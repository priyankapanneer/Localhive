<?php 
include "admin_header.php"; 
include('../inc/db.php');
?>

<!-- Page Wrapper -->
<div class="container py-4">

    <!-- Page Title -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="fw-bold text-success">Customers</h2>
    </div>

    <!-- Card -->
    <div class="card shadow-sm border-0 rounded-3">
        <div class="card-body">

            <?php
            // Fetch customers
            $query = "SELECT id, name, email, phone, created_at FROM users ORDER BY id DESC";
            $customers = mysqli_query($conn, $query);
            ?>

            <!-- Responsive Table -->
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="bg-success text-white">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Registered On</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php 
                        if (mysqli_num_rows($customers) > 0) {
                            while($row = mysqli_fetch_assoc($customers)) { ?>
                                <tr>
                                    <td><?= $row['id'] ?></td>
                                    <td><?= htmlspecialchars($row['name']) ?></td>
                                    <td><?= htmlspecialchars($row['email']) ?></td>
                                    <td><?= htmlspecialchars($row['phone']) ?></td>
                                    <td><?= $row['created_at'] ?></td>
                                </tr>
                            <?php 
                            }
                        } else { ?>
                            <!-- No Records Found -->
                            <tr>
                                <td colspan="5" class="text-center py-4 text-muted">
                                    No customers found.
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>

                </table>
            </div>

        </div>
    </div>

</div>

<?php include "admin_footer.php"; ?>
