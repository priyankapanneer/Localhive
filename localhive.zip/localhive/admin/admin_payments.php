<?php 
include "admin_header.php"; 
include('../inc/db.php');
?>

<div class="page-header">
    <h2>Payments</h2>
    <hr>
</div>

<?php
// Secure query using prepared statement
$query = "
    SELECT 
        pay.id, 
        u.name AS customer, 
        p.name AS provider, 
        s.title AS service, 
        pay.amount, 
        pay.status, 
        pay.created_at
    FROM payments pay
    JOIN bookings b ON pay.booking_id = b.id
    JOIN users u ON b.user_id = u.id
    JOIN providers p ON b.provider_id = p.id
    JOIN services s ON b.service_id = s.id
    ORDER BY pay.created_at DESC
";

$payments = mysqli_query($conn, $query);
?>

<div class="table-responsive">
    <table class="table table-hover payments-table align-middle">
        <thead>
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Provider</th>
                <th>Service</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>

        <tbody>
            <?php while($row = mysqli_fetch_assoc($payments)) { ?>
            <tr>
                <td><?= htmlspecialchars($row['id']) ?></td>
                <td><?= htmlspecialchars($row['customer']) ?></td>
                <td><?= htmlspecialchars($row['provider']) ?></td>
                <td><?= htmlspecialchars($row['service']) ?></td>

                <td>₹ <?= number_format($row['amount'], 2) ?></td>

                <td>
                    <?php 
                        $status = strtolower($row['status']);
                        if (in_array($status, ['success', 'paid'])) {
                            echo "<span class='badge custom-badge bg-success'>Paid</span>";
                        } 
                        elseif ($status === 'pending') {
                            echo "<span class='badge custom-badge bg-warning text-dark'>Pending</span>";
                        } 
                        elseif (in_array($status, ['failed', 'error'])) {
                            echo "<span class='badge custom-badge bg-danger'>Failed</span>";
                        } 
                        else {
                            echo "<span class='badge custom-badge bg-secondary'>". htmlspecialchars(ucfirst($status)) ."</span>";
                        }
                    ?>
                </td>

                <td><?= date("d M Y, h:i A", strtotime($row['created_at'])) ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<style>
/* Global Page Header */
.page-header h2 {
    color: #007E6E;
    font-weight: 700;
    margin-bottom: 8px;
}

.page-header hr {
    border: 2px solid #73AF6F;
    width: 180px;
    margin-bottom: 25px;
}

/* Table Design */
.payments-table {
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 6px 18px rgba(0,0,0,0.08);
}

.payments-table thead {
    background-color: #007E6E;
    color: #E7DEAF;
}

.payments-table tbody tr:nth-child(odd) {
    background-color: #F5ECCE;
}

.payments-table tbody tr:hover {
    background-color: rgba(0, 126, 110, 0.12);
    transition: 0.3s ease;
}

/* Table text */
.payments-table th,
.payments-table td {
    text-align: center;
    padding: 14px;
}

/* Status Badges */
.custom-badge {
    padding: 0.55em 0.9em;
    font-weight: 600;
    border-radius: 14px;
}

/* Mobile Scroll */
.table-responsive {
    margin-top: 10px;
}
</style>

<?php include "admin_footer.php"; ?>
