<?php
include('../inc/db.php');

// Validate ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("<div style='padding:20px; background:#fff3cd; color:#856404; border:1px solid #ffeeba; border-radius:8px; width:80%; margin:40px auto; text-align:center;'>
            ❗ Invalid Provider ID
        </div>");
}

$id = (int)$_GET['id'];

// Handle confirmation
if (isset($_POST['confirm'])) {

    if ($_POST['confirm'] === 'Yes') {
        // Delete provider using prepared statement
        $stmt = $conn->prepare("DELETE FROM providers WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        echo "
        <div style='padding:25px; margin:40px auto; background:#d4edda; border:1px solid #c3e6cb; 
        border-radius:10px; width:80%; text-align:center; color:#155724; font-size:18px;'>
            ✔ Provider deleted successfully!
        </div>

        <div style='text-align:center;'>
            <a href='admin_providers.php' 
               style='padding:12px 24px; background:#007E6E; color:#fff; 
               text-decoration:none; border-radius:8px; font-weight:bold;'>
               Back to Providers
            </a>
        </div>";

        exit;
    } else {
        header("Location: admin_providers.php");
        exit;
    }
}

// Fetch provider details using prepared statement
$stmt = $conn->prepare("SELECT name FROM providers WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$provider = $result->fetch_assoc();

if (!$provider) {
    die("<div style='padding:20px; background:#fff3cd; color:#856404; border:1px solid #ffeeba; 
         border-radius:8px; width:80%; margin:40px auto; text-align:center;'>
            ⚠ Provider not found
        </div>");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Provider</title>

    <style>
        body {
            font-family: "Segoe UI", Arial, sans-serif;
            background-color: #E7DEAF;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .confirm-box {
            background: #ffffff;
            padding: 35px 40px;
            border-radius: 14px;
            width: 420px;
            text-align: center;
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
            border: 2px solid #D7C097;
        }

        .confirm-box h2 {
            color: #007E6E;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .confirm-box p {
            font-size: 17px;
            color: #333;
        }

        .btn {
            display: inline-block;
            padding: 10px 22px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: bold;
            font-size: 15px;
            margin: 10px;
            transition: 0.2s ease;
        }

        .btn-yes {
            background: #73AF6F;
            color: #fff;
        }

        .btn-yes:hover {
            background: #007E6E;
        }

        .btn-no {
            background: #D7C097;
            color: #4b3e2a;
        }

        .btn-no:hover {
            background: #c4ab81;
        }
    </style>
</head>
<body>

    <div class="confirm-box">
        <h2>Delete Provider</h2>
        <p>Are you sure you want to delete <strong><?= htmlspecialchars($provider['name']) ?></strong>?</p>

        <form method="POST">
            <button name="confirm" value="Yes" class="btn btn-yes">Yes, Delete</button>
            <button name="confirm" value="No" class="btn btn-no">Cancel</button>
        </form>
    </div>

</body>
</html>
