<?php 
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>LocalHive Admin Panel</title>

    <!-- BOOTSTRAP -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

    <!-- ICONS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <!-- GLOBAL ADMIN THEME -->
    <link rel="stylesheet" href="/localhive/assets/css/admin_theme.css">

    <style>
        :root {
            --brand-accent: #007E6E;
            --brand-accent-light: #73AF6F;
            --brand-gold: #E7DEAF;
            --brand-grey: #F5F5F5;
        }

        body {
            background-color: var(--brand-grey);
            font-family: 'Segoe UI', Tahoma, sans-serif;
            overflow-x: hidden;
        }

        /* SIDEBAR */
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background-color: var(--brand-accent);
            padding: 20px 0;
            color: var(--brand-gold);
            transition: 0.3s ease;
        }

        .sidebar h4 {
            text-align: center;
            font-weight: 700;
            color: var(--brand-gold);
            margin-bottom: 30px;
        }

        .sidebar a {
            display: block;
            padding: 12px 25px;
            color: var(--brand-gold);
            text-decoration: none;
            font-weight: 600;
            border-left: 4px solid transparent;
            transition: 0.3s ease;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: var(--brand-accent-light);
            border-left: 4px solid #fff;
        }

        .sidebar .logout {
            margin-top: 30px;
            color: #fff;
            background: #c12020;
            border-left: 4px solid transparent;
        }

        .sidebar .logout:hover {
            background: #ff3d3d;
            border-left: 4px solid #fff;
        }

        /* MAIN CONTENT */
        .main-content {
            margin-left: 250px;
            padding: 30px;
            transition: 0.3s ease;
        }

        /* MOBILE SIDEBAR */
        @media(max-width: 768px) {
            .sidebar {
                left: -250px;
            }
            .sidebar.active {
                left: 0;
            }
            .main-content {
                margin-left: 0;
            }
        }

        /* TOGGLE BUTTON */
        .toggle-btn {
            font-size: 26px;
            cursor: pointer;
            color: var(--brand-accent);
            display: none;
        }

        @media(max-width: 768px) {
            .toggle-btn {
                display: inline-block;
            }
        }
    </style>

</head>

<body>

<!-- Sidebar Toggle (Mobile) -->
<div class="p-3">
    <i class="bi bi-list toggle-btn" onclick="toggleSidebar()"></i>
</div>

<!-- Sidebar -->
<div class="sidebar" id="sidebarMenu">
    <h4>LocalHive Admin</h4>

    <a href="admin_dashboard.php" class="<?= $activePage=='dashboard'?'active':'' ?>">
        <i class="bi bi-speedometer2 me-2"></i> Dashboard
    </a>

    <a href="admin_customers.php" class="<?= $activePage=='customers'?'active':'' ?>">
        <i class="bi bi-people me-2"></i> Customers
    </a>

    <a href="admin_providers.php" class="<?= $activePage=='providers'?'active':'' ?>">
        <i class="bi bi-person-workspace me-2"></i> Providers
    </a>

    <a href="admin_services.php" class="<?= $activePage=='services'?'active':'' ?>">
        <i class="bi bi-tools me-2"></i> Services
    </a>

    <a href="admin_bookings.php" class="<?= $activePage=='bookings'?'active':'' ?>">
        <i class="bi bi-calendar-check me-2"></i> Bookings
    </a>

    <a href="admin_emergency_bookings.php" class="<?= $activePage=='emergency'?'active':'' ?>">
        <i class="bi bi-exclamation-triangle me-2"></i> Emergency Bookings
    </a>

    <a href="admin_late_reports.php" class="<?= $activePage=='late_reports'?'active':'' ?>">
        <i class="bi bi-clock-history me-2"></i> Late Arrival Reports
    </a>

    <a href="admin_payments.php" class="<?= $activePage=='payments'?'active':'' ?>">
        <i class="bi bi-credit-card-2-front me-2"></i> Payments
    </a>

    <a href="admin_download_reports.php" class="<?= $activePage=='reports'?'active':'' ?>">
        <i class="bi bi-download me-2"></i> Download Reports
    </a>

    <a href="admin_logout.php" class="logout">
        <i class="bi bi-box-arrow-right me-2"></i> Logout
    </a>
</div>

<!-- Main Content -->
<div class="main-content">
