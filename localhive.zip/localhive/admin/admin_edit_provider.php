<?php
include('../inc/db.php');
include("admin_header.php");

// Validate Provider ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("<div class='alert alert-danger text-center mt-4'>Invalid Provider ID</div>");
}

$id = intval($_GET['id']);

// Fetch provider details
$q = mysqli_query($conn, "SELECT * FROM providers WHERE id = $id");
$provider = mysqli_fetch_assoc($q);

if (!$provider) {
    die("<div class='alert alert-warning text-center mt-4'>Provider Not Found</div>");
}

$msg = "";

// Update Provider
if (isset($_POST['update'])) {

    $name     = mysqli_real_escape_string($conn, trim($_POST['name']));
    $email    = mysqli_real_escape_string($conn, trim($_POST['email']));
    $phone    = mysqli_real_escape_string($conn, trim($_POST['phone']));
    $approved = intval($_POST['status']);  // Maps to providers.approved

    $updateQuery = "
        UPDATE providers 
        SET name='$name',
            email='$email',
            phone='$phone',
            approved=$approved
        WHERE id=$id
    ";

    if (mysqli_query($conn, $updateQuery)) {
        $msg = "<div class='alert alert-success'>Provider updated successfully!</div>";
        // Refresh the provider data
        $provider = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM providers WHERE id = $id"));
    } else {
        $msg = "<div class='alert alert-danger'>Update failed! Please try again.</div>";
    }
}
?>

<style>
    body {
        background-color: #E7DEAF;
        color: #007E6E;
        font-family: "Segoe UI", Arial, sans-serif;
    }

    .edit-card {
        background: #ffffff;
        border-radius: 15px;
        padding: 30px;
        border: 2px solid #D7C097;
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }

    .form-control {
        border: 2px solid #73AF6F;
        border-radius: 8px;
    }

    .form-control:focus {
        box-shadow: 0 0 10px rgba(0,126,110,0.4);
        border-color: #007E6E;
    }

    label {
        font-weight: bold;
        color: #007E6E;
    }

    .main-btn {
        background-color: #007E6E;
        color: #E7DEAF;
        border: none;
        border-radius: 10px;
        padding: 12px;
        font-size: 1.1rem;
        font-weight: bold;
        transition: 0.3s ease;
        width: 100%;
    }

    .main-btn:hover {
        background-color: #73AF6F;
        color: #ffffff;
    }

    h2.section-title {
        color: #007E6E;
        margin-top: 20px;
        font-weight: 800;
    }

    .divider {
        height: 3px;
        background: #73AF6F;
        width: 120px;
        border-radius: 5px;
        margin-bottom: 30px;
    }
</style>

<div class="container mt-4">
    
    <h2 class="section-title">Edit Provider</h2>
    <div class="divider"></div>

    <?= $msg ?>

    <form method="POST" class="edit-card">

        <div class="mb-3">
            <label>Name</label>
            <input type="text" 
                   name="name" 
                   class="form-control" 
                   required
                   value="<?= htmlspecialchars($provider['name']) ?>">
        </div>

        <div class="mb-3">
            <label>Email</label>
            <input type="email" 
                   name="email" 
                   class="form-control" 
                   required
                   value="<?= htmlspecialchars($provider['email']) ?>">
        </div>

        <div class="mb-3">
            <label>Phone</label>
            <input type="text" 
                   name="phone" 
                   class="form-control" 
                   required
                   value="<?= htmlspecialchars($provider['phone']) ?>">
        </div>

        <div class="mb-3">
            <label>Status</label>
            <?php 
                // providers.approved is the actual DB status column
                $statusVal = $provider['approved'] ?? 0;
            ?>
            <select name="status" class="form-control">
                <option value="1" <?= $statusVal == 1 ? 'selected' : '' ?>>Active</option>
                <option value="0" <?= $statusVal == 0 ? 'selected' : '' ?>>Inactive</option>
            </select>
        </div>

        <button name="update" class="main-btn">Update Provider</button>
    </form>
</div>

<?php include("admin_footer.php"); ?>
