<?php
session_start();
include('../inc/db.php');

$msg = "";

// LOGIN PROCESS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass  = $_POST['password'];

    $query = "SELECT id, email, password FROM admins WHERE email = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {

        $data = mysqli_fetch_assoc($result);

        // verify hashed password
        if (password_verify($pass, $data['password'])) {
            $_SESSION['admin_id'] = $data['id'];
            header("Location: admin_dashboard.php");
            exit();
        } else {
            $msg = "Incorrect password!";
        }

    } else {
        $msg = "Email not found!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Admin Login - LocalHive</title>

    <!-- Bootstrap 5 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

    <!-- UI Theme -->
    <style>
        :root {
            --primary: #007E6E;
            --primary-light: #73AF6F;
            --cream: #E7DEAF;
            --bg-light: #F5F5F5;
            --card-shadow: rgba(0, 0, 0, 0.12);
        }

        body {
            background: var(--bg-light);
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            height: 100vh;
            display: flex;
            align-items: center;
        }

        .login-card {
            width: 420px;
            margin: auto;
            background: var(--cream);
            padding: 35px;
            border-radius: 18px;
            box-shadow: 0 12px 25px var(--card-shadow);
            transition: 0.25s ease-in-out;
        }

        .login-card:hover {
            transform: translateY(-6px);
        }

        .login-title {
            color: var(--primary);
            font-weight: 700;
            margin-bottom: 20px;
        }

        .form-label {
            color: var(--primary);
            font-weight: 600;
        }

        .form-control {
            border-radius: 10px;
            border: 1px solid var(--primary);
        }

        .form-control:focus {
            border-color: var(--primary-light);
            box-shadow: 0 0 6px var(--primary-light);
        }

        .btn-primary-custom {
            background: var(--primary);
            border: none;
            border-radius: 10px;
            padding: 10px;
            font-weight: 600;
            transition: 0.3s;
        }

        .btn-primary-custom:hover {
            background: var(--primary-light);
        }

        .error-msg {
            font-weight: 600;
            color: #b30000;
            background: #ffd6d6;
            padding: 8px;
            border-radius: 8px;
        }
    </style>

</head>

<body>

    <div class="login-card">
        <h2 class="text-center login-title">Admin Login</h2>

        <!-- Error Message -->
        <?php if (!empty($msg)): ?>
            <p class="text-center error-msg"><?= htmlspecialchars($msg) ?></p>
        <?php endif; ?>

        <form method="POST" autocomplete="off">
            <div class="mb-3">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="admin@example.com" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter password" required>
            </div>

            <button class="btn btn-primary-custom w-100 mt-2" name="login">Login</button>
        </form>
    </div>

</body>

</html>
