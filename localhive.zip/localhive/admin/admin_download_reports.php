<?php include "admin_header.php"; ?>

<style>
    body {
        background-color: #E7DEAF;
        color: #007E6E;
        font-family: "Segoe UI", Arial, sans-serif;
    }

    .page-title {
        margin-top: 25px;
        font-weight: bold;
        color: #007E6E;
    }

    .divider {
        border: 0;
        height: 3px;
        background: #D7C097;
        width: 120px;
        margin-bottom: 30px;
    }

    .report-container {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        padding-bottom: 50px;
    }

    .report-card {
        flex: 1 1 calc(25% - 20px);
        min-width: 230px;
        text-decoration: none;
        background: #ffffff;
        border-radius: 12px;
        padding: 25px 20px;
        border: 2px solid #D7C097;
        box-shadow: 0 6px 18px rgba(0,0,0,0.12);
        transition: all 0.25s ease;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .report-card h4 {
        margin: 0 0 10px;
        color: #007E6E;
        font-weight: 700;
    }

    .report-card p {
        color: #444;
        margin: 0;
    }

    .report-card:hover {
        background: #007E6E;
        border-color: #007E6E;
        transform: translateY(-5px);
    }

    .report-card:hover h4,
    .report-card:hover p {
        color: #ffffff;
    }

    @media(max-width: 768px) {
        .report-container {
            flex-direction: column;
        }
        .report-card {
            flex: 1 1 100%;
        }
    }
</style>

<div class="container">

    <h2 class="page-title">Download Reports</h2>
    <hr class="divider">

    <div class="report-container">

        <a href="../reports/download_bookings.php" class="report-card">
            <h4>Bookings Report</h4>
            <p>Download all bookings as CSV</p>
        </a>

        <a href="../reports/download_emergency.php" class="report-card">
            <h4>Emergency Bookings Report</h4>
            <p>Download all emergency bookings as CSV</p>
        </a>

        <a href="../reports/download_late_reports.php" class="report-card">
            <h4>Late Arrival Reports</h4>
            <p>Download all late arrival reports as CSV</p>
        </a>

        <a href="../reports/download_payments.php" class="report-card">
            <h4>Payments Report</h4>
            <p>Download all payments as CSV</p>
        </a>

    </div>
</div>

<?php include "admin_footer.php"; ?>
