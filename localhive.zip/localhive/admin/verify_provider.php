<?php
include 'admin_header.php';
include('../inc/db.php');

// -------------------------------------------
// 1. VALIDATE PARAMETERS
// -------------------------------------------
if (!isset($_GET['id'], $_GET['v']) || !is_numeric($_GET['id']) || !is_numeric($_GET['v'])) {
    header("Location: admin_providers.php?error=invalid");
    exit();
}

$id = (int)$_GET['id'];
$v  = (int)$_GET['v'];  // 1=approve, 0=reject

if (!in_array($v, [0, 1], true)) {
    header("Location: admin_providers.php?error=invalid_action");
    exit();
}

// -------------------------------------------
// 2. CHECK PROVIDER EXISTS
// -------------------------------------------
$stmt = $conn->prepare("SELECT id, name FROM providers WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$provider = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$provider) {
    header("Location: admin_providers.php?error=not_found");
    exit();
}

// -------------------------------------------
// 3. UPDATE VERIFICATION STATUS
// -------------------------------------------
$stmt = $conn->prepare("UPDATE providers SET is_verified = ? WHERE id = ?");
$stmt->bind_param("ii", $v, $id);

if ($stmt->execute()) {
    $msg        = ($v === 1) ? "Provider approved successfully!" : "Provider rejected successfully!";
    $alertClass = "alert-success";
} else {
    $msg        = "Failed to update provider. Please try again.";
    $alertClass = "alert-danger";
}
$stmt->close();
?>

<div class="container mt-5">

    <div class="card shadow-lg border-0 p-4"
         style="background:#ffffff; border-radius:16px;">

        <div class="text-center mb-3">
            <h3 class="fw-bold" style="color:#007E6E;">
                Provider Verification Status
            </h3>
            <hr style="border:1px solid #007E6E;">
        </div>

        <div class="alert <?= $alertClass ?> text-center fs-5">
            <?= htmlspecialchars($msg) ?>
        </div>

        <div class="text-center mt-4">
            <a href="admin_providers.php"
               class="btn px-4 py-2"
               style="background-color:#007E6E; color:#E7DEAF; border-radius:8px;">
               ← Back to Providers
            </a>
        </div>

    </div>

</div>

<?php include 'admin_footer.php'; ?>
