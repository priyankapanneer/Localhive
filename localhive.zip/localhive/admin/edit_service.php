<?php
include "admin_header.php";
include __DIR__ . '/../inc/db.php';

// Validate id
if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    header("Location: admin_services.php");
    exit();
}

$id = (int) $_GET['id'];

// --- Fetch service ---
$stmt = $conn->prepare("SELECT id, title, price, duration_minutes FROM services WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$service = $result->fetch_assoc();
$stmt->close();

if (!$service) {
    echo '<div class="container mt-4"><div class="alert alert-danger">Service not found.</div></div>';
    include "admin_footer.php";
    exit();
}

// --- Handle update ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title    = trim($_POST['title']);
    $price    = trim($_POST['price']);
    $duration = (int) $_POST['duration_minutes'];

    if ($title === '' || $price === '') {
        $msg = '<div class="alert alert-danger">All fields are required.</div>';
    } else {
        $update = $conn->prepare("UPDATE services SET title = ?, price = ?, duration_minutes = ? WHERE id = ?");
        $update->bind_param("sdii", $title, $price, $duration, $id);
        $update->execute();
        $update->close();

        echo "<script>
                window.location.href = 'admin_services.php?updated=1';
              </script>";
        exit();
    }
}
?>

<!-- ===== UI STYLES ===== -->
<style>
.page-title {
    color: #007E6E;
    font-weight: 700;
}
.brand-btn {
    background-color: #007E6E;
    color: #E7DEAF;
    font-weight: 600;
    border-radius: 8px;
}
.brand-btn:hover {
    background-color: #069581;
    color: #fff;
}
.card-custom {
    border-radius: 15px;
    padding: 25px;
    background: #fff;
    border-left: 5px solid #73AF6F;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}
input.form-control {
    border-radius: 10px !important;
}
</style>

<div class="container mt-4">
    <div class="card-custom">

        <h2 class="page-title">Edit Service</h2>
        <hr>

        <?= $msg ?? '' ?>

        <form method="post">

            <div class="mb-3">
                <label class="form-label">Service Title</label>
                <input type="text" name="title" class="form-control" 
                    value="<?= htmlspecialchars($service['title']) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Price (INR)</label>
                <input type="number" step="0.01" name="price" class="form-control"
                    value="<?= htmlspecialchars($service['price']) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Duration (Minutes)</label>
                <input type="number" name="duration_minutes" class="form-control"
                    value="<?= htmlspecialchars($service['duration_minutes']) ?>" required>
            </div>

            <button class="btn brand-btn">Save Changes</button>
            <a href="admin_services.php" class="btn btn-secondary">Cancel</a>
        </form>

    </div>
</div>

<?php include "admin_footer.php"; ?>
