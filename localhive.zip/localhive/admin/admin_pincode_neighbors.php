<?php
include "admin_header.php";
include('../inc/db.php');

$msg = "";

/* -------------------------
   ADD NEIGHBOR
-------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_neighbor'])) {
    $pincode = trim($_POST['pincode'] ?? '');
    $neighbor = trim($_POST['neighbor'] ?? '');

    if ($pincode === '' || $neighbor === '') {
        $msg = "Both pincode and neighbor are required.";
    } else {
        $stmt = $conn->prepare("INSERT IGNORE INTO pincode_neighbors (pincode, neighbor) VALUES (?,?)");
        $stmt->bind_param("ss", $pincode, $neighbor);

        if ($stmt->execute()) {
            header("Location: admin_pincode_neighbors.php?added=1");
            exit;
        } else {
            $msg = "Error adding neighbor: " . $stmt->error;
        }
    }
}

/* -------------------------
   DELETE NEIGHBOR
-------------------------- */
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if ($id > 0) {
        $deleteStmt = $conn->prepare("DELETE FROM pincode_neighbors WHERE id = ?");
        $deleteStmt->bind_param("i", $id);
        $deleteStmt->execute();
    }
    header("Location: admin_pincode_neighbors.php?deleted=1");
    exit;
}

?>

<div class="container mt-4">

    <div class="admin-card shadow-sm p-4">
        <h3 class="page-title">Pincode Neighbors</h3>
        <p class="subtitle">
            Map nearby pincodes. Helps with search results when <code>?expand=1</code> is used.
        </p>

        <!-- Alerts -->
        <?php if ($msg): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <?php if (isset($_GET['added'])): ?>
            <div class="alert alert-success">Neighbor added successfully!</div>
        <?php endif; ?>

        <?php if (isset($_GET['deleted'])): ?>
            <div class="alert alert-success">Neighbor removed successfully!</div>
        <?php endif; ?>

        <!-- Add Form -->
        <form method="POST" class="row g-3 mb-4">
            <div class="col-md-4">
                <label class="form-label fw-semibold">Pincode</label>
                <input name="pincode" class="form-control" placeholder="Enter pincode" required>
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold">Neighbor Pincode</label>
                <input name="neighbor" class="form-control" placeholder="Enter neighbor" required>
            </div>

            <div class="col-md-4 d-flex align-items-end">
                <button name="add_neighbor" class="btn btn-brand w-100">
                    ➕ Add Neighbor
                </button>
            </div>
        </form>

        <!-- Table -->
        <?php
        $res = $conn->query("SELECT * FROM pincode_neighbors ORDER BY pincode, neighbor LIMIT 500");
        ?>

        <?php if ($res && $res->num_rows > 0): ?>

            <div class="table-responsive">
                <table class="table table-hover align-middle neighbors-table shadow-sm">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Pincode</th>
                            <th>Neighbor</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php while ($row = $res->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td><?= htmlspecialchars($row['pincode']) ?></td>
                            <td><?= htmlspecialchars($row['neighbor']) ?></td>
                            <td>
                                <a href="?delete=<?= $row['id'] ?>" 
                                   onclick="return confirm('Are you sure you want to delete this neighbor set?')"
                                   class="btn btn-sm btn-danger">
                                   🗑 Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>

                </table>
            </div>

        <?php else: ?>
            <div class="alert alert-info mt-3">No neighbor mappings found.</div>
        <?php endif; ?>
    </div>
</div>

<?php include "admin_footer.php"; ?>

<style>
/* Theme Colors */
:root {
    --brand-green: #007E6E;
    --brand-accent: #73AF6F;
    --brand-light: #E7DEAF;
}

/* Page Title */
.page-title {
    color: var(--brand-green);
    font-weight: 700;
}

.subtitle {
    color: #555;
    margin-bottom: 20px;
}

/* Card */
.admin-card {
    background: #FFF;
    border-radius: 12px;
    border-left: 5px solid var(--brand-green);
}

/* Buttons */
.btn-brand {
    background: var(--brand-green);
    color: #fff;
    font-weight: 600;
    border-radius: 10px;
    transition: 0.2s;
}

.btn-brand:hover {
    background: var(--brand-accent);
}

/* Table */
.neighbors-table thead {
    background: var(--brand-green);
    color: var(--brand-light);
}

.neighbors-table tbody tr:nth-child(even) {
    background-color: #F7F2DE;
}

.neighbors-table tbody tr:hover {
    background-color: rgba(0, 126, 110, 0.18);
    transition: 0.25s ease;
}

.neighbors-table th, .neighbors-table td {
    text-align: center;
    padding: 12px;
}
</style>
