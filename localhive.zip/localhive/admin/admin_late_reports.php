<?php 
include "admin_header.php"; 
include('../inc/db.php');

// ----------------------------------
// SAFETY CHECKS + FETCH REPORTS
// ----------------------------------
$query = "
    SELECT 
        r.id, 
        u.name AS reporter, 
        p.name AS provider, 
        r.booking_id, 
        r.reported_at, 
        r.delay_minutes, 
        r.reason, 
        r.resolved
    FROM late_reports r
    JOIN users u ON r.reporter_user_id = u.id
    JOIN providers p ON r.provider_id = p.id
    ORDER BY r.reported_at DESC
";

$reports = mysqli_query($conn, $query);
?>

<div class="container mt-4">
    <h2 class="page-title">Late Arrival Reports</h2>
    <hr class="page-divider">

    <div class="card shadow-custom p-3">
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle text-center custom-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Reporter</th>
                        <th>Provider</th>
                        <th>Booking ID</th>
                        <th>Reported At</th>
                        <th>Delay (mins)</th>
                        <th>Reason</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if(mysqli_num_rows($reports) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($reports)): ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td><?= htmlspecialchars($row['reporter']) ?></td>
                            <td><?= htmlspecialchars($row['provider']) ?></td>
                            <td><?= $row['booking_id'] ?></td>
                            <td><?= date("d M Y, h:i A", strtotime($row['reported_at'])) ?></td>
                            <td><?= $row['delay_minutes'] ?></td>
                            <td><?= htmlspecialchars($row['reason']) ?></td>
                            <td>
                                <?php if($row['resolved'] == 1): ?>
                                    <span class="badge status-resolved">Resolved</span>
                                <?php else: ?>
                                    <span class="badge status-pending">Pending</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-muted py-3">
                                No late arrival reports found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>
    </div>
</div>

<?php include "admin_footer.php"; ?>

<!-- ========== PAGE STYLES ========== -->
<style>
/* PAGE TITLE */
.page-title {
    color: #007E6E;
    font-weight: 700;
    margin-bottom: 10px;
}

/* DIVIDER */
.page-divider {
    border: 2px solid #73AF6F;
    margin-bottom: 25px;
    width: 180px;
}

/* CARD SHADOW */
.shadow-custom {
    border-radius: 15px;
    background: #E7DEAF;
    box-shadow: 0px 4px 14px rgba(0,0,0,0.15);
}

/* TABLE STYLING */
.custom-table {
    border-radius: 10px;
    overflow: hidden;
}

.custom-table thead {
    background-color: #007E6E;
    color: #E7DEAF;
    font-weight: 600;
}

.custom-table tbody tr:nth-child(odd) {
    background-color: #D7C097;
}

.custom-table tbody tr:hover {
    background-color: rgba(0,126,110,0.25) !important;
    transition: 0.25s ease-in-out;
}

/* BADGES */
.status-resolved {
    background-color: #28a745 !important;
    color: #fff !important;
    padding: 8px 14px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 0.85rem;
}

.status-pending {
    background-color: #ffc107 !important;
    color: #3d3d3d !important;
    padding: 8px 14px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 0.85rem;
}

/* RESPONSIVE TABLE */
.table-responsive {
    overflow-x: auto;
}

</style>
