<?php 
include "admin_header.php"; 
include('../inc/db.php');

/* ---------------------------------------------------------
   FETCH FILTER VALUES
--------------------------------------------------------- */
$radius = isset($_GET['radius']) ? intval($_GET['radius']) : '';
$userLat = isset($_GET['user_lat']) ? floatval($_GET['user_lat']) : '';
$userLng = isset($_GET['user_lng']) ? floatval($_GET['user_lng']) : '';

/* ---------------------------------------------------------
   BASE QUERY (SAFE + CLEAN)
--------------------------------------------------------- */
$query = "SELECT *, latitude, longitude FROM providers";

/* ---------------------------------------------------------
   DISTANCE CALCULATION ONLY IF VALID LAT/LNG ENTERED
--------------------------------------------------------- */
if ($userLat && $userLng) {
    $query = "
        SELECT *, 
        (6371 * ACOS(
            COS(RADIANS(?)) * 
            COS(RADIANS(latitude)) * 
            COS(RADIANS(longitude) - RADIANS(?)) + 
            SIN(RADIANS(?)) * SIN(RADIANS(latitude))
        )) AS distance
        FROM providers
    ";
}

$params = [];
$types  = "";

/* bind if lat/lng used */
if ($userLat && $userLng) {
    $params = [$userLat, $userLng, $userLat];
    $types  = "ddd";
}

/* HAVING for radius */
$having = "";

if ($radius && $userLat && $userLng) {
    $having = " HAVING distance <= " . intval($radius);
}

/* ---------------------------------------------------------
   FINAL ORDER CLAUSE
--------------------------------------------------------- */
$query .= $having . " ORDER BY id DESC";

/* ---------------------------------------------------------
   PREPARE + EXECUTE QUERY
--------------------------------------------------------- */
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

?>
<!-- PAGE TITLE -->
<h2 class="page-title">Manage Service Providers</h2>

<!-- FILTER UI -->
<div class="filter-card p-3 mb-4 shadow-sm">
    <form method="GET" class="row gy-2">
        
        <div class="col-md-3">
            <select name="radius" class="form-control">
                <option value="">Distance Filter</option>
                <?php foreach([5,10,20] as $r): ?>
                    <option value="<?= $r ?>" <?= ($radius==$r ? "selected" : "") ?>>
                        Within <?= $r ?> km
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-3">
            <input type="text" name="user_lat" class="form-control" placeholder="Latitude"
                value="<?= htmlspecialchars($userLat) ?>">
        </div>

        <div class="col-md-3">
            <input type="text" name="user_lng" class="form-control" placeholder="Longitude"
                value="<?= htmlspecialchars($userLng) ?>">
        </div>

        <div class="col-md-3">
            <button class="btn btn-primary w-100">Apply Filter</button>
        </div>

    </form>
</div>


<!-- PROVIDERS TABLE -->
<div class="table-responsive shadow-sm rounded">
<table class="table table-hover align-middle">
    <thead class="table-header">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Service</th>
            <th>Status</th>
            <th>Verification</th>
            <th>Location</th>
            <th>Actions</th>
        </tr>
    </thead>

    <tbody>
    <?php while($row = $result->fetch_assoc()): ?>

        <?php
        /* Normalize Status */
        $status = isset($row['status']) ? $row['status'] : (isset($row['approved']) ? $row['approved'] : 0);

        /* Normalize Verification */
        $verified = isset($row['is_verified']) ? $row['is_verified'] : (isset($row['approved']) ? $row['approved'] : 0);
        ?>

        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['phone']) ?></td>
            <td><?= htmlspecialchars($row['service'] ?? 'N/A') ?></td>

            <!-- STATUS -->
            <td>
                <?php if($status == 1): ?>
                    <span class="badge bg-success">Active</span>
                <?php else: ?>
                    <span class="badge bg-danger">Inactive</span>
                <?php endif; ?>
            </td>

            <!-- VERIFICATION -->
            <td>
                <?php if($verified == 1): ?>
                    <span class="badge bg-success">Verified</span>
                <?php else: ?>
                    <span class="badge bg-warning text-dark">Pending</span><br>

                    <a href="verify_provider.php?id=<?= $row['id'] ?>&v=1"
                       class="btn btn-sm btn-success mt-1">Approve</a>

                    <a href="verify_provider.php?id=<?= $row['id'] ?>&v=0"
                       class="btn btn-sm btn-danger mt-1">Reject</a>
                <?php endif; ?>
            </td>

            <!-- MAP -->
            <td>
                <?php if($row['latitude'] && $row['longitude']): ?>
                    <a class="btn btn-sm btn-info" 
                       target="_blank"
                       href="https://www.google.com/maps?q=<?= $row['latitude'] ?>,<?= $row['longitude'] ?>">
                       View
                    </a>
                <?php else: ?>
                    <span class="text-muted">Not Added</span>
                <?php endif; ?>
            </td>

            <!-- ACTIONS -->
            <td>
                <a href="admin_edit_provider.php?id=<?= $row['id'] ?>" 
                   class="btn btn-sm btn-primary">Edit</a>

                <a href="admin_delete_provider.php?id=<?= $row['id'] ?>" 
                   onclick="return confirm('Delete Provider?')"
                   class="btn btn-sm btn-danger">Delete</a>
            </td>
        </tr>

    <?php endwhile; ?>
    </tbody>
</table>
</div>


<!-- ENHANCED UI STYLES -->
<style>
.page-title{
    color:#007E6E;
    font-weight:700;
    margin-bottom:18px;
}

.filter-card{
    background:#fff;
    border-left:4px solid #007E6E;
    border-radius:10px;
}

.table-header{
    background:#007E6E;
    color:#E7DEAF;
    text-transform:uppercase;
}

.table-hover tbody tr:hover{
    background-color:rgba(0,126,110,0.1);
}

.btn-primary{
    background:#007E6E;
    border:none;
}
.btn-primary:hover{
    background:#73AF6F;
}

.btn-info{
    background:#007E6E;
    border:none;
    color:#fff;
}
.btn-info:hover{
    background:#73AF6F;
}

.badge{
    font-size:0.85rem;
    padding:6px 10px;
}
</style>

<?php include "admin_footer.php"; ?>
