<?php
session_start();

// Require admin login
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

require_once __DIR__ . '/../inc/db.php';

// Validate ID
if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    header("Location: admin_services.php?msg=invalid_id");
    exit();
}

$serviceId = (int)$_GET['id'];

// Prepared delete query
$query = "DELETE FROM services WHERE id = ?";
$stmt = $conn->prepare($query);

if ($stmt) {
    $stmt->bind_param("i", $serviceId);

    if ($stmt->execute()) {
        $stmt->close();
        header("Location: admin_services.php?msg=deleted");
        exit();
    } else {
        $stmt->close();
        header("Location: admin_services.php?msg=delete_error");
        exit();
    }
} else {
    header("Location: admin_services.php?msg=query_error");
    exit();
}
?>
