<?php 
include "admin_header.php"; 
include('../inc/db.php'); 
?>

<!-- Page Wrapper -->
<div class="container py-4">

    <!-- Page Title -->
    <h2 class="fw-bold text-success mb-3">Dashboard</h2>
    <hr>

    <div class="row g-4">

        <!-- Total Customers -->
        <div class="col-md-3 col-sm-6">
            <div class="card shadow-sm border-0 rounded-3 text-center py-4">
                <h5 class="text-success fw-bold">Total Customers</h5>
                <h2 class="fw-bold text-dark">
                    <?php 
                        $c = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users");
                        echo mysqli_fetch_assoc($c)['total'];
                    ?>
                </h2>
                <small class="text-muted">Registered customers</small>
            </div>
        </div>

        <!-- Total Providers -->
        <div class="col-md-3 col-sm-6">
            <div class="card shadow-sm border-0 rounded-3 text-center py-4">
                <h5 class="text-success fw-bold">Total Providers</h5>
                <h2 class="fw-bold text-dark">
                    <?php 
                        $p = mysqli_query($conn, "SELECT COUNT(*) AS total FROM providers");
                        echo mysqli_fetch_assoc($p)['total'];
                    ?>
                </h2>
                <small class="text-muted">Active service providers</small>
            </div>
        </div>

        <!-- Total Bookings -->
        <div class="col-md-3 col-sm-6">
            <div class="card shadow-sm border-0 rounded-3 text-center py-4">
                <h5 class="text-success fw-bold">Total Bookings</h5>
                <h2 class="fw-bold text-dark">
                    <?php 
                        $b = mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings");
                        echo mysqli_fetch_assoc($b)['total'];
                    ?>
                </h2>
                <small class="text-muted">All bookings</small>
            </div>
        </div>

        <!-- Emergency Bookings -->
        <div class="col-md-3 col-sm-6">
            <div class="card shadow-sm border-0 rounded-3 text-center py-4">
                <h5 class="text-success fw-bold">Emergency Bookings</h5>
                <h2 class="fw-bold text-dark">
                    <?php 
                        $e = mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE booking_type='emergency'");
                        echo mysqli_fetch_assoc($e)['total'];
                    ?>
                </h2>
                <small class="text-muted">Bookings marked as emergency</small>
            </div>
        </div>

    </div>

</div>

<?php include "admin_footer.php"; ?>
