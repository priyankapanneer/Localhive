<?php 
include "admin_header.php"; 
include('../inc/db.php');
?>

<div class="container py-4">

    <!-- Page Title + Breadcrumb -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
        <div>
            <h2 class="fw-bold text-success mb-1">
                <i class="bi bi-calendar-check me-2"></i>Bookings (Normal)
            </h2>
            <p class="text-muted mb-0 small">Monitor and manage all normal bookings in one place.</p>
        </div>
        <div class="mt-2 mt-md-0">
            <button class="btn btn-outline-success btn-sm">
                <i class="bi bi-arrow-repeat me-1"></i> Refresh
            </button>
        </div>
    </div>

    <!-- Card Wrapper -->
    <div class="card shadow-sm border-0 rounded-3">

        <!-- Card Header Toolbar -->
        <div class="card-header bg-white border-0 pb-0">
            <div class="row g-2 align-items-center">
                <div class="col-md-4">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-light border-0">
                            <i class="bi bi-search text-muted"></i>
                        </span>
                        <input type="text" class="form-control border-0 shadow-none" 
                               placeholder="Search by customer, provider or service">
                    </div>
                </div>
                <div class="col-md-3">
                    <select class="form-select form-select-sm">
                        <option value="">Filter by status</option>
                        <option value="pending">Pending</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                </div>
                <div class="col-md-3 ms-auto text-md-end">
                    <span class="badge rounded-pill bg-light text-muted">
                        <i class="bi bi-info-circle me-1"></i>
                        Normal bookings overview
                    </span>
                </div>
            </div>
        </div>

        <div class="card-body">

            <?php
            $query = "
                SELECT b.id, u.name AS customer, p.name AS provider, s.title AS service,
                       b.preferred_date AS date, b.preferred_time AS time, b.status
                FROM bookings b
                JOIN users u ON b.user_id = u.id
                JOIN providers p ON b.provider_id = p.id
                JOIN services s ON b.service_id = s.id
                WHERE b.booking_type = 'normal'
                ORDER BY b.id DESC
            ";
            $bookings = mysqli_query($conn, $query);
            ?>

            <!-- Responsive Table -->
            <div class="table-responsive mt-3">
                <table class="table table-hover align-middle table-borderless mb-0">
                    <thead class="bg-success text-white">
                        <tr>
                            <th class="text-nowrap">#</th>
                            <th>Customer</th>
                            <th>Provider</th>
                            <th>Service</th>
                            <th class="text-nowrap">Date</th>
                            <th class="text-nowrap">Time</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <?php 
                        if (mysqli_num_rows($bookings) > 0) {
                            while($row = mysqli_fetch_assoc($bookings)) { 

                                $status_class = match($row['status']) {
                                    'pending'   => 'badge rounded-pill bg-warning text-dark',
                                    'completed' => 'badge rounded-pill bg-success',
                                    'cancelled' => 'badge rounded-pill bg-danger',
                                    default     => 'badge rounded-pill bg-secondary'
                                };
                        ?>
                        <tr class="border-bottom">
                            <td class="fw-semibold text-muted"><?= $row['id'] ?></td>
                            <td>
                                <div class="fw-semibold"><?= htmlspecialchars($row['customer']) ?></div>
                                <div class="text-muted small">Customer</div>
                            </td>
                            <td>
                                <div class="fw-semibold"><?= htmlspecialchars($row['provider']) ?></div>
                                <div class="text-muted small">Provider</div>
                            </td>
                            <td>
                                <div class="fw-semibold"><?= htmlspecialchars($row['service']) ?></div>
                                <div class="text-muted small">
                                    <i class="bi bi-briefcase me-1"></i>Service
                                </div>
                            </td>
                            <td class="text-nowrap">
                                <i class="bi bi-calendar-event me-1 text-muted"></i>
                                <?= $row['date'] ?>
                            </td>
                            <td class="text-nowrap">
                                <i class="bi bi-clock me-1 text-muted"></i>
                                <?= $row['time'] ?>
                            </td>
                            <td>
                                <span class="<?= $status_class ?> px-3">
                                    <?= ucfirst($row['status']) ?>
                                </span>
                            </td>
                        </tr>
                        <?php 
                            }
                        } else { 
                        ?>
                        <tr>
                            <td colspan="7" class="text-center py-5">
                                <div class="text-muted">
                                    <i class="bi bi-calendar-x display-6 d-block mb-2"></i>
                                    <span class="fw-semibold d-block">No normal bookings found</span>
                                    <span class="small">New bookings will appear here automatically.</span>
                                </div>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

<?php include "admin_footer.php"; ?>
