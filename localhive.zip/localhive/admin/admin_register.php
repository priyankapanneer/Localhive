<?php
session_start();
include('../inc/db.php');

/* -----------------------------------------------------------
   Secure Admin Registration
----------------------------------------------------------- */

$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {

    // Clean input
    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);
    $pass  = trim($_POST['password']);

    // Basic validations
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = "<div class='alert alert-danger text-center'>Invalid email format.</div>";
    } elseif (strlen($pass) < 6) {
        $msg = "<div class='alert alert-danger text-center'>Password must be at least 6 characters.</div>";
    } else {
        // Check if email exists
        $check = $conn->prepare("SELECT id FROM admins WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $checkRes = $check->get_result();

        if ($checkRes->num_rows > 0) {
            $msg = "<div class='alert alert-warning text-center'>Email already registered.</div>";
        } else {

            // Hash the password
            $hashed = password_hash($pass, PASSWORD_BCRYPT);

            // Insert admin using prepared statement
            $stmt = $conn->prepare("INSERT INTO admins (name, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $email, $hashed);

            if ($stmt->execute()) {
                $msg = "<div class='alert alert-success text-center'>Admin Registered Successfully!</div>";
            } else {
                $msg = "<div class='alert alert-danger text-center'>Error: Could not register admin.</div>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Register</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

    <style>
        body {
            background-color: #F5F5F5;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        }

        .card-custom {
            border-radius: 15px;
            background-color: #E7DEAF;
            padding: 35px;
            transition: 0.3s;
        }

        .card-custom:hover {
            transform: translateY(-7px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }

        .title {
            color: #007E6E;
            font-weight: 700;
        }

        .form-control {
            border-radius: 10px;
            padding: 10px;
        }

        .btn-custom {
            background-color: #007E6E;
            color: #E7DEAF;
            font-weight: 600;
            border-radius: 10px;
            padding: 10px;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background-color: #73AF6F !important;
            color: #fff !important;
        }

        a.custom-link {
            color: #007E6E;
            text-decoration: none;
            font-weight: 500;
        }

        a.custom-link:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
<div class="container mt-5">
    <div class="col-md-5 mx-auto card-custom shadow">

        <h3 class="text-center mb-4 title">Admin Registration</h3>

        <?= $msg ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label fw-semibold">Full Name</label>
                <input type="text" name="name" class="form-control" placeholder="Enter full name" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Email</label>
                <input type="email" name="email" class="form-control" placeholder="Enter email address" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Minimum 6 characters" required>
            </div>

            <button class="btn btn-custom w-100 mt-2" name="register">Register Admin</button>
        </form>

        <p class="text-center mt-3">
            <a href="admin_login.php" class="custom-link">Already have an account? Login</a>
        </p>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
