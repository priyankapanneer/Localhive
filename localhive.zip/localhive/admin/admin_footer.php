</body>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>LocalHive Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

<style>
    :root {
        --brand-accent: #007E6E;
        --brand-accent-light: #73AF6F;
        --brand-gold: #E7DEAF;
        --brand-gold-dark: #D7C097;
        --bg-light: #F5F5F5;
    }

    body {
        background-color: var(--bg-light);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
    }

    .wrapper {
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }

    /* CARD UI */
    .card {
        border-radius: 15px;
        background-color: var(--brand-gold);
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        transition: transform 0.2s;
    }

    .card:hover {
        transform: translateY(-5px);
    }

    /* TABLE DESIGN */
    table.table {
        border-radius: 10px;
        overflow: hidden;
    }

    table.table thead {
        background-color: var(--brand-accent);
        color: var(--brand-gold);
    }

    table.table-striped tbody tr:nth-of-type(odd) {
        background-color: var(--brand-gold-dark);
    }

    table.table-striped tbody tr:hover {
        background-color: rgba(0, 126, 110, 0.15);
        transition: 0.3s;
    }

    table.table td, 
    table.table th {
        vertical-align: middle;
        text-align: center;
    }

    /* BUTTON */
    .btn-dark {
        background-color: var(--brand-accent);
        border: none;
        transition: 0.3s;
    }

    .btn-dark:hover {
        background-color: var(--brand-accent-light);
    }

    /* BADGES */
    .badge {
        padding: 0.5em 0.8em;
        border-radius: 12px;
        font-weight: 600;
        font-size: 0.9rem;
    }

    /* HEADINGS */
    h2 {
        color: var(--brand-accent);
        margin-bottom: 20px;
    }

    hr {
        border: 2px solid var(--brand-accent-light);
        margin-bottom: 25px;
    }

    /* LIST GROUP */
    .list-group-item {
        background-color: var(--brand-gold-dark);
        color: var(--brand-accent);
        font-weight: 600;
        margin-bottom: 10px;
        border-radius: 10px;
        transition: 0.3s;
        border: none;
    }

    .list-group-item:hover {
        background-color: var(--brand-accent-light);
        color: var(--brand-gold);
    }

    /* FOOTER */
    .admin-footer {
        background-color: var(--brand-accent);
        color: var(--brand-gold);
        border-top: 3px solid var(--brand-accent-light);
        padding: 14px 0;
    }
</style>
</head>

<body>

<div class="wrapper">

    <!-- Main Content Container -->
    <div class="container flex-grow-1 mt-4">
        <!-- Page content will appear here -->
    </div>

    <!-- Single Correct Footer -->
    <footer class="admin-footer text-center mt-auto">
        <small>&copy; <?= date('Y') ?> LocalHive Admin Dashboard. All Rights Reserved.</small>
    </footer>

</div>

</body>
</html>
