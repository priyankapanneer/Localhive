<?php
// payment_disputes.php (refactored)
/**
 * Secure, improved Payment Disputes admin page.
 *
 * - Requires admin session (redirect if not logged in)
 * - Uses POST actions with CSRF protection
 * - Prepared statements for all DB updates/reads
 * - Regenerates invoice HTML safely
 * - Flash messages for success/error
 */

session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

require_once __DIR__ . '/../inc/db.php';
include 'admin_header.php';

// --- Simple flash helper ---
function flash_set($k, $v) { $_SESSION['flash'][$k] = $v; }
function flash_get_all() { $f = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $f; }

// --- CSRF token helper ---
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(20));
}
$CSRF = $_SESSION['csrf_token'];

// --- 1) Ensure table exists (safe, idempotent) ---
$create = "CREATE TABLE IF NOT EXISTS payment_disputes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    payment_id INT NULL,
    reporter_user_id INT NOT NULL,
    provider_id INT NOT NULL,
    reason TEXT,
    status ENUM('open','resolved','rejected') DEFAULT 'open',
    admin_note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
mysqli_query($conn, $create); // Ignore errors here — use migration in production

// --- 2) Handle POST actions (resolve / reject / refund / regenerate) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['dispute_id'], $_POST['csrf'])) {

    // CSRF check
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'])) {
        flash_set('error', 'Invalid request (CSRF).');
        header('Location: payment_disputes.php');
        exit();
    }

    $action = $_POST['action'];
    $disputeId = intval($_POST['dispute_id']);

    // Load dispute safely
    $stmt = $conn->prepare("SELECT * FROM payment_disputes WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $disputeId);
    $stmt->execute();
    $res = $stmt->get_result();
    $dispute = $res ? $res->fetch_assoc() : null;
    $stmt->close();

    if (!$dispute) {
        flash_set('error', 'Dispute not found.');
        header('Location: payment_disputes.php');
        exit();
    }

    // Start action handling
    if ($action === 'resolve') {
        $upd = $conn->prepare("UPDATE payment_disputes SET status='resolved', resolved_at=NOW(), admin_note=? WHERE id=?");
        $note = "Resolved by admin #" . intval($_SESSION['admin_id']);
        $upd->bind_param('si', $note, $disputeId);
        $ok = $upd->execute();
        $upd->close();
        flash_set($ok ? 'success' : 'error', $ok ? 'Dispute marked resolved.' : 'Failed to resolve dispute.');
    }

    elseif ($action === 'reject') {
        $upd = $conn->prepare("UPDATE payment_disputes SET status='rejected', resolved_at=NOW(), admin_note=? WHERE id=?");
        $note = "Rejected by admin #" . intval($_SESSION['admin_id']);
        $upd->bind_param('si', $note, $disputeId);
        $ok = $upd->execute();
        $upd->close();
        flash_set($ok ? 'success' : 'error', $ok ? 'Dispute rejected.' : 'Failed to reject dispute.');
    }

    elseif ($action === 'refund') {
        // Ensure there is a payment to refund
        if (empty($dispute['payment_id'])) {
            flash_set('error', 'No linked payment to refund.');
        } else {
            $payId = intval($dispute['payment_id']);

            // Update payments table to refunded - use prepared statement
            $updPay = $conn->prepare("UPDATE payments SET status = 'refunded' WHERE id = ?");
            $updPay->bind_param('i', $payId);
            $okPay = $updPay->execute();
            $updPay->close();

            if ($okPay) {
                $updDisp = $conn->prepare("UPDATE payment_disputes SET status='resolved', admin_note=?, resolved_at=NOW() WHERE id=?");
                $note = "Refund issued for payment #$payId by admin #" . intval($_SESSION['admin_id']);
                $updDisp->bind_param('si', $note, $disputeId);
                $okDisp = $updDisp->execute();
                $updDisp->close();

                flash_set(($okDisp && $okPay) ? 'success' : 'error', ($okDisp && $okPay) ? "Refund issued and dispute resolved." : "Refund failed to mark dispute resolved.");
            } else {
                flash_set('error', 'Failed to update payment status to refunded.');
            }
        }
    }

    elseif ($action === 'regenerate') {
        // Create invoice HTML if booking/payment exist
        if (empty($dispute['payment_id']) || empty($dispute['booking_id'])) {
            flash_set('error', 'Missing booking/payment information for invoice regeneration.');
        } else {
            $payId = intval($dispute['payment_id']);
            $bookingId = intval($dispute['booking_id']);

            // Fetch booking + service securely
            $sql = "SELECT b.id AS booking_id, b.user_id, b.provider_id, s.title, s.price
                    FROM bookings b
                    LEFT JOIN services s ON s.id = b.service_id
                    WHERE b.id = ? LIMIT 1";
            $s = $conn->prepare($sql);
            $s->bind_param('i', $bookingId);
            $s->execute();
            $bkRes = $s->get_result();
            $bk = $bkRes ? $bkRes->fetch_assoc() : null;
            $s->close();

            if (!$bk) {
                flash_set('error', 'Booking not found, cannot regenerate invoice.');
            } else {
                // customer
                $cu = $conn->prepare("SELECT name,email FROM users WHERE id = ? LIMIT 1");
                $cu->bind_param('i', $bk['user_id']);
                $cu->execute();
                $cuRes = $cu->get_result();
                $cust = $cuRes ? $cuRes->fetch_assoc() : ['name'=>'Unknown','email'=>''];
                $cu->close();

                // provider
                $pv = $conn->prepare("SELECT name FROM providers WHERE id = ? LIMIT 1");
                $pv->bind_param('i', $bk['provider_id']);
                $pv->execute();
                $pvRes = $pv->get_result();
                $prov = $pvRes ? $pvRes->fetch_assoc() : ['name'=>'Unknown'];
                $pv->close();

                $amount = floatval($bk['price'] ?? 0.0);
                $admin_fee = round($amount * 0.10, 2);
                $total = $amount; // keep same as original behaviour

                // Build invoice HTML (simple)
                $invoiceHtml = "<!doctype html>
                <html lang='en'>
                <head><meta charset='utf-8'><title>Invoice #$payId</title>
                <style>
                  body{font-family:Arial,Helvetica,sans-serif;color:#111}
                  .wrap{max-width:800px;margin:30px auto;padding:20px;border:1px solid #ddd}
                  h1{color:#007E6E}
                  table{width:100%;border-collapse:collapse;margin-top:20px}
                  th,td{padding:10px;border:1px solid #ddd;text-align:left}
                </style>
                </head><body>
                <div class='wrap'>
                  <h1>Invoice #".htmlspecialchars($payId, ENT_QUOTES)."</h1>
                  <p><strong>Date:</strong> ".date('Y-m-d H:i:s')."</p>
                  <p><strong>Customer:</strong> ".htmlspecialchars($cust['name'] ?? 'Unknown')." (".htmlspecialchars($cust['email'] ?? '').")</p>
                  <p><strong>Provider:</strong> ".htmlspecialchars($prov['name'] ?? 'Unknown')."</p>
                  <p><strong>Service:</strong> ".htmlspecialchars($bk['title'] ?? 'Service')."</p>
                  
                  <table>
                    <tr><th>Description</th><th style='width:150px'>Amount</th></tr>
                    <tr><td>Service Charge</td><td>₹".number_format($amount,2)."</td></tr>
                    <tr><td>Admin Fee (10%)</td><td>₹".number_format($admin_fee,2)."</td></tr>
                    <tr><td><strong>Total</strong></td><td><strong>₹".number_format($total,2)."</strong></td></tr>
                  </table>
                </div>
                </body></html>";

                // Save invoice
                $invoiceDir = __DIR__ . '/../exports/invoices';
                if (!is_dir($invoiceDir)) {
                    if (!mkdir($invoiceDir, 0755, true)) {
                        flash_set('error', 'Failed to create invoices directory.');
                        header('Location: payment_disputes.php');
                        exit();
                    }
                }

                $invoicePath = $invoiceDir . "/invoice_{$payId}.html";
                $wok = file_put_contents($invoicePath, $invoiceHtml);

                if ($wok !== false) {
                    flash_set('success', 'Invoice regenerated: ' . basename($invoicePath));
                } else {
                    flash_set('error', 'Failed to write invoice file.');
                }
            }
        }
    }

    // redirect back
    header('Location: payment_disputes.php');
    exit();
}

// --- 3) Fetch disputes list (prepared not needed for simple select without params) ---
$disputes_q = "
    SELECT d.*, u.name AS customer, p.name AS provider
    FROM payment_disputes d
    LEFT JOIN users u ON u.id = d.reporter_user_id
    LEFT JOIN providers p ON p.id = d.provider_id
    ORDER BY d.created_at DESC
";
$disputes = mysqli_query($conn, $disputes_q);

// --- collect flash messages ---
$flashes = flash_get_all();
?>

<!-- ===== UI ===== -->
<div class="container mt-4">
    <h2 class="mb-2" style="color:#007E6E;">Payment Disputes</h2>
    <p class="text-muted">Manage disputes, issue refunds, and regenerate invoices.</p>

    <!-- show flash messages -->
    <?php foreach ($flashes as $k => $msg): ?>
        <div class="alert alert-<?= ($k === 'error' ? 'danger' : ($k === 'success' ? 'success' : 'info')) ?>"><?= htmlspecialchars($msg) ?></div>
    <?php endforeach; ?>

    <div class="table-responsive">
        <table class="table table-hover table-bordered align-middle">
            <thead style="background:#007E6E;color:#E7DEAF;">
                <tr>
                    <th>ID</th>
                    <th>Booking</th>
                    <th>Payment</th>
                    <th>Customer</th>
                    <th>Provider</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Filed At</th>
                    <th style="min-width:260px">Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php if ($disputes && mysqli_num_rows($disputes) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($disputes)): ?>
                        <tr>
                            <td><?= intval($row['id']) ?></td>
                            <td><?= intval($row['booking_id']) ?></td>
                            <td><?= $row['payment_id'] ? intval($row['payment_id']) : 'N/A' ?></td>
                            <td><?= htmlspecialchars($row['customer'] ?? '—') ?></td>
                            <td><?= htmlspecialchars($row['provider'] ?? '—') ?></td>
                            <td style="max-width:320px;white-space:pre-wrap;"><?= nl2br(htmlspecialchars($row['reason'] ?? '')) ?></td>
                            <td>
                                <?php if ($row['status'] === 'open'): ?>
                                    <span class="badge bg-warning text-dark">Open</span>
                                <?php elseif ($row['status'] === 'resolved'): ?>
                                    <span class="badge bg-success">Resolved</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Rejected</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($row['created_at']) ?></td>
                            <td>
                                <?php if ($row['status'] === 'open'): ?>
                                    <!-- Resolve -->
                                    <form method="POST" style="display:inline-block;margin-right:6px;">
                                        <input type="hidden" name="csrf" value="<?= htmlspecialchars($CSRF) ?>">
                                        <input type="hidden" name="dispute_id" value="<?= intval($row['id']) ?>">
                                        <input type="hidden" name="action" value="resolve">
                                        <button class="btn btn-success btn-sm" type="submit">Resolve</button>
                                    </form>

                                    <!-- Refund -->
                                    <form method="POST" style="display:inline-block;margin-right:6px;">
                                        <input type="hidden" name="csrf" value="<?= htmlspecialchars($CSRF) ?>">
                                        <input type="hidden" name="dispute_id" value="<?= intval($row['id']) ?>">
                                        <input type="hidden" name="action" value="refund">
                                        <button class="btn btn-danger btn-sm" type="submit" <?= empty($row['payment_id']) ? 'disabled title="No payment linked"' : '' ?>>Refund</button>
                                    </form>

                                    <!-- Reject -->
                                    <form method="POST" style="display:inline-block;">
                                        <input type="hidden" name="csrf" value="<?= htmlspecialchars($CSRF) ?>">
                                        <input type="hidden" name="dispute_id" value="<?= intval($row['id']) ?>">
                                        <input type="hidden" name="action" value="reject">
                                        <button class="btn btn-secondary btn-sm" type="submit">Reject</button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted small">No actions</span>
                                <?php endif; ?>

                                <?php if (!empty($row['payment_id'])): ?>
                                    <form method="POST" style="display:inline-block;margin-left:6px;">
                                        <input type="hidden" name="csrf" value="<?= htmlspecialchars($CSRF) ?>">
                                        <input type="hidden" name="dispute_id" value="<?= intval($row['id']) ?>">
                                        <input type="hidden" name="action" value="regenerate">
                                        <button class="btn btn-outline-primary btn-sm" type="submit">Regenerate Invoice</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center text-muted py-4">No disputes found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
include 'admin_footer.php';
