<?php 
include "admin_header.php"; 
include('../inc/db.php');

/* -----------------------------------------------------------
   Fetch Services Securely
----------------------------------------------------------- */
$stmt = $conn->prepare("SELECT id, title, price, duration_minutes FROM services ORDER BY id DESC");
$stmt->execute();
$result = $stmt->get_result();
?>

<style>
    :root {
        --accent: #007E6E;
        --accent-light: #73AF6F;
        --warning: #D9534F;
        --warning-dark: #C03430;
        --gold: #F5C542;
        --sky: #8BD4F5;
        --cream: #F9F5E9;
    }

    .page-title {
        color: var(--accent);
        font-weight: 700;
        margin-bottom: 10px;
    }

    .divider {
        border: 2px solid var(--accent-light);
        width: 100%;
        margin-bottom: 25px;
    }

    .table-custom {
        border-radius: 12px;
        overflow: hidden;
        background: #fff;
        box-shadow: 0 6px 18px rgba(0,0,0,0.08);
    }

    .table-custom thead {
        background-color: var(--accent) !important;
        color: #E7DEAF !important;
    }

    .table-custom tbody tr:nth-child(odd) {
        background-color: var(--cream);
    }

    .table-custom tbody tr:hover {
        background-color: rgba(0,126,110,0.15);
        transition: 0.2s;
    }

    /* ---------- Buttons ---------- */
    .btn-edit {
        background-color: var(--accent);
        color: #fff;
        border-radius: 8px;
        font-weight: 600;
        padding: 6px 12px;
    }

    .btn-edit:hover {
        background-color: var(--accent-light);
        color: #fff;
    }

    .btn-delete {
        background-color: var(--warning);
        color: #fff;
        border-radius: 8px;
        font-weight: 600;
        padding: 6px 12px;
    }

    .btn-delete:hover {
        background-color: var(--warning-dark);
        color: #fff;
    }

    .btn-save {
        background-color: var(--accent);
        color: #fff;
        border-radius: 8px;
        padding: 8px 15px;
        font-weight: 700;
        box-shadow: 0 3px 8px rgba(0,0,0,0.2);
    }

    .btn-save:hover {
        background-color: var(--accent-light);
    }

    /* ---------- Badges ---------- */
    .badge-price {
        background: var(--gold) !important;
        color: #000 !important;
        padding: 6px 10px;
        border-radius: 8px;
        font-size: 0.9rem;
    }

    .badge-duration {
        background: var(--sky) !important;
        color: #000 !important;
        padding: 6px 10px;
        border-radius: 8px;
        font-size: 0.9rem;
    }
</style>

<div class="container mt-4">

    <h2 class="page-title">Manage Services</h2>
    <hr class="divider">

    <div class="table-responsive">
        <table class="table table-bordered table-custom">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Service Title</th>
                    <th>Price</th>
                    <th>Duration (mins)</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php while($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $row['id']; ?></td>

                    <td><?= htmlspecialchars($row['title'] ?: 'Untitled Service'); ?></td>

                    <td>
                        <span class="badge badge-price">
                            ₹ <?= htmlspecialchars($row['price'] ?? '0.00'); ?>
                        </span>
                    </td>

                    <td>
                        <span class="badge badge-duration">
                            <?= htmlspecialchars($row['duration_minutes'] ?? '60'); ?> mins
                        </span>
                    </td>

                    <td>
                        <a href="edit_service.php?id=<?= $row['id']; ?>" class="btn btn-edit btn-sm">Edit</a>

                        <a href="delete_service.php?id=<?= $row['id']; ?>" 
                           class="btn btn-delete btn-sm"
                           onclick="return confirm('Are you sure you want to delete this service?');">
                           Delete
                        </a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>

        </table>
    </div>

</div>

<?php include "admin_footer.php"; ?>
