<?php 
include "admin_header.php"; 
include('../inc/db.php');
?>

<style>
    .page-title {
        font-size: 26px;
        font-weight: 700;
        color: var(--brand-accent);
    }

    .report-wrapper {
        background: var(--card-bg);
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 4px 14px rgba(0,0,0,0.08);
    }

    .table thead th {
        background: var(--brand-accent);
        color: #fff;
        border: none;
        font-weight: 600;
        text-align: center;
    }

    .table tbody tr:hover {
        background: rgba(0, 126, 110, 0.08);
        transition: 0.2s;
    }

    .badge {
        padding: 6px 12px;
        font-size: 13px;
        border-radius: 30px;
        font-weight: 600;
        display: inline-block;
    }
    .badge-pending { background: #ffca2c; color: #000; }
    .badge-accepted { background: #0d6efd; color: #fff; }
    .badge-completed { background: #28a745; color: #fff; }
    .badge-rejected { background: #dc3545; color: #fff; }
    .badge-default { background: #6c757d; color: #fff; }
</style>

<div class="container mt-4">

    <h2 class="page-title mb-3">Emergency Bookings</h2>
    <hr>

    <?php
    /* 
       FIXED QUERY (NO more emergency_address)
       Using columns that REALLY exist in your database
    */
    $emergency = mysqli_query(
        $conn,
        "SELECT 
            b.id,
            u.name AS customer,
            p.name AS provider,
            s.title AS service_name,
            b.status,
            COALESCE(b.actual_arrival, b.created_at) AS booked_at
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN providers p ON b.provider_id = p.id
        JOIN services s ON b.service_id = s.id
        WHERE b.booking_type = 'emergency'
        ORDER BY booked_at DESC"
    );
    ?>

    <div class="report-wrapper mt-4">

        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Customer</th>
                        <th>Provider</th>
                        <th>Service</th>
                        <th>Location</th>
                        <th>Booked At</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if(mysqli_num_rows($emergency) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($emergency)): ?>
                            <tr>
                                <td class="text-center"><?= $row['id'] ?></td>
                                <td><?= htmlspecialchars($row['customer']) ?></td>
                                <td><?= htmlspecialchars($row['provider']) ?></td>
                                <td><?= htmlspecialchars($row['service_name']) ?></td>

                                <!-- No location column exists, so we show N/A -->
                                <td class="text-muted text-center">N/A</td>

                                <td><?= date('d M Y, H:i', strtotime($row['booked_at'])) ?></td>
                                <td class="text-center">
                                    <?php 
                                        $status = strtolower($row['status']);
                                        $badgeClass = [
                                            'pending'   => 'badge-pending',
                                            'accepted'  => 'badge-accepted',
                                            'completed' => 'badge-completed',
                                            'rejected'  => 'badge-rejected',
                                        ][$status] ?? 'badge-default';

                                        echo "<span class='badge $badgeClass'>". ucfirst($row['status']) ."</span>";
                                    ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center py-3">
                                <strong>No emergency bookings found.</strong>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>

    </div>
</div>

<?php include "admin_footer.php"; ?>
