// assets/js/ui.js
// Minimal JS for tooltips, theme toggle, and search hook (no frameworks)
document.addEventListener('DOMContentLoaded', function () {
  // Enable Bootstrap tooltips
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  tooltipTriggerList.forEach(function (el) {
    new bootstrap.Tooltip(el)
  })

  // Theme toggle (adds/removes .dark-mode on body)
  var themeToggle = document.querySelector('[data-lh-toggle-theme]')
  if(themeToggle){
    themeToggle.addEventListener('click', function(){
      document.body.classList.toggle('dark-mode')
      // Persist preference
      try{ localStorage.setItem('lh-dark', document.body.classList.contains('dark-mode') ? '1' : '0') }catch(e){}
    })
    // load preference
    try{ if(localStorage.getItem('lh-dark') === '1') document.body.classList.add('dark-mode') }catch(e){}
  }

  // Search input placeholder hook: emits a custom event for progressive enhancement
  var searchInputs = document.querySelectorAll('[data-lh-search]')
  searchInputs.forEach(function(input){
    input.addEventListener('input', function(e){
      input.dispatchEvent(new CustomEvent('lh:search', { detail: { value: input.value }}) )
    })
  })
})

/* Notification helpers (toast + modal alerts)
   Usage: window.LHNotify.toast(level, title, message)
          window.LHNotify.alert(level, title, message)
   level: 'success'|'error'|'warning'|'info'
*/
// Notification helpers removed. Use the new notification bell UI instead.
