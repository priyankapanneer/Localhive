/* ===========================
   FORM VALIDATION
=========================== */
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (form.checkValidity() === false) {
        showToast("Please fill all required fields!", "danger");
        return false;
    }
    return true;
}

/* ===========================
   TOAST NOTIFICATION
=========================== */
function showToast(message, type = "success") {
    const toastBox = document.createElement("div");
    toastBox.className = `alert alert-${type} custom-toast`;
    toastBox.innerHTML = message;

    document.body.appendChild(toastBox);

    setTimeout(() => {
        toastBox.style.opacity = "0";
        setTimeout(() => toastBox.remove(), 500);
    }, 2000);
}

/* ===========================
   CONFIRM DELETE MODAL
=========================== */
function confirmDelete(url) {
    if (confirm("Are you sure you want to delete this item?")) {
        window.location.href = url;
    }
}

/* ===========================
   EMERGENCY BADGE HANDLER
=========================== */
function markEmergency(id) {
    document.getElementById(id).innerHTML = 
        '<span class="badge bg-danger">Emergency</span>';
}

/* ===========================
   AJAX LOADER (Optional)
=========================== */
function showLoader() {
    document.body.innerHTML += `
        <div id="loader-overlay">
            <div class="spinner-border text-primary"></div>
        </div>
    `;
}

function hideLoader() {
    const loader = document.getElementById("loader-overlay");
    if (loader) loader.remove();
}
