// assets/js/notifications.js
// Small script to populate .lh-bell elements by calling /inc/fetch_updates.php
(function(){
  if (window.__lhNotificationsInit) return; window.__lhNotificationsInit = true;
  var endpoint = '/localhive/inc/fetch_updates.php';

  function renderItem(u){
    var item = document.createElement('div');
    item.className = 'lh-bell-item py-2';
    var title = document.createElement('div'); title.style.fontWeight = '700'; title.textContent = u.title || '';
    var msg = document.createElement('div'); msg.className = 'small text-muted'; msg.textContent = u.message || '';
    var link = document.createElement('a'); link.href = u.link || '#'; link.className = 'stretched-link';
    item.appendChild(title); item.appendChild(msg); item.appendChild(link);
    return item;
  }

  function updateAll(){
    fetch(endpoint, { credentials: 'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(json){
        if (!json || !json.ok) return;
        var lists = document.querySelectorAll('.lh-bell');
        lists.forEach(function(btn){
          var parent = btn.closest('.dropdown');
          var badge = btn.querySelector('.lh-bell-count') || parent.querySelector('.lh-bell-count');
          var dropdown = parent.querySelector('.lh-bell-dropdown');
          if (json.count && json.count > 0){
            if(badge){ badge.style.display = 'inline-block'; badge.textContent = json.count; }
          } else { if(badge) badge.style.display = 'none'; }
          if (dropdown){
            dropdown.innerHTML = '';
            if (json.updates && json.updates.length){
              json.updates.forEach(function(u){
                var node = renderItem(u);
                dropdown.appendChild(node);
              });
              var more = document.createElement('div'); more.className = 'text-center mt-2';
              more.innerHTML = '<a href="#" class="small">View all</a>';
              dropdown.appendChild(more);
            } else {
              dropdown.innerHTML = '<div class="text-muted small">No recent updates</div>';
            }
          }
        });
      }).catch(function(e){
        // silently ignore
        console.debug('fetch updates failed', e);
      });
  }

  document.addEventListener('DOMContentLoaded', function(){
    updateAll();
    // Poll every 30s
    setInterval(updateAll, 30000);
  });
})();
