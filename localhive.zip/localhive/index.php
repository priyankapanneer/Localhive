<?php
// index.php
// Home page — dynamic Popular Services, autoplay carousels, palette, no inline style

include "inc/db.php";

// Fetch top 4 services by bookings count (works with your schema)
$services_q = "
    SELECT s.*, IFNULL(COUNT(b.id),0) AS bookings_count
    FROM services s
    LEFT JOIN bookings b ON b.service_id = s.id
    GROUP BY s.id
    ORDER BY bookings_count DESC, s.id DESC
    LIMIT 4
";
$services = mysqli_query($conn, $services_q);

// Optional: hero asset fallback check (if file doesn't exist we'll rely on CSS background)
$hero_video = 'assets/videos/hero.mp4';
$hero_video_exists = file_exists(__DIR__ . '/' . $hero_video);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>LocalHive – Local Service Marketplace</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
<style>
  /* ===========================
     Palette & variables
     =========================== */
  :root{
    --brand: #007E6E;
    --brand-2: #73AF6F;
    --accent: #E7DEAF;
    --muted: #D7C097;
    --bg: #F5F5F5;
    --text: #0b3a36;
    --glass: rgba(255,255,255,0.75);
    --nav-blur: rgba(11,58,54,0.6);
    --card-shadow: 0 8px 24px rgba(11,58,54,0.08);
    --card-hover: 0 16px 40px rgba(11,58,54,0.12);
    --radius-lg: 14px;
    --radius-md: 10px;
    --radius-sm: 8px;
    --max-width: 1200px;
    font-family: 'Inter', system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
  }

  /* Global */
  html,body { height:100%; }
  body {
    background: var(--bg);
    color: var(--text);
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale;
    line-height:1.45;
    margin:0;
  }
  .container { max-width:var(--max-width) }

  a { color: var(--brand); text-decoration:none; }
  a:hover { text-decoration:underline; }

  /* NAVBAR */
  .navbar-brand { font-weight:700; letter-spacing:0.2px; }
  .brand-bg { background: linear-gradient(90deg,var(--brand), #006754); }
  .navbar { transition: all .28s ease; }
  .navbar.sticky-scrolled { backdrop-filter: blur(6px); background: linear-gradient(180deg, rgba(0,0,0,0.08), rgba(0,0,0,0)); padding-top:.25rem; padding-bottom:.25rem; transform: translateZ(0); }
  .navbar .nav-link { color: rgba(255,255,255,0.95); margin-left:.6rem; margin-right:.6rem; }
  .nav-cta { border-radius:999px; padding:.45rem .9rem; font-weight:600; box-shadow: 0 6px 18px rgba(0,0,0,0.12); }
  .btn-ghost { background: transparent; border: 1px solid rgba(255,255,255,0.12); color: #fff; }
  .btn-cta { background: linear-gradient(90deg,var(--brand),var(--brand-2)); color: #fff; border:none; border-radius:999px; padding:.6rem 1.05rem; box-shadow: 0 10px 30px rgba(11,58,54,0.12); transition: transform .16s ease, box-shadow .16s ease; }
  .btn-cta:hover{ transform: translateY(-3px); box-shadow: var(--card-hover); }

  /* HERO */
  .hero-full {
    position:relative;
    min-height: calc(100vh - 72px);
    overflow:hidden;
    display:flex;
    align-items:center;
    color: white;
  }
  .hero-media {
    position:absolute; inset:0; width:100%; height:100%; object-fit:cover; z-index:0;
    filter: saturate(.95) contrast(.95) brightness(.6);
  }
  .hero-overlay { position:absolute; inset:0; background: linear-gradient(180deg, rgba(0,126,110,0.35), rgba(7,45,40,0.5)); z-index:1; }
  .hero-inner { position:relative; z-index:2; padding:4rem 0; }
  .headline { font-size: clamp(1.6rem, 3.8vw, 2.8rem); line-height:1.05; font-weight:800; margin-bottom:.5rem; color: #fff; }
  .headline .shimmer {
    color: #fff;
    display:inline-block;
    background: linear-gradient(90deg, rgba(255,255,255,0.2), rgba(255,255,255,0.9), rgba(255,255,255,0.2));
    -webkit-background-clip: text;
    background-clip:text;
    animation: shimmer 2.8s infinite linear;
    font-weight:800;
  }
  @keyframes shimmer {
    0% { background-position: -120% 0; }
    100% { background-position: 220% 0; }
  }

  .hero-sub { color: rgba(255,255,255,0.9); font-size:1.05rem; margin-bottom:1.25rem; max-width: 60ch; }

  /* Right-side lottie card */
  .hero-visual {
    background: linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02));
    border-radius: 18px;
    padding: 1.2rem;
    display:inline-block;
    box-shadow: var(--card-shadow);
    border: 1px solid rgba(255,255,255,0.06);
  }

  .trusted-strip {
    display:inline-flex;
    gap:.6rem;
    margin-top:1rem;
    padding:.35rem .5rem;
    background: rgba(255,255,255,0.06);
    border-radius:999px;
    align-items:center;
  }
  .trusted-strip span { font-weight:600; font-size:.9rem; opacity:.95; color:#fff; }

  /* floating badges */
  .float-badges { position:absolute; right:6%; top:30%; display:flex; flex-direction:column; gap:.65rem; z-index:3; }
  .float-badge {
    background: linear-gradient(180deg, rgba(255,255,255,0.95), rgba(255,255,255,0.9));
    color: var(--brand);
    padding:.45rem .6rem;
    border-radius:999px;
    font-weight:700;
    box-shadow: 0 6px 20px rgba(0,0,0,0.08);
    display:flex; gap:.6rem; align-items:center; min-width:140px;
  }
  .float-badge i { color: var(--brand-2); }

  /* ROLES CARDS */
  .login-card {
    background: #fff;
    border-radius: var(--radius-lg);
    padding:1.6rem;
    box-shadow: var(--card-shadow);
    transition: transform .18s ease, box-shadow .18s ease;
    text-align:center;
  }
  .login-card:hover { transform: translateY(-8px); box-shadow: var(--card-hover); }
  .icon-wrap { width:64px;height:64px;border-radius:20px;background:linear-gradient(180deg,var(--accent),var(--muted)); margin:0 auto 0.6rem; display:flex; align-items:center; justify-content:center; font-size:1.3rem; color:var(--brand); }
  .login-card h5 { margin-top:.6rem; margin-bottom:.35rem; font-weight:700; }
  .chip { display:inline-block; padding:.18rem .55rem; border-radius:999px; background:rgba(0,0,0,0.04); font-size:.78rem; margin-bottom:.6rem; color:var(--text); }

  .btn-outline-brand { border:1px solid var(--brand); color:var(--brand); background:transparent; border-radius:999px; padding:.35rem .6rem; }
  .btn-sm-cta { padding:.4rem .7rem; border-radius:999px; }

  /* WHY FEATURE SLIDE */
  .carousel-with-progress { position:relative; }
  .carousel-progress { position:absolute; left:1rem; right:1rem; top: -8px; height:6px; background: rgba(255,255,255,0.06); border-radius:999px; overflow:hidden; }
  .carousel-progress-bar { height:100%; width:0%; background: linear-gradient(90deg,var(--brand),var(--brand-2)); border-radius:999px; box-shadow:0 6px 20px rgba(7,45,40,0.12); }
  .feature-slide { display:flex; gap:1rem; justify-content:space-between; flex-wrap:wrap; }
  .feature-card { flex:1 1 30%; background:#fff; padding:1rem; border-radius:12px; box-shadow:var(--card-shadow); min-width:200px; }
  .feature-card h5 { color: var(--brand); font-weight:700; margin-bottom:.35rem; }

  /* SERVICES GRID */
  .services-grid { display:grid; grid-template-columns: repeat(auto-fit,minmax(220px,1fr)); gap:18px; }
  .service-card { background: #fff; border-radius:14px; padding:1.1rem; box-shadow: var(--card-shadow); transition: transform .18s ease, box-shadow .18s ease, background .18s ease; display:flex; flex-direction:column; justify-content:space-between; }
  .service-card:hover { transform: translateY(-8px) scale(1.01); box-shadow: var(--card-hover); background: linear-gradient(180deg, #ffffff, #fbfbf9); }
  .service-icon { width:56px;height:56px;border-radius:12px;background: linear-gradient(180deg,var(--muted),var(--accent)); display:flex; align-items:center; justify-content:center; font-size:1.2rem; color:var(--brand); }
  .service-card h6 { margin-top:.6rem; margin-bottom:.4rem; font-weight:700; }
  .service-card p { color:#4b4b4b; font-size:.95rem; min-height:48px; }
  .meta { font-size:.85rem; color:#6b6b6b; margin-top:.5rem; }

  /* Testimonials */
  .testimonial-card { background:#fff; padding:1.1rem; border-radius:12px; box-shadow: var(--card-shadow); max-width:520px; margin:0 auto; position:relative; }
  .testimonial-avatar { width:64px;height:64px;border-radius:50%; border:3px solid var(--brand-2); margin:0 auto 0.5rem; display:block; }
  .testimonial-stars { color: #f6b21d; margin-bottom:.6rem; }
  .testimonial-quote { font-style:italic; color:#333; margin-bottom:.5rem; }
  .testimonial-author { font-weight:700; color:#0b3a36; }

  /* HOW IT WORKS */
  .steps { display:flex; gap:1rem; align-items:center; justify-content:space-between; flex-wrap:wrap; }
  .step { background:#fff; padding:1rem; border-radius:12px; box-shadow:var(--card-shadow); flex:1 1 30%; text-align:center; }
  .step .num { font-weight:800; background:linear-gradient(90deg,var(--brand),var(--brand-2)); color:#fff; width:56px;height:56px;border-radius:999px; display:inline-flex; align-items:center; justify-content:center; font-size:1.05rem; margin-bottom:.6rem; }

  /* FAQ */
  .faq .accordion-button { background:#fff; border-radius:8px; box-shadow:var(--card-shadow); color:var(--text); }

  /* CTA band */
  .cta-band { background: linear-gradient(90deg,var(--brand),var(--brand-2)); color:#fff; padding:1.1rem; border-radius:12px; display:flex; align-items:center; justify-content:space-between; gap:1rem; box-shadow: var(--card-hover); }

  /* Footer */
  .site-footer { background: linear-gradient(180deg,var(--brand), #055348); color: #fff; padding-top:2.4rem; padding-bottom:2.4rem; margin-top:3rem; }
  .site-footer h5 { color:#fff; }
  .newsletter-input input { border-radius:999px 0 0 999px; padding:.6rem .9rem; border: none; outline:none; }
  .newsletter-input button { border-radius:0 999px 999px 0; padding:.55rem 1rem; border:none; background: #fff; color: var(--brand); font-weight:700; }

  /* Utility & responsive */
  .text-muted { color: rgba(255,255,255,0.8); }
  @media (max-width:991px){
    .hero-inner .col-lg-5 { display:none; }
    .float-badges { display:none; }
    .feature-slide { flex-direction:column; }
    .carousel-progress { top:0; }
  }
  @media (max-width:575px){
    .headline { font-size: 1.6rem; }
    .services-grid { grid-template-columns: 1fr; }
    .feature-card { min-width: unset; }
    .hero-full { min-height: 66vh; padding-top: 2rem; padding-bottom: 2rem; }
  }

  /* Reveal animation */
  .reveal { opacity:0; transform: translateY(16px); transition: opacity .6s ease, transform .6s ease; }
  .reveal.in-view { opacity:1; transform: translateY(0); }

  /* small tweaks */
  .footer-sep { border-color: rgba(255,255,255,0.12) !important; margin-top:1rem; margin-bottom:1rem; }

</style>
</head>
<body class="admin-theme">

<!-- NAV -->
<nav class="navbar navbar-expand-lg brand-bg shadow-sm fixed-top" id="mainNavbar" role="navigation" aria-label="Main navigation">
  <div class="container">
    <a class="navbar-brand text-white fw-bold" href="#">LocalHive</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav ms-auto align-items-lg-center">
        <li class="nav-item"><a class="nav-link text-white" href="#roles">Get Started</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="#why">Why LocalHive</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="#popular">Popular</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="customer/login.php">Sign In</a></li>
        <li class="nav-item ms-2"><a class="btn btn-cta nav-cta" href="customer/register.php">Get Started</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- spacer to account for fixed nav -->
<div style="height:72px;"></div>

<!-- HERO -->
<section class="hero-full reveal" id="hero" aria-label="Hero">
  <?php if($hero_video_exists): ?>
    <video class="hero-media" autoplay muted loop playsinline poster="assets/images/hero-bg.jpg" aria-hidden="true">
      <source src="<?php echo $hero_video; ?>" type="video/mp4">
    </video>
  <?php else: ?>
    <!-- fallback gradient background handled via CSS overlay -->
  <?php endif; ?>

  <div class="hero-overlay" aria-hidden="true"></div>

  <div class="container hero-inner">
    <div class="row align-items-center">
      <div class="col-lg-7">
        <div class="reveal">
          <h1 class="headline">Local services that <span class="shimmer">show up</span> when you need them</h1>
          <p class="hero-sub">Find verified professionals in your area, book instantly, and manage appointments with confidence. LocalHive connects you with trusted local providers — fast.</p>

          <div class="d-flex align-items-center gap-3">
            <a href="customer/register.php" class="btn btn-cta btn-lg me-2" role="button" aria-label="Get started">Get Started</a>
            <a href="customer/login.php" class="btn btn-ghost btn-lg" role="button" aria-label="Browse services">Browse Services</a>
          </div>

          <div class="trusted-strip mt-4" aria-hidden="true">
            <span>Trusted by</span>
            <span style="opacity:.95; font-weight:600;">NeighbourCo</span>
            <span style="opacity:.9;">QuickFix</span>
            <span style="opacity:.9;">HomePro</span>
          </div>
        </div>
      </div>

      <div class="col-lg-5 d-none d-lg-block text-center">
        <div class="hero-visual reveal" role="img" aria-label="Illustration">
          <lottie-player src="https://assets7.lottiefiles.com/packages/lf20_jcikwtux.json"  background="transparent"  speed="1"  style="width:320px;height:320px;"  loop  autoplay aria-hidden="true"></lottie-player>
        </div>
      </div>
    </div>
  </div>

  <!-- floating badges -->
  <div class="float-badges" aria-hidden="true">
    <div class="float-badge"><i class="fas fa-star"></i> 4.8★ Avg</div>
    <div class="float-badge"><i class="fas fa-check-circle"></i> 10k+ Bookings</div>
    <div class="float-badge"><i class="fas fa-map-marker-alt"></i> 200+ Areas</div>
  </div>

  <div class="wave-divider" aria-hidden="true">
    <svg viewBox="0 0 1200 120" preserveAspectRatio="none" style="display:block;"><path d="M0,0 C300,100 900,0 1200,80 L1200,120 L0,120 Z" fill="var(--brand)"></path></svg>
  </div>
</section>

<!-- ROLES -->
<section id="roles" class="py-5">
  <div class="container reveal">
    <div class="row g-4 justify-content-center">
      <div class="col-md-4">
        <div class="login-card" role="region" aria-label="Customer">
          <div class="chip">For homeowners</div>
          <div class="icon-wrap"><i class="fas fa-user"></i></div>
          <h5>Customer</h5>
          <p>Book trusted local services in your area easily and quickly.</p>
          <div class="mt-3">
            <a href="customer/login.php" class="btn btn-outline-brand btn-sm-cta" aria-label="Customer login">Login</a>
            <a href="customer/register.php" class="btn btn-cta btn-sm ms-2" aria-label="Customer signup">Sign Up</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="login-card" role="region" aria-label="Provider">
          <div class="chip">For professionals</div>
          <div class="icon-wrap"><i class="fas fa-tools"></i></div>
          <h5>Provider</h5>
          <p>Manage your services, connect with customers, and grow your business.</p>
          <div class="mt-3">
            <a href="provider/provider_login.php" class="btn btn-outline-brand btn-sm-cta" aria-label="Provider login">Login</a>
            <a href="provider/provider_register.php" class="btn btn-cta btn-sm ms-2" aria-label="Provider register">Register</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="login-card" role="region" aria-label="Admin">
          <div class="chip">For platform admins</div>
          <div class="icon-wrap"><i class="fas fa-cogs"></i></div>
          <h5>Admin</h5>
          <p>Monitor and manage all operations of the LocalHive platform seamlessly.</p>
          <div class="mt-3">
            <a href="admin/admin_login.php" class="btn btn-outline-brand btn-sm-cta" aria-label="Admin login">Login</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- WHY LOCALHIVE -->
<section id="why" class="py-5 bg-transparent">
  <div class="container reveal">
    <div class="text-center mb-4">
      <h3 class="brand-text">Why LocalHive?</h3>
      <p class="text-muted">A smarter way to find and manage local services — fast, reliable, and nearby.</p>
    </div>

    <div id="whyCarousel" class="carousel slide carousel-with-progress" data-bs-ride="carousel" aria-label="Why LocalHive carousel">
      <div class="carousel-progress" aria-hidden="true"><div class="carousel-progress-bar"></div></div>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <div class="feature-slide">
            <div class="feature-card" aria-hidden="false">
              <h5><i class="fas fa-shield-alt me-2 text-success"></i>Verified Providers</h5>
              <p>We screen and verify local service providers so you can hire with confidence.</p>
            </div>
            <div class="feature-card">
              <h5><i class="fas fa-bolt me-2 text-success"></i>Fast Booking</h5>
              <p>Quick booking flow and instant confirmations save you time.</p>
            </div>
            <div class="feature-card">
              <h5><i class="fas fa-map-marker-alt me-2 text-success"></i>Local Coverage</h5>
              <p>Search by pincode to find providers close to your home or business.</p>
            </div>
          </div>
        </div>

        <div class="carousel-item">
          <div class="feature-slide">
            <div class="feature-card">
              <h5><i class="fas fa-thumbs-up me-2 text-success"></i>Quality Guarantee</h5>
              <p>Ratings and reviews help ensure quality service every time.</p>
            </div>
            <div class="feature-card">
              <h5><i class="fas fa-wallet me-2 text-success"></i>Secure Payments</h5>
              <p>Multiple payment options with secure handling and receipts.</p>
            </div>
            <div class="feature-card">
              <h5><i class="fas fa-headset me-2 text-success"></i>24/7 Support</h5>
              <p>Our support team is ready to help with bookings and disputes.</p>
            </div>
          </div>
        </div>
      </div>

      <button class="carousel-control-prev" type="button" data-bs-target="#whyCarousel" data-bs-slide="prev" aria-label="Previous">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#whyCarousel" data-bs-slide="next" aria-label="Next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
      </button>
    </div>
  </div>
</section>

<!-- POPULAR SERVICES (dynamic) -->
<section id="popular" class="py-4">
  <div class="container reveal">
    <div class="text-center mb-3">
      <h3 class="brand-text">Popular Services</h3>
      <p class="text-muted">Quickly find what most users are booking.</p>
    </div>

    <div class="services-grid" role="list">
      <?php if($services && mysqli_num_rows($services)>0): ?>
        <?php $first=true; while($s = mysqli_fetch_assoc($services)): ?>
          <div class="service-card" role="listitem" tabindex="0" aria-label="<?php echo htmlspecialchars($s['title']); ?>">
            <div style="display:flex; justify-content:space-between; align-items:flex-start;">
              <div class="service-icon"><i class="fas fa-tools"></i></div>
              <?php if($first): ?>
                <div style="background:var(--brand-2); color:#fff; padding:.25rem .6rem; border-radius:8px; font-weight:700; font-size:.8rem;">Top booked</div>
              <?php endif; ?>
            </div>

            <div>
              <h6><?php echo htmlspecialchars(isset($s['title']) ? $s['title'] : ($s['service_name'] ?? 'Service')); ?></h6>
              <p><?php echo htmlspecialchars($s['description'] ? mb_substr($s['description'],0,120) : '—'); ?></p>
            </div>

            <div>
              <div class="meta small text-muted">₹ <?php echo number_format($s['price'],2); ?> • Bookings: <?php echo intval($s['bookings_count']); ?></div>
              <div style="margin-top:.6rem; display:flex; gap:.5rem; flex-wrap:wrap;">
                <span class="chip">Home</span>
                <span class="chip">Electrical</span>
                <span class="chip">Popular</span>
              </div>

              <div class="mt-3 d-flex justify-content-between align-items-center">
                <a href="customer/login.php" class="btn btn-outline-brand" aria-label="Explore <?php echo htmlspecialchars($s['title']); ?>">Explore</a>
                <a class="text-muted small" href="#" aria-hidden="true">View details</a>
              </div>
            </div>
          </div>
        <?php $first=false; endwhile; ?>
      <?php else: ?>
        <div class="text-center">No services available yet.</div>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- HOW IT WORKS -->
<section class="py-5">
  <div class="container reveal">
    <div class="text-center mb-4">
      <h3 class="brand-text">How LocalHive works</h3>
      <p class="text-muted">Three steps to get service done, fast.</p>
    </div>

    <div class="steps">
      <div class="step">
        <div class="num">1</div>
        <h5>Search by pincode</h5>
        <p>Enter your area and discover nearby providers with verified profiles.</p>
      </div>
      <div class="step">
        <div class="num">2</div>
        <h5>Compare providers</h5>
        <p>See ratings, prices, and past jobs to pick the best fit for your needs.</p>
      </div>
      <div class="step">
        <div class="num">3</div>
        <h5>Book & track</h5>
        <p>Book, pay securely, and track provider arrival in-app — all in one place.</p>
      </div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="py-5 bg-transparent">
  <div class="container reveal">
    <div class="text-center mb-4"><h3 class="brand-text">What customers say</h3></div>
    <div id="testimonials" class="carousel slide carousel-with-progress" data-bs-ride="carousel" aria-label="Customer testimonials">
      <div class="carousel-progress" aria-hidden="true"><div class="carousel-progress-bar"></div></div>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <div class="testimonial-card text-center">
            <img class="testimonial-avatar" src="https://ui-avatars.com/api/?name=Priya+K&background=FFFFFF&color=007E6E" alt="Priya avatar">
            <div class="testimonial-stars"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i></div>
            <div class="testimonial-quote">"Great experience — my plumber arrived on time and fixed the issue quickly. Highly recommended!"</div>
            <div class="testimonial-author">— Priya K., Homeowner</div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="testimonial-card text-center">
            <img class="testimonial-avatar" src="https://ui-avatars.com/api/?name=Amit+R&background=FFFFFF&color=007E6E" alt="Amit avatar">
            <div class="testimonial-stars"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
            <div class="testimonial-quote">"Easy to use, and the providers are reliable. The dashboard makes managing bookings a breeze."</div>
            <div class="testimonial-author">— Amit R., Small Business</div>
          </div>
        </div>
      </div>

      <button class="carousel-control-prev" type="button" data-bs-target="#testimonials" data-bs-slide="prev" aria-label="Previous">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#testimonials" data-bs-slide="next" aria-label="Next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
      </button>
    </div>
  </div>
</section>

<!-- FAQ -->
<section class="py-5">
  <div class="container reveal">
    <div class="text-center mb-4"><h3 class="brand-text">Frequently asked questions</h3></div>
    <div class="accordion faq" id="faqAccordion">
      <div class="accordion-item mb-3">
        <h2 class="accordion-header" id="faqOne">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">How do you verify providers?</button>
        </h2>
        <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="faqOne" data-bs-parent="#faqAccordion">
          <div class="accordion-body">We perform profile checks, ID verification, and review provider history before approval.</div>
        </div>
      </div>

      <div class="accordion-item mb-3">
        <h2 class="accordion-header" id="faqTwo">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false">Do you support emergency bookings?</button>
        </h2>
        <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="faqTwo" data-bs-parent="#faqAccordion">
          <div class="accordion-body">Yes — choose 'Emergency' during booking; nearby providers will be prioritized for acceptance.</div>
        </div>
      </div>

      <div class="accordion-item mb-3">
        <h2 class="accordion-header" id="faqThree">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false">How are payments handled?</button>
        </h2>
        <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="faqThree" data-bs-parent="#faqAccordion">
          <div class="accordion-body">Payments are securely recorded in our payments table. We support multiple gateways (configurable by admin).</div>
        </div>
      </div>

      <div class="accordion-item mb-3">
        <h2 class="accordion-header" id="faqFour">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false">Can I get invoices?</button>
        </h2>
        <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="faqFour" data-bs-parent="#faqAccordion">
          <div class="accordion-body">Yes — admin and providers can generate simple HTML invoices which can be saved as PDF from the browser.</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA BAND -->
<section class="py-4">
  <div class="container reveal">
    <div class="cta-band">
      <div>
        <h4 style="margin:0;">Ready to get started with LocalHive?</h4>
        <div style="opacity:.95;">Find a trusted local provider in minutes.</div>
      </div>
      <div style="display:flex; gap:.6rem;">
        <a href="customer/register.php" class="btn btn-light" style="font-weight:700; border-radius:999px;">Get started</a>
        <a href="mailto:hello@localhive.example" class="btn btn-outline-light" style="border-radius:999px;">Talk to us</a>
      </div>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="site-footer admin-footer" role="contentinfo">
  <div class="container">
    <div class="row footer-columns">
      <div class="col-md-4">
        <h5>LocalHive</h5>
        <p style="max-width:260px;color:rgba(255,255,255,0.95)">Trusted local services — verified providers, secure transactions, and easy booking in your neighborhood.</p>
      </div>
      <div class="col-md-2">
        <h5>Company</h5>
        <ul class="list-unstyled">
          <li><a href="#" class="text-white">About</a></li>
          <li><a href="#" class="text-white">Careers</a></li>
          <li><a href="#" class="text-white">Blog</a></li>
        </ul>
      </div>
      <div class="col-md-2">
        <h5>Support</h5>
        <ul class="list-unstyled">
          <li><a href="#" class="text-white">Help Center</a></li>
          <li><a href="#" class="text-white">Contact</a></li>
          <li><a href="#" class="text-white">Safety</a></li>
        </ul>
      </div>
      <div class="col-md-4">
        <h5>Newsletter</h5>
        <p style="color:rgba(255,255,255,0.8)">Get updates and offers</p>
        <form class="newsletter-input d-flex" action="#" method="post" onsubmit="alert('Thanks! (form disabled in demo)'); return false;" aria-label="Subscribe to newsletter">
          <input type="email" placeholder="you@example.com" aria-label="Email address" required>
          <button type="submit" aria-label="Subscribe">Subscribe</button>
        </form>
      </div>
    </div>

    <hr class="footer-sep">

    <div class="d-flex justify-content-between align-items-center">
      <div>&copy; <?php echo date('Y'); ?> LocalHive. All rights reserved. &nbsp; <a href="#" class="text-white">Terms</a> • <a href="#" class="text-white">Privacy</a></div>
      <div>
        <a href="#" class="text-white me-3" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
        <a href="#" class="text-white me-3" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
        <a href="#" class="text-white" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
      </div>
    </div>
  </div>
</footer>

<!-- scripts -->
<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
/* Navbar shrink on scroll */
const navbar = document.getElementById('mainNavbar');
const hero = document.getElementById('hero');
window.addEventListener('scroll', ()=> {
  if (window.scrollY > 40) { navbar.classList.add('sticky-scrolled'); }
  else { navbar.classList.remove('sticky-scrolled'); }
});

/* Carousel progress bar logic (used for both carousels) */
document.querySelectorAll('.carousel-with-progress').forEach(function(carouselEl){
  const carousel = new bootstrap.Carousel(carouselEl, { interval: 4000, ride: 'carousel', pause: 'hover' });
  const progressBar = carouselEl.querySelector('.carousel-progress-bar');

  function startProgress() {
    if(!progressBar) return;
    // reset
    progressBar.style.transition = 'none';
    progressBar.style.width = '0%';
    // allow reflow
    requestAnimationFrame(()=> {
      requestAnimationFrame(()=> {
        progressBar.style.transition = 'width 4s linear';
        progressBar.style.width = '100%';
      });
    });
  }

  startProgress();
  carouselEl.addEventListener('slid.bs.carousel', startProgress);

  carouselEl.addEventListener('mouseenter', ()=> {
    // pause CSS transition
    if(progressBar) progressBar.style.transitionPlayState = 'paused';
  });
  carouselEl.addEventListener('mouseleave', ()=> {
    if(progressBar) progressBar.style.transitionPlayState = 'running';
  });
});

/* Parallax subtle */
if(hero){
  window.addEventListener('scroll', ()=> {
    const sc = window.scrollY;
    hero.style.backgroundPosition = `center ${Math.max(-30, -sc * 0.12)}px`;
  });
}

/* Reveal on scroll */
const reveals = document.querySelectorAll('.reveal');
const io = new IntersectionObserver((entries)=> {
  entries.forEach(entry => {
    if(entry.isIntersecting) {
      entry.target.classList.add('in-view');
      io.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
reveals.forEach(r => io.observe(r));

/* Accessibility: allow keyboard focus to show hover-like elevation */
document.querySelectorAll('.service-card, .login-card, .testimonial-card').forEach(el=>{
  el.addEventListener('focus', ()=> el.classList.add('focus-visible'));
  el.addEventListener('blur', ()=> el.classList.remove('focus-visible'));
});
</script>

</body>
</html>
