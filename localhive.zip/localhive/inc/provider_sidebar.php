<?php
// Provider sidebar include - outputs sidebar and opens main-content
?>
<div class="sidebar">
    <h4>Provider</h4>
    <a href="/localhive/provider/provider_dashboard.php">Dashboard</a>
    <a href="/localhive/provider/manage_services.php">Manage Services</a>
    <a href="/localhive/provider/provider_bookings.php">Bookings</a>
    <a href="/localhive/provider/provider_download_reports.php">Reports</a>
    <a href="/localhive/provider/provider_logout.php" class="logout">Logout</a>
</div>
<div class="main-content">
