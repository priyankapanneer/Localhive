<?php
// Gateway configuration - DO NOT commit real secrets. Set via environment or edit locally.
// Recommended: set these in Apache or your system environment instead of committing.

// Gateway configuration removed: this installation does not include external
// payment gateway constants by default. If you re-enable a gateway later,
// add credentials using your environment or a local config file.

// Helper: log gateway events
function gateway_log($line){
    $logDir = __DIR__ . '/../logs';
    if (!is_dir($logDir)) mkdir($logDir,0755,true);
    $file = $logDir . '/payment_gateway.log';
    file_put_contents($file, date('Y-m-d H:i:s') . " | " . $line . "\n", FILE_APPEND | LOCK_EX);
}

?>