<?php
// inc/components/header.php
// Usage: include_once __DIR__.'/components/header.php';
// Loads Bootstrap 5, Bootstrap Icons, site styles, and sets SITE_ROOT constant.

if(!defined('LH_SITE_ROOT')){
    define('LH_SITE_ROOT', rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/'));
}

?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= isset($page_title) ? htmlspecialchars($page_title) . ' - LocalHive' : 'LocalHive' ?></title>

  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">

  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <!-- Design system -->
  <link rel="stylesheet" href="<?= LH_SITE_ROOT ?>/assets/css/variables.css">
  <link rel="stylesheet" href="<?= LH_SITE_ROOT ?>/assets/css/components.css">
  <!-- Serif refined theme (typography, spacing, tables, badges) -->
  <link rel="stylesheet" href="<?= LH_SITE_ROOT ?>/assets/css/serif_theme.css">

  <!-- SweetAlert2 (for elegant modal notifications) -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js" defer></script>

  <!-- App JS (defer) -->
  <script defer src="<?= LH_SITE_ROOT ?>/assets/js/ui.js"></script>

  <!-- Notification bridge: if server set a session notification, emit it to LHNotify on DOM ready -->
  <!-- Notification bridge removed: a unified bell UI is used instead -->

  <?php if(!empty($extra_head)) echo $extra_head; ?>
</head>
<body class="<?= isset($body_class) ? htmlspecialchars($body_class) : '' ?>">
<?php
// optional top navbar can be included after this file
?>
