<?php
// inc/components/sidebar.php
// $area can be 'admin'|'provider'|'customer' to switch menus.
if(!isset($area)) $area = 'admin';

$menus = [
  'admin' => [
    ['href'=>'admin_dashboard.php','icon'=>'bi-speedometer2','label'=>'Dashboard'],
    ['href'=>'admin_customers.php','icon'=>'bi-people','label'=>'Customers'],
    ['href'=>'admin_providers.php','icon'=>'bi-person-badge','label'=>'Providers'],
    ['href'=>'admin_services.php','icon'=>'bi-list-task','label'=>'Services'],
    ['href'=>'admin_bookings.php','icon'=>'bi-calendar-check','label'=>'Bookings'],
    ['href'=>'admin_download_reports.php','icon'=>'bi-download','label'=>'Reports'],
    ['href'=>'admin_logout.php','icon'=>'bi-box-arrow-right','label'=>'Logout','class'=>'text-danger']
  ],
  // provider and customer menus can be added here...
];

$activePage = basename($_SERVER['SCRIPT_NAME']);
?>
<nav class="d-none d-lg-block col-lg-2 order-lg-1">
  <div class="position-sticky" style="top:1rem">
    <div class="p-3 lh-card">
      <div class="mb-3 text-center">
        <div class="rounded-circle bg-success d-inline-flex align-items-center justify-content-center" style="width:64px;height:64px;color:white;font-weight:700">LH</div>
        <div class="mt-2">
          <div class="fw-bold"><?= isset($_SESSION['admin_name']) ? htmlspecialchars($_SESSION['admin_name']) : 'Admin' ?></div>
          <div class="small lh-muted">Administrator</div>
        </div>
      </div>
      <ul class="nav nav-pills flex-column">
        <?php foreach($menus[$area] as $item): 
          $isActive = ($activePage === $item['href']) ? 'active' : '';
        ?>
          <li class="nav-item mb-1">
            <a class="nav-link d-flex align-items-center <?= $isActive ?> <?= isset($item['class']) ? $item['class'] : '' ?>" href="<?= htmlspecialchars($item['href']) ?>">
              <i class="bi <?= htmlspecialchars($item['icon']) ?> me-2"></i>
              <span><?= htmlspecialchars($item['label']) ?></span>
            </a>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</nav>
