<?php
// inc/components/footer.php
// Place at end of page before closing body tag.
?>
<footer class="py-4 mt-4" role="contentinfo" aria-label="Site Footer">
  <div class="container lh-container text-center">
    <small class="lh-muted">&copy; <?= date('Y') ?> LocalHive — All rights reserved.</small>
  </div>
</footer>

<!-- Bootstrap Bundle (includes Popper for tooltips) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>
