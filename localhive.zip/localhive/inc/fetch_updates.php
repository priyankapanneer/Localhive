<?php
// inc/fetch_updates.php
// Returns recent booking updates for the current logged-in user (customer/provider/admin)
header('Content-Type: application/json; charset=utf-8');
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/db.php';

$role = null;
$uid = null;
if (!empty($_SESSION['customer_id'])) { $role = 'user'; $uid = intval($_SESSION['customer_id']); }
elseif (!empty($_SESSION['provider_id'])) { $role = 'provider'; $uid = intval($_SESSION['provider_id']); }
elseif (!empty($_SESSION['admin_id'])) { $role = 'admin'; $uid = intval($_SESSION['admin_id']); }
else { echo json_encode(['ok'=>false, 'error'=>'not_authenticated']); exit(); }

$updates = [];
try {
    if ($role === 'user') {
        $stmt = $conn->prepare("SELECT b.id, b.status, b.created_at, s.title AS service_title, p.name AS provider_name
            FROM bookings b
            LEFT JOIN services s ON s.id = b.service_id
            LEFT JOIN providers p ON p.id = b.provider_id
            WHERE b.user_id = ?
            ORDER BY b.created_at DESC
            LIMIT 8");
        $stmt->bind_param('i', $uid);
    } elseif ($role === 'provider') {
        $stmt = $conn->prepare("SELECT b.id, b.status, b.created_at, s.title AS service_title, u.name AS customer_name
            FROM bookings b
            LEFT JOIN services s ON s.id = b.service_id
            LEFT JOIN users u ON u.id = b.user_id
            WHERE b.provider_id = ?
            ORDER BY b.created_at DESC
            LIMIT 8");
        $stmt->bind_param('i', $uid);
    } else { // admin
        $stmt = $conn->prepare("SELECT b.id, b.status, b.created_at, s.title AS service_title, p.name AS provider_name
            FROM bookings b
            LEFT JOIN services s ON s.id = b.service_id
            LEFT JOIN providers p ON p.id = b.provider_id
            ORDER BY b.created_at DESC
            LIMIT 10");
    }

    $stmt->execute();
    $res = $stmt->get_result();
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $bid = intval($r['id']);
            $status = $r['status'] ?? '';
            $title = "Booking #{$bid} — " . ($status ? ucfirst($status) : 'New');
            $subtitle = '';
            if ($role === 'user') {
                $subtitle = "Service: " . ($r['service_title'] ?? 'Service') . " — Provider: " . ($r['provider_name'] ?? '—');
                $link = '/localhive/customer/dashboard.php';
            } elseif ($role === 'provider') {
                $subtitle = "Service: " . ($r['service_title'] ?? 'Service') . " — Customer: " . ($r['customer_name'] ?? '—');
                $link = '/localhive/provider/provider_bookings.php';
            } else {
                $subtitle = "Service: " . ($r['service_title'] ?? 'Service') . " — Provider: " . ($r['provider_name'] ?? '—');
                $link = '/localhive/admin/admin_bookings.php';
            }
            $updates[] = [
                'id' => $bid,
                'type' => 'booking',
                'title' => $title,
                'message' => $subtitle,
                'link' => $link,
                'created_at' => $r['created_at'] ?? null,
            ];
        }
    }
    $stmt->close();

    echo json_encode(['ok'=>true, 'count'=>count($updates), 'updates'=>$updates]);
} catch (Exception $e) {
    echo json_encode(['ok'=>false, 'error'=>'exception', 'message'=>$e->getMessage()]);
}

exit();
