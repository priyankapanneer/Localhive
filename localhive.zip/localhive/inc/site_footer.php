<?php
// Shared footer include
?>
<footer class="site-footer mt-4">
  <div class="container py-3">
    <small>&copy; <?= date('Y') ?> LocalHive. All Rights Reserved.</small>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<?php
// end
?>
