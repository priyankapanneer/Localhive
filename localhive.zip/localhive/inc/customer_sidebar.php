<?php
// Customer sidebar include - outputs sidebar and opens main-content
?>
<div class="sidebar">
    <div style="display:flex;align-items:center;justify-content:space-between;padding:0 16px 10px 16px">
        <h4 style="margin:0">Customer</h4>
        <div>
            <div class="dropdown">
                <a href="#" class="btn btn-sm btn-outline-secondary dropdown-toggle lh-bell" id="lhBellCustomer" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-bell"></i> <span class="badge bg-danger lh-bell-count" style="display:none;">0</span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="lhBellCustomer" style="width:320px; max-width:95%;">
                    <li class="dropdown-header">Recent updates</li>
                    <li><div class="px-3 py-2 lh-bell-dropdown"><div class="text-muted small">Loading…</div></div></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-center" href="/localhive/customer/dashboard.php">View all</a></li>
                </ul>
            </div>
        </div>
    </div>
    <a href="/localhive/customer/dashboard.php">Dashboard</a>
    <a href="/localhive/customer/book_service.php">Book Service</a>
    <a href="/localhive/customer/invoices.php">Invoices</a>
    <a href="/localhive/customer/report_late.php">Report Late</a>
    <a href="/localhive/customer/customer_logout.php" class="logout">Logout</a>
</div>
<div class="main-content">
