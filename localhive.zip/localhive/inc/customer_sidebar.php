<?php
// Customer sidebar include - outputs sidebar and opens main-content
?>
<div class="sidebar">
    <h4>Customer</h4>
    <a href="/localhive/customer/dashboard.php">Dashboard</a>
    <a href="/localhive/customer/book_service.php">Book Service</a>
    <a href="/localhive/customer/invoices.php">Invoices</a>
    <a href="/localhive/customer/report_late.php">Report Late</a>
    <a href="/localhive/customer/customer_logout.php" class="logout">Logout</a>
</div>
<div class="main-content">
