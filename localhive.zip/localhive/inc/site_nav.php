<?php
// Navigation component removed per project preference.
// This file is intentionally left minimal so accidental includes won't render an app-level navbar.
http_response_code(204);
// end
?>
