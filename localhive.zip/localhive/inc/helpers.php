<?php

// Clean input string
function clean($str){
    return htmlspecialchars(trim($str), ENT_QUOTES);
}

// Convert MySQL date to readable format
function formatDate($date){
    return date("d M Y", strtotime($date));
}

// Convert MySQL time to readable format
function formatTime($time){
    return date("h:i A", strtotime($time));
}

// CSV Export Helper
function exportCSV($filename, $header, $rows){
    // Make CSV Excel-friendly: declare UTF-8 and emit BOM so Excel detects UTF-8 correctly
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename='.$filename.'.csv');

    // UTF-8 BOM
    echo "\xEF\xBB\xBF";

    $output = fopen("php://output", "w");
    // write header row
    fputcsv($output, $header);

    foreach($rows as $row){
        fputcsv($output, $row);
    }
    fclose($output);
    exit();
}

// Note: Notification functionality (session + persistent DB notifications)
// was removed per recent requirements. Keep this file focused on general
// helpers only. If you need a different notification approach, add it
// in a small, separate module.

?>
