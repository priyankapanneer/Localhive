<?php
require_once __DIR__ . '/../inc/db.php';

function stream_csv($rows, $filename = 'report.csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $out = fopen('php://output', 'w');
    if (count($rows) === 0) {
        fputcsv($out, ['No data']);
        fclose($out);
        exit;
    }
    fputcsv($out, array_keys($rows[0]));
    foreach ($rows as $r) fputcsv($out, $r);
    fclose($out);
    exit;
}

function build_html_table($rows, $title = 'Report') {
    $html = '<!doctype html><html><head><meta charset="utf-8"><title>' . htmlspecialchars($title) . '</title>';
    $html .= '<style>table{border-collapse:collapse;width:100%;}th,td{border:1px solid #ccc;padding:8px;text-align:left;}th{background:#f4f4f4;}</style>';
    $html .= '</head><body>';
    $html .= '<h2>' . htmlspecialchars($title) . '</h2>';
    if (count($rows) === 0) {
        $html .= '<p>No rows found.</p>';
    } else {
        $html .= '<table><thead><tr>';
        foreach (array_keys($rows[0]) as $h) $html .= '<th>' . htmlspecialchars($h) . '</th>';
        $html .= '</tr></thead><tbody>';
        foreach ($rows as $r) {
            $html .= '<tr>';
            foreach ($r as $v) $html .= '<td>' . htmlspecialchars((string)$v) . '</td>';
            $html .= '</tr>';
        }
        $html .= '</tbody></table>';
    }
    $html .= '</body></html>';
    return $html;
}

function generate_pdf_or_fallback($html, $filename_base = 'report') {
    // Try to locate wkhtmltopdf
    $wk = null;
    $where = trim(@shell_exec('where wkhtmltopdf 2>&1'));
    if ($where) $wk = strtok($where, "\r\n");
    if (!$wk) {
        $which = trim(@shell_exec('which wkhtmltopdf 2>&1'));
        if ($which) $wk = strtok($which, "\r\n");
    }

    if ($wk) {
        $tmpHtml = tempnam(sys_get_temp_dir(), 'rp_') . '.html';
        $tmpPdf = tempnam(sys_get_temp_dir(), 'rp_') . '.pdf';
        file_put_contents($tmpHtml, $html);
        @shell_exec(escapeshellarg($wk) . ' ' . escapeshellarg($tmpHtml) . ' ' . escapeshellarg($tmpPdf) . ' 2>&1');
        if (file_exists($tmpPdf) && filesize($tmpPdf) > 0) {
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename_base . '.pdf"');
            readfile($tmpPdf);
            @unlink($tmpHtml);
            @unlink($tmpPdf);
            exit;
        }
        @unlink($tmpHtml);
        @unlink($tmpPdf);
    }

    header('Content-Type: text/html');
    header('Content-Disposition: attachment; filename="' . $filename_base . '.html"');
    echo $html;
    exit;
}

$format = isset($_GET['format']) ? strtolower($_GET['format']) : 'csv';

$sql = "SELECT b.id AS booking_id, u.name AS customer, p.name AS provider, s.title AS service, COALESCE(b.actual_arrival, b.created_at) AS booked_at, b.preferred_date, b.preferred_time, b.status, b.provider_id, b.user_id
        FROM bookings b
        JOIN users u ON u.id = b.user_id
        JOIN providers p ON p.id = b.provider_id
        JOIN services s ON s.id = b.service_id
        WHERE b.booking_type = 'emergency'
        ORDER BY COALESCE(b.actual_arrival, b.created_at) DESC";
$result = $conn->query($sql);
$rows = [];
if ($result) {
    while ($r = $result->fetch_assoc()) $rows[] = $r;
}

if ($format === 'pdf') {
    $html = build_html_table($rows, 'Emergency Bookings');
    generate_pdf_or_fallback($html, 'emergency_bookings');
} else {
    stream_csv($rows, 'emergency_bookings.csv');
}
