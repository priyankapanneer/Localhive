<?php
// tools/geocode_providers.php
// Usage: run from project root: php tools/geocode_providers.php
require_once __DIR__ . '/../inc/db.php';

function geocode($address) {
    $url = 'https://nominatim.openstreetmap.org/search?' . http_build_query([
        'q' => $address,
        'format' => 'json',
        'limit' => 1,
    ]);
    $opts = ['http' => ['header' => "User-Agent: LocalHive/1.0 (your-email@example.com)\r\n"]];
    $context = stream_context_create($opts);
    $res = @file_get_contents($url, false, $context);
    if (!$res) return null;
    $j = json_decode($res, true);
    if (empty($j)) return null;
    return ['lat'=>floatval($j[0]['lat']), 'lon'=>floatval($j[0]['lon'])];
}

$sql = "SELECT id, address FROM providers WHERE (lat IS NULL OR lng IS NULL)";
$result = $conn->query($sql);
if (!$result) {
    echo "Query failed: " . $conn->error . "\n";
    exit(1);
}

$update = $conn->prepare("UPDATE providers SET latitude = ?, longitude = ? WHERE id = ?");
if (!$update) {
    echo "Prepare failed: " . $conn->error . "\n";
    exit(1);
}

$count = 0;
while ($r = $result->fetch_assoc()) {
    $address = trim($r['address'] ?? '');
    if (empty($address)) {
        echo "Skipping provider {$r['id']} — no address\n";
        continue;
    }
    echo "Geocoding provider {$r['id']}: $address\n";
    $g = geocode($address);
    if ($g) {
        // update lat/lng columns
        $update2 = $conn->prepare("UPDATE providers SET lat = ?, lng = ? WHERE id = ?");
        $update2->bind_param('ddi', $g['lat'], $g['lon'], $r['id']);
        if ($update2->execute()) {
            echo " -> success: {$g['lat']},{$g['lon']}\n";
            $count++;
        } else {
            echo " -> update failed: " . $update2->error . "\n";
        }
    } else {
        echo " -> failed to geocode\n";
    }
    // be polite to Nominatim: 1 second pause
    sleep(1);
}

echo "Done. Geocoded $count providers.\n";
