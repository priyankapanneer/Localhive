<?php
// CLI script to regenerate invoices for all payments
// Usage (from project root):
// C:\xampp\php\php.exe tools\regenerate_all_invoices.php

require_once __DIR__ . '/../inc/db.php';

$invoiceDir = __DIR__ . '/../exports/invoices';
if (!is_dir($invoiceDir)) mkdir($invoiceDir, 0755, true);

$q = "SELECT pa.id AS payment_id, pa.amount, b.id AS booking_id, b.user_id, b.provider_id, s.title AS service_title, s.price AS service_price
      FROM payments pa
      JOIN bookings b ON b.id=pa.booking_id
      JOIN services s ON s.id=b.service_id";
$res = mysqli_query($conn, $q);
if (!$res) {
    echo "DB query failed: " . mysqli_error($conn) . "\n";
    exit(1);
}

$generatedCount = 0;
$failed = 0;
while ($p = mysqli_fetch_assoc($res)) {
    $pid = intval($p['payment_id']);
    $amount = floatval($p['amount'] ?: $p['service_price']);
    $admin_fee = round($amount * 0.10, 2);

    $html = "<html><head><meta charset=\"utf-8\"><title>Invoice #$pid</title></head><body style='font-family:Arial,sans-serif'>";
    $html .= "<h2>Invoice #$pid</h2>";
    $html .= "<p><strong>Service:</strong> " . htmlspecialchars($p['service_title']) . "</p>";
    $html .= "<table border='1' cellpadding='6' cellspacing='0' style='border-collapse:collapse;width:60%'>";
    $html .= "<tr><th>Description</th><th>Amount</th></tr>";
    $html .= "<tr><td>Service Charge</td><td>₹" . number_format($amount,2) . "</td></tr>";
    $html .= "<tr><td>Admin Fee</td><td>₹" . number_format($admin_fee,2) . "</td></tr>";
    $html .= "<tr><td><strong>Total</strong></td><td><strong>₹" . number_format($amount,2) . "</strong></td></tr>";
    $html .= "</table>";
    $html .= "</body></html>";

    $pdfPath = $invoiceDir . '/invoice_' . $pid . '.pdf';
    $htmlPath = $invoiceDir . '/invoice_' . $pid . '.html';

    // Always generate HTML invoices (Dompdf removed)
    $ok = file_put_contents($htmlPath, $html) !== false;
    if ($ok) {
        echo "Generated HTML: invoice_$pid.html\n";
        $generatedCount++;
    } else {
        echo "Failed to write invoice for $pid\n";
        $failed++;
    }
}

echo "Done. Generated: $generatedCount, Failed: $failed\n";

?>