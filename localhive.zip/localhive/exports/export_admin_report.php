<?php
include "../inc/db.php";
include "../inc/helpers.php";

// Validate input
$type = $_GET['type'] ?? '';
if ($type === '') {
    die("Invalid Request");
}

/**
 * Fetch all rows from mysqli_query
 */
function fetchRows($query){
    $rows = [];
    while($r = mysqli_fetch_assoc($query)){
        $rows[] = $r;
    }
    return $rows;
}

/**
 * Safe column checker for dynamic SQL readability
 */
function runQuery($sql){
    global $conn;
    $q = mysqli_query($conn, $sql);
    if(!$q){
        die("Query Error: " . mysqli_error($conn));
    }
    return $q;
}

switch($type){

/* -------------------------
   CUSTOMERS REPORT
------------------------- */
case "customers":
    $rows = fetchRows(runQuery(
        "SELECT id, name, email, phone, address 
         FROM users ORDER BY id DESC"
    ));
    exportCSV("customers_report", 
        ["ID","Name","Email","Phone","Address"], 
        $rows
    );
break;

/* -------------------------
   PROVIDERS REPORT
------------------------- */
case "providers":
    $rows = fetchRows(runQuery(
        "SELECT id, name, email, phone, service_category, status 
         FROM providers ORDER BY id DESC"
    ));
    exportCSV("providers_report", 
        ["ID","Name","Email","Phone","Category","Status"], 
        $rows
    );
break;

/* -------------------------
   BOOKINGS REPORT
------------------------- */
case "bookings":
    $rows = fetchRows(runQuery(
        "SELECT 
            b.id,
            u.name AS customer,
            s.title AS service,
            b.preferred_date AS date,
            b.preferred_time AS time,
            b.booking_type AS type,
            b.status
         FROM bookings b
         JOIN users u ON b.user_id = u.id
         JOIN services s ON b.service_id = s.id
         ORDER BY b.id DESC"
    ));
    exportCSV("bookings_report",
        ["ID","Customer","Service","Date","Time","Type","Status"],
        $rows
    );
break;

/* -------------------------
   EMERGENCY BOOKINGS REPORT
------------------------- */
case "emergency":
    $rows = fetchRows(runQuery(
        "SELECT 
            b.id,
            u.name AS customer,
            s.title AS service,
            b.preferred_date AS date,
            b.preferred_time AS time
         FROM bookings b
         JOIN users u ON b.user_id = u.id
         JOIN services s ON b.service_id = s.id
         WHERE b.booking_type = 'emergency'
         ORDER BY b.id DESC"
    ));
    exportCSV("emergency_bookings",
        ["ID","Customer","Service","Date","Time"],
        $rows
    );
break;

/* -------------------------
   LATE ARRIVAL REPORTS
------------------------- */
case "late_reports":
    $rows = fetchRows(runQuery(
        "SELECT 
            lr.id,
            u.name AS customer,
            lr.reason,
            lr.status
         FROM late_reports lr
         JOIN users u ON lr.reporter_user_id = u.id
         ORDER BY lr.id DESC"
    ));
    exportCSV("late_arrival_reports",
        ["ID","Customer","Reason","Status"],
        $rows
    );
break;

/* -------------------------
   PAYMENTS REPORT
------------------------- */
case "payments":
    $rows = fetchRows(runQuery(
        "SELECT 
            p.id,
            p.booking_id,
            p.amount,
            p.status,
            p.created_at AS date
         FROM payments p
         ORDER BY p.id DESC"
    ));
    exportCSV("payments_report",
        ["ID","Booking ID","Amount","Status","Date"],
        $rows
    );
break;

/* -------------------------
   INVALID TYPE
------------------------- */
default:
    echo "Invalid report type.";
break;

}
?>
