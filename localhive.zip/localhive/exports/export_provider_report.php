<?php
include "../inc/db.php";
include "../inc/helpers.php";

/* -------------------------
   VALIDATE INPUTS
------------------------- */
$provider_id = isset($_GET['provider_id']) ? intval($_GET['provider_id']) : 0;
$type        = $_GET['type'] ?? '';

if (!$provider_id || $type === '') {
    die("Invalid Request");
}

/* -------------------------
   UNIVERSAL FETCH FUNCTION
------------------------- */
function fetchRows($query){
    $rows = [];
    while($r = mysqli_fetch_assoc($query)){
        $rows[] = $r;
    }
    return $rows;
}

/* -------------------------
   SAFE QUERY EXECUTOR
------------------------- */
function runQuery($sql){
    global $conn;
    $q = mysqli_query($conn, $sql);
    if(!$q){
        die("SQL Error: " . mysqli_error($conn));
    }
    return $q;
}

/* -------------------------
   REPORT LOGIC
------------------------- */
switch($type){

/* ---------------------------------------------------
   PROVIDER BOOKINGS REPORT
   Correct logic: bookings.provider_id is stored
   inside bookings table, NOT services table.
--------------------------------------------------- */
case "bookings":
    $rows = fetchRows(runQuery(
        "SELECT 
            b.id,
            s.title AS service,
            b.preferred_date AS date,
            b.preferred_time AS time,
            b.status
         FROM bookings b
         JOIN services s ON b.service_id = s.id
         WHERE b.provider_id = $provider_id
         ORDER BY b.id DESC"
    ));

    exportCSV("provider_bookings",
        ["ID","Service","Date","Time","Status"],
        $rows
    );
break;

/* ---------------------------------------------------
   EMERGENCY BOOKINGS
--------------------------------------------------- */
case "emergency":
    $rows = fetchRows(runQuery(
        "SELECT 
            b.id,
            s.title AS service,
            b.preferred_date AS date,
            b.preferred_time AS time
         FROM bookings b
         JOIN services s ON b.service_id = s.id
         WHERE b.provider_id = $provider_id
           AND b.booking_type = 'emergency'
         ORDER BY b.id DESC"
    ));

    exportCSV("provider_emergency_bookings",
        ["ID","Service","Date","Time"],
        $rows
    );
break;

/* ---------------------------------------------------
   LATE REPORTS FILE
   Correct mapping: 
   late_reports → bookings → provider_id
--------------------------------------------------- */
case "late_reports":
    $rows = fetchRows(runQuery(
        "SELECT 
            lr.id,
            lr.reason,
            lr.status
         FROM late_reports lr
         JOIN bookings b ON lr.booking_id = b.id
         WHERE b.provider_id = $provider_id
         ORDER BY lr.id DESC"
    ));

    exportCSV("provider_late_reports",
        ["ID","Reason","Status"],
        $rows
    );
break;

/* ---------------------------------------------------
   PROVIDER EARNINGS REPORT
   Correct: payments join → bookings → provider_id
--------------------------------------------------- */
case "earnings":
    $rows = fetchRows(runQuery(
        "SELECT 
            p.id,
            p.booking_id,
            p.amount,
            p.status,
            p.created_at AS date
         FROM payments p
         JOIN bookings b ON p.booking_id = b.id
         WHERE b.provider_id = $provider_id
           AND p.status = 'success'
         ORDER BY p.id DESC"
    ));

    exportCSV("provider_earnings",
        ["ID","Booking ID","Amount","Status","Date"],
        $rows
    );
break;

/* ---------------------------------------------------
   INVALID TYPE
--------------------------------------------------- */
default:
    die("Invalid report type.");
}

?>
