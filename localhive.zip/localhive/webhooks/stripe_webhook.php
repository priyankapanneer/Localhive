<?php
// Stripe integration removed
http_response_code(410);
header('Content-Type: text/plain');
echo "Stripe integration has been removed from this installation.\n";
exit();

?>