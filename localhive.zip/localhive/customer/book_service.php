<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../inc/db.php';

if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit();
}

// CSRF token
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
$CSRF = $_SESSION['csrf_token'];

$msg = "";
$alertClass = "";

$user_pincode = '';

// Fetch user pincode safely
$uid = intval($_SESSION['customer_id']);
$stmt = $conn->prepare("SELECT pincode FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $uid);
$stmt->execute();
$res = $stmt->get_result();
if ($res && $row = $res->fetch_assoc()) {
    $user_pincode = $row['pincode'] ?? '';
}
$stmt->close();

// Prepare services list: only providers approved and matching pincode
$services = [];
if (!empty($user_pincode)) {
    $stmt = $conn->prepare("
        SELECT s.id, s.title, s.price, s.provider_id, p.name AS provider_name
        FROM services s
        JOIN providers p ON s.provider_id = p.id
        WHERE p.approved = 1 AND p.pincode = ?
        ORDER BY s.title ASC
    ");
    $stmt->bind_param("s", $user_pincode);
    $stmt->execute();
    $svRes = $stmt->get_result();
    if ($svRes) {
        while ($r = $svRes->fetch_assoc()) $services[] = $r;
    }
    $stmt->close();
} else {
    // no pincode known — show no services (as per your earlier choice)
    $services = [];
}

/* ---------- Handle booking submission ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CSRF check
    if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf'])) {
        $msg = "Invalid request (CSRF).";
        $alertClass = "alert-danger";
    } else {
        $customer   = $uid;
        $serviceId  = isset($_POST['service']) ? intval($_POST['service']) : 0;
        $date       = trim($_POST['date'] ?? '');
        $time       = trim($_POST['time'] ?? '');
        $type       = trim($_POST['type'] ?? '');

        // Basic validation
        if ($serviceId <= 0 || $date === '' || $time === '' || ($type !== 'normal' && $type !== 'emergency')) {
            $msg = "Please fill all fields correctly.";
            $alertClass = "alert-danger";
        } else {
            // Validate date/time (not in the past)
            $dt = DateTime::createFromFormat('Y-m-d H:i', $date . ' ' . $time);
            if (!$dt) {
                $msg = "Invalid date or time format.";
                $alertClass = "alert-danger";
            } else {
                $now = new DateTime('now');
                if ($dt < $now) {
                    $msg = "Preferred date/time cannot be in the past.";
                    $alertClass = "alert-danger";
                } else {
                    // fetch provider_id for the service
                    $stmt = $conn->prepare("SELECT provider_id FROM services WHERE id = ? LIMIT 1");
                    $stmt->bind_param("i", $serviceId);
                    $stmt->execute();
                    $srvRes = $stmt->get_result();
                    if (!$srvRes || $srvRes->num_rows === 0) {
                        $msg = "Selected service not found.";
                        $alertClass = "alert-danger";
                        $stmt->close();
                    } else {
                        $srv = $srvRes->fetch_assoc();
                        $provider_id = intval($srv['provider_id']);
                        $stmt->close();

                        // Insert booking safely
                        $insert = $conn->prepare("
                            INSERT INTO bookings 
                                (user_id, provider_id, service_id, booking_type, preferred_date, preferred_time, status, created_at)
                            VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())
                        ");
                        $pref_date = $date;
                        $pref_time = $time;
                        $booking_type = $type;
                        $insert->bind_param("iiisss", $customer, $provider_id, $serviceId, $booking_type, $pref_date, $pref_time);

                        if ($insert->execute()) {
                            $msg = "Service booked successfully!";
                            $alertClass = "alert-success";
                            // Optionally regenerate services list to reflect availability
                        } else {
                            $msg = "Error: Could not book service. Please try again.";
                            $alertClass = "alert-danger";
                        }
                        $insert->close();
                    }
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Book Service</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

    <!-- your site styles (keeps consistency) -->
    <link rel="stylesheet" href="/localhive/assets/css/styles.css">
    <link rel="stylesheet" href="/localhive/assets/css/ecommerce.css">
    <link rel="stylesheet" href="/localhive/assets/css/admin_theme.css">

    <style>
    /* small page-specific tweaks that follow your theme */
    .form-card { max-width: 820px; margin: 0 auto; border-radius: 12px; background:#fff; padding:24px; }
    .btn-primary-ecom { background:#007E6E; color:#E7DEAF; border-radius:10px; font-weight:600; }
    .btn-primary-ecom:hover { background:#73AF6F; color:#fff; }
    .small-muted { font-size:0.92rem; color:#6b6b6b; }
    .max-w-200 { max-width:200px; }
    </style>
</head>

<body class="ecom-body admin-theme">
<?php include_once __DIR__ . '/../inc/customer_sidebar.php'; ?>

<div class="container mt-4">
    <div class="form-card ecom-card shadow-sm">

        <h3 class="text-center mb-2">Book a Service</h3>
        <p class="text-center small-muted mb-3">We show services from providers approved in your pincode (<?= htmlspecialchars($user_pincode ?: 'unknown') ?>).</p>
        <hr>

        <?php if ($msg): ?>
            <div class="<?= htmlspecialchars($alertClass ?: 'alert-info') ?>"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <form method="POST" class="row g-3" novalidate>
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($CSRF) ?>">

            <div class="col-12">
                <label class="form-label">Select Service</label>
                <select class="form-control" name="service" required <?= empty($services) ? 'disabled' : '' ?>>
                    <option value="">-- Select Service --</option>
                    <?php if (!empty($services)): ?>
                        <?php foreach ($services as $row): ?>
                            <option value="<?= intval($row['id']) ?>">
                                <?= htmlspecialchars($row['title']) ?> — ₹<?= number_format($row['price'],2) ?> (<?= htmlspecialchars($row['provider_name']) ?>)
                            </option>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <option disabled>No services available for your pincode</option>
                    <?php endif; ?>
                </select>
            </div>

            <div class="col-md-6">
                <label class="form-label">Preferred Date</label>
                <input type="date" class="form-control" name="date" required>
            </div>

            <div class="col-md-6">
                <label class="form-label">Preferred Time</label>
                <input type="time" class="form-control" name="time" required>
            </div>

            <div class="col-12">
                <label class="form-label">Service Type</label>
                <select class="form-control" name="type" required>
                    <option value="normal">Normal</option>
                    <option value="emergency">Emergency</option>
                </select>
            </div>

            <div class="col-12">
                <button class="btn btn-primary-ecom w-100" type="submit" <?= empty($services) ? 'disabled' : '' ?>>Book Service</button>
            </div>
        </form>

        <hr>

        <div class="mt-3">
            <h5>Find providers by Pincode</h5>
            <div class="d-flex gap-2 mb-2">
                <input id="search-pincode" class="form-control max-w-200" placeholder="Enter pincode" value="<?= htmlspecialchars($user_pincode) ?>">
                <button id="search-pincode-btn" class="btn btn-outline-primary">Search</button>
            </div>
            <div id="nearby-results"></div>
        </div>

    </div>
</div>

<!-- JS: fetch providers_nearby.php?pincode=... expects JSON { providers: [...] } -->
<script>
document.getElementById('search-pincode-btn').addEventListener('click', function(e){
    e.preventDefault();
    const out = document.getElementById('nearby-results');
    const pinInput = document.getElementById('search-pincode');
    const pin = pinInput.value.trim();
    out.innerHTML = '';
    if (!pin) { out.innerHTML = '<div class="text-danger">Enter a pincode</div>'; pinInput.focus(); return; }
    out.innerHTML = '<div class="text-muted">Searching…</div>';

    fetch(`providers_nearby.php?pincode=${encodeURIComponent(pin)}`, { credentials: 'same-origin' })
        .then(r => r.json())
        .then(json => {
            if (json.error) { out.innerHTML = `<div class="text-danger">${json.error}</div>`; return; }
            if (!json.providers || json.providers.length === 0) { out.innerHTML = '<div>No providers found for this pincode.</div>'; return; }

            const list = document.createElement('div');
            list.className = 'row';
            json.providers.forEach(p => {
                const col = document.createElement('div');
                col.className = 'col-12 mb-2';
                const card = document.createElement('div');
                card.className = 'card p-2';
                const addr = p.address ? `<div class="small-muted">${p.address}</div>` : '';
                card.innerHTML = `<div class="d-flex justify-content-between align-items-center">
                    <div><strong>${escapeHtml(p.name)}</strong>${addr}</div>
                    <div><a href="provider_profile.php?id=${encodeURIComponent(p.id)}" class="btn btn-sm btn-primary">View</a></div>
                </div>`;
                col.appendChild(card);
                list.appendChild(col);
            });
            out.innerHTML = '';
            out.appendChild(list);
        })
        .catch(err => {
            console.error(err);
            out.innerHTML = '<div class="text-danger">Error fetching providers</div>';
        });
});

// small helper to escape inserted strings for innerHTML fragments
function escapeHtml(s) {
    if (!s) return '';
    return s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
}
</script>

</body>
</html>
