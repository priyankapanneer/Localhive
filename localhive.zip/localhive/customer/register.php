﻿<?php
// Customer registration (final clean version)
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../inc/db.php';

$msg = "";

if (isset($_POST['register'])) {
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $phone   = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $pincode = trim($_POST['pincode'] ?? '');
    $passRaw = $_POST['password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = "Invalid email format.";
    } elseif (!preg_match('/^[0-9]{6}$/', $pincode)) {
        $msg = "Invalid pincode. Must be 6 digits.";
    } elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $msg = "Invalid phone number.";
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $check->bind_param("s", $email);
        $check->execute();
        $exists = $check->get_result()->num_rows > 0;
        $check->close();

        if ($exists) {
            $msg = "Email already registered!";
        } else {
            $password = password_hash($passRaw, PASSWORD_DEFAULT);

            $ins = $conn->prepare(
                "INSERT INTO users (name, email, phone, address, pincode, password) VALUES (?, ?, ?, ?, ?, ?)"
            );

            $ins->bind_param("ssssss", $name, $email, $phone, $address, $pincode, $password);

            if ($ins->execute()) {
                $ins->close();
                header("Location: login.php?registered=1");
                exit();
            } else {
                $msg = "Registration failed. Please try again.";
            }

            $ins->close();
        }
    }
}

$page_title = 'Customer Registration';
$body_class = 'customer-register';
require_once __DIR__ . '/../inc/components/header.php';
?>

<div class="d-flex align-items-center" style="min-height:70vh;">
  <div class="container lh-container">
    <div class="row justify-content-center">
      <div class="col-sm-10 col-md-8 col-lg-6">
        <div class="lh-card">
          <h2 class="h5 text-center mb-3">Create your account</h2>

          <?php if ($msg): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($msg) ?></div>
          <?php endif; ?>

          <form method="POST" autocomplete="off">
            <div class="mb-3">
              <label class="form-label">Full Name</label>
              <input type="text" class="form-control" name="name" required>
            </div>

            <div class="mb-3">
              <label class="form-label">Email Address</label>
              <input type="email" class="form-control" name="email" required>
            </div>

            <div class="mb-3 row">
              <div class="col-md-6 mb-3 mb-md-0">
                <label class="form-label">Phone Number</label>
                <input type="text" class="form-control" name="phone" maxlength="10" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Pincode</label>
                <input type="text" class="form-control" name="pincode" maxlength="6" required>
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Address</label>
              <textarea class="form-control" name="address" required></textarea>
            </div>

            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" class="form-control" name="password" required>
            </div>

            <div class="d-grid">
              <button type="submit" name="register" class="btn lh-btn lh-btn-primary">Register</button>
            </div>

            <p class="text-center mt-3 small lh-muted">Already have an account? <a href="login.php">Login here</a></p>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../inc/components/footer.php'; ?>
