<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../inc/db.php';

// -----------------------------
//  USER AUTH CHECK
// -----------------------------
if (!isset($_SESSION['customer_id'])) {
    $_SESSION['flash_message'] = "Please login to continue.";
    header('Location: login.php');
    exit();
}

$uid = intval($_SESSION['customer_id']);

if (!isset($_GET['payment_id']) || !is_numeric($_GET['payment_id'])) {
    $_SESSION['flash_message'] = "Invalid payment reference.";
    header('Location: invoices.php');
    exit();
}

$paymentId = intval($_GET['payment_id']);

// -----------------------------
//  FETCH PAYMENT + BOOKING DETAILS (Prepared)
// -----------------------------
$sql = "
SELECT pa.*, 
       b.user_id, 
       b.provider_id, 
       b.id AS booking_id, 
       s.title AS service_title, 
       s.price AS service_price 
FROM payments pa
JOIN bookings b ON b.id = pa.booking_id
JOIN services s ON s.id = b.service_id
WHERE pa.id = ?
LIMIT 1
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $paymentId);
$stmt->execute();
$res = $stmt->get_result();
$p = $res->fetch_assoc();
$stmt->close();

if (!$p || intval($p['user_id']) !== $uid) {
    $_SESSION['flash_message'] = "Unauthorized payment access.";
    header('Location: invoices.php');
    exit();
}

// -----------------------------
//  FETCH CUSTOMER & PROVIDER
// -----------------------------
$cust = [];
$prov = [];

// customer
$cs = $conn->prepare("SELECT name, email FROM users WHERE id = ? LIMIT 1");
$cs->bind_param("i", $p['user_id']);
$cs->execute();
$customerRes = $cs->get_result();
$cust = $customerRes->fetch_assoc();
$cs->close();

// provider
$ps = $conn->prepare("SELECT name FROM providers WHERE id = ? LIMIT 1");
$ps->bind_param("i", $p['provider_id']);
$ps->execute();
$providerRes = $ps->get_result();
$prov = $providerRes->fetch_assoc();
$ps->close();

// -----------------------------
//  CALCULATIONS
// -----------------------------
$amount = floatval($p['amount'] ?: $p['service_price']);
$admin_fee = round($amount * 0.10, 2);
$total = $amount;  // You can change if total = amount + fee

// -----------------------------
//  FOLDERS
// -----------------------------
$invoiceDir = dirname(__DIR__) . '/exports/invoices';
$logDir     = dirname(__DIR__) . '/logs';

if (!is_dir($invoiceDir)) mkdir($invoiceDir, 0755, true);
if (!is_dir($logDir)) mkdir($logDir, 0755, true);

// -----------------------------
//  HTML INVOICE TEMPLATE
// -----------------------------
$invoiceHtml = "
<html>
<head>
    <meta charset='UTF-8'>
    <title>Invoice #{$paymentId}</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f8f9fc;
            padding: 30px;
        }
        .container {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            width: 700px;
            margin: auto;
            box-shadow: 0 3px 12px rgba(0,0,0,0.12);
        }
        h2 {
            margin-bottom: 5px;
            font-size: 28px;
            color: #333;
        }
        .meta {
            color: #666;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        table th, table td {
            border: 1px solid #dedede;
            padding: 10px;
            text-align: left;
        }
        table th {
            background: #f1f1f1;
            font-weight: bold;
        }
        .total-row td {
            font-size: 16px;
            font-weight: bold;
            background: #fafafa;
        }
        .footer {
            margin-top: 25px;
            color: #777;
            font-size: 13px;
            text-align: center;
        }
    </style>
</head>

<body>
<div class='container'>
    <h2>Invoice #{$paymentId}</h2>
    <p class='meta'><strong>Date:</strong> " . date('Y-m-d H:i:s') . "</p>

    <p><strong>Customer:</strong> " . htmlspecialchars($cust['name'] ?? '') . " (" . htmlspecialchars($cust['email'] ?? '') . ")</p>
    <p><strong>Provider:</strong> " . htmlspecialchars($prov['name'] ?? '') . "</p>
    <p><strong>Service:</strong> " . htmlspecialchars($p['service_title'] ?? '') . "</p>

    <table>
        <tr>
            <th>Description</th>
            <th>Amount (₹)</th>
        </tr>
        <tr>
            <td>Service Charge</td>
            <td>" . number_format($amount, 2) . "</td>
        </tr>
        <tr>
            <td>Admin Fee</td>
            <td>" . number_format($admin_fee, 2) . "</td>
        </tr>
        <tr class='total-row'>
            <td>Total</td>
            <td>" . number_format($total, 2) . "</td>
        </tr>
    </table>

    <p class='footer'>This is a system-generated invoice. No signature required.</p>
</div>
</body>
</html>
";

// -----------------------------
//  WRITE HTML INVOICE
// -----------------------------
$htmlPath = $invoiceDir . "/invoice_{$paymentId}.html";
$success = file_put_contents($htmlPath, $invoiceHtml);

// -----------------------------
//  LOGGING
// -----------------------------
$logFile = $logDir . '/invoices.log';
$logStatus = $success ? "SUCCESS" : "FAILED";
$logLine = date('Y-m-d H:i:s') . " | regenerate_invoice | user={$uid} | payment={$paymentId} | {$logStatus}\n";

file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);

// -----------------------------
//  REDIRECT BACK WITH MESSAGE
// -----------------------------
$_SESSION['flash_message'] = $success
    ? "Invoice regenerated successfully."
    : "Error: Could not regenerate invoice.";

header("Location: invoices.php");
exit();
?>
