<?php
/**
 * Clean, secure, UI-enhanced version of Report Payment Issue
 * No duplicate code, no schema conflicts
 */

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../inc/db.php';

// --------------------------------------
// 1. AUTH CHECK
// --------------------------------------
if (!isset($_SESSION['customer_id'])) {
    header('Location: login.php');
    exit();
}

$customer_id = intval($_SESSION['customer_id']);
$booking_id  = intval($_GET['booking_id'] ?? 0);
$msg = '';

// --------------------------------------
// 2. HANDLE POST (CREATE DISPUTE)
// --------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reason = trim($_POST['reason'] ?? '');

    if ($booking_id && $reason !== '') {
        $reason_db = mysqli_real_escape_string($conn, $reason);

        // Ensure booking exists and belongs to user
        $booking_q = mysqli_query(
            $conn,
            "SELECT provider_id
             FROM bookings
             WHERE id = $booking_id AND user_id = $customer_id
             LIMIT 1"
        );

        if ($booking_q && mysqli_num_rows($booking_q) > 0) {
            $bk = mysqli_fetch_assoc($booking_q);
            $provider_id = intval($bk['provider_id']);

            // Get payment row if exists
            $pay_q = mysqli_query(
                $conn,
                "SELECT id FROM payments
                 WHERE booking_id = $booking_id
                 ORDER BY created_at DESC
                 LIMIT 1"
            );
            $payment_id = $pay_q && mysqli_num_rows($pay_q) > 0
                ? intval(mysqli_fetch_assoc($pay_q)['id'])
                : 'NULL';

            // Insert dispute
            $ins_q = mysqli_query(
                $conn,
                "INSERT INTO payment_disputes
                 (booking_id, payment_id, reporter_user_id, provider_id, reason)
                 VALUES ($booking_id, $payment_id, $customer_id, $provider_id, '$reason_db')"
            );

            $msg = $ins_q
                ? "<div class='alert alert-success text-center'>Payment Issue Reported. Admin will review.</div>"
                : "<div class='alert alert-danger text-center'>Error submitting report.</div>";

        } else {
            $msg = "<div class='alert alert-danger text-center'>Booking not found or access denied.</div>";
        }
    } else {
        $msg = "<div class='alert alert-danger text-center'>Please enter a reason.</div>";
    }
}

// --------------------------------------
// 3. FETCH BOOKING DETAILS FOR UI
// --------------------------------------
$booking = null;
if ($booking_id) {
    $booking = mysqli_fetch_assoc(
        mysqli_query(
            $conn,
            "SELECT b.id, s.title AS service_title, p.name AS provider_name
             FROM bookings b
             JOIN services s ON b.service_id = s.id
             JOIN providers p ON p.id = b.provider_id
             WHERE b.id = $booking_id AND b.user_id = $customer_id
             LIMIT 1"
        )
    );
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Report Payment Issue</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="/localhive/assets/css/styles.css">

<style>
    body {
        background: #F4F4EE;
        font-family: 'Segoe UI', sans-serif;
    }

    .card-custom {
        background: #FFF8D6;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        transition: 0.3s;
    }
    .card-custom:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.25);
    }

    .btn-danger {
        background: #D9534F;
        border: none;
        font-weight: 600;
    }
    .btn-danger:hover {
        background: #C9302C;
    }

    h3 {
        color: #007E6E;
        font-weight: 700;
    }
    textarea.form-control {
        border-radius: 10px;
        resize: vertical;
    }
</style>

</head>
<body>
<div class="container mt-4 mb-5">
    <a href="dashboard.php" class="btn btn-secondary mb-3">⟵ Back</a>

    <div class="card card-custom mx-auto" style="max-width:650px;">
        <h3 class="text-center mb-4">Report Payment Issue</h3>

        <?= $msg ?>

        <?php if ($booking) : ?>
            <div class="mb-3 p-3 bg-light rounded">
                <strong>Booking #<?= $booking['id'] ?></strong><br>
                Service: <?= htmlspecialchars($booking['service_title']) ?><br>
                Provider: <?= htmlspecialchars($booking['provider_name']) ?>
            </div>

            <form method="POST">
                <label class="form-label fw-semibold">Describe the Issue</label>
                <textarea name="reason" class="form-control" rows="4" placeholder="Explain the payment problem..." required></textarea>

                <button class="btn btn-danger w-100 mt-4">Submit Report</button>
            </form>
        <?php else : ?>
            <div class="alert alert-warning text-center">Booking not found.</div>
        <?php endif; ?>
    </div>
</div>

<?php include_once __DIR__ . '/../inc/site_footer.php'; ?>
</body>
</html>