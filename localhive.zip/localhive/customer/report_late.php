<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../inc/db.php';

if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit();
}

$customer_id = intval($_SESSION['customer_id']);
$msg = "";

// =====================================================
// FETCH CUSTOMER BOOKINGS (PREPARED STATEMENT)
// =====================================================
$stmt = $conn->prepare("
    SELECT b.id, s.title AS service_title, b.preferred_date AS date, b.preferred_time AS time
    FROM bookings b
    JOIN services s ON b.service_id = s.id
    WHERE b.user_id = ?
");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$bookings = $stmt->get_result();

// =====================================================
// SUBMIT LATE REPORT
// =====================================================
if (isset($_POST['submit_report'])) {

    $booking_id = intval($_POST['booking_id'] ?? 0);
    $reason     = trim($_POST['reason'] ?? '');

    if ($booking_id <= 0 || $reason === "") {
        $msg = "<div class='alert alert-danger text-center'>Please fill all fields.</div>";
    } else {

        // Verify booking belongs to user
        $chk = $conn->prepare("SELECT provider_id FROM bookings WHERE id = ? AND user_id = ? LIMIT 1");
        $chk->bind_param("ii", $booking_id, $customer_id);
        $chk->execute();
        $res = $chk->get_result();

        if ($res->num_rows === 0) {
            $msg = "<div class='alert alert-danger text-center'>Unauthorized booking selection.</div>";
        } else {

            $provider_id = intval($res->fetch_assoc()['provider_id']);
            $reason_safe = htmlspecialchars($reason);

            // Insert late report
            $ins = $conn->prepare("
                INSERT INTO late_reports (booking_id, reporter_user_id, provider_id, delay_minutes, reason)
                VALUES (?, ?, ?, 0, ?)
            ");

            $ins->bind_param("iiis", $booking_id, $customer_id, $provider_id, $reason);

            if ($ins->execute()) {
                $msg = "<div class='alert alert-success text-center'>Late Arrival Report Submitted Successfully!</div>";
            } else {
                $msg = "<div class='alert alert-danger text-center'>Error submitting report. Please try again.</div>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Report Late Arrival</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    
    <style>
        body {
            background: linear-gradient(135deg, #007E6E, #73AF6F);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 25px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .glass-card {
            width: 520px;
            background: rgba(255, 255, 255, 0.18);
            backdrop-filter: blur(15px);
            padding: 35px;
            border-radius: 18px;
            box-shadow: 0 12px 35px rgba(0,0,0,0.25);
            color: #000;
            animation: fadeUp 0.4s ease;
        }
        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        h2 {
            text-align: center;
            font-weight: 800;
            margin-bottom: 20px;
            color: #004c43;
        }
        .form-label { font-weight: 600; }
        .btn-custom {
            background-color: #D9534F;
            border: none;
            padding: 12px;
            border-radius: 10px;
            font-weight: 600;
            color: #fff;
            transition: 0.25s ease;
        }
        .btn-custom:hover {
            background-color: #c0392b;
        }
        select, textarea {
            border-radius: 10px !important;
        }
    </style>
</head>

<body>

<div class="glass-card">
    
    <h2>Report Late Arrival</h2>

    <?= $msg ?>

    <form method="POST">

        <label class="form-label">Select Booking</label>
        <select class="form-control" name="booking_id" required>
            <option value="">-- Select Booking --</option>
            <?php while ($b = $bookings->fetch_assoc()): ?>
                <option value="<?= $b['id'] ?>">
                    <?= htmlspecialchars($b['service_title']) ?> 
                    (<?= htmlspecialchars($b['date']) ?> @ <?= htmlspecialchars($b['time']) ?>)
                </option>
            <?php endwhile; ?>
        </select>

        <label class="form-label mt-3">Reason</label>
        <textarea class="form-control" name="reason" placeholder="Describe the issue" required></textarea>

        <button type="submit" class="btn-custom w-100 mt-4" name="submit_report">
            Submit Report
        </button>

    </form>

</div>

</body>
</html>
