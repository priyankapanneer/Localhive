<?php
// providers_nearby.php
require_once __DIR__ . '/../inc/db.php';
header('Content-Type: application/json; charset=utf-8');

// Params
$pincode = isset($_GET['pincode']) ? trim((string)$_GET['pincode']) : null;
$limit   = isset($_GET['limit']) ? (int)$_GET['limit'] : 100;
$expand  = isset($_GET['expand']) && in_array(strtolower((string)$_GET['expand']), ['1','true','yes'], true);

if (!$pincode) {
    http_response_code(400);
    echo json_encode(['error' => 'pincode parameter is required'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($limit <= 0 || $limit > 500) $limit = 100;

// Build pincodes array (unique, trimmed)
$pincodes = [$pincode];

if ($expand) {
    $stmtN = $conn->prepare("SELECT neighbor FROM pincode_neighbors WHERE pincode = ?");
    if ($stmtN) {
        $stmtN->bind_param('s', $pincode);
        if ($stmtN->execute()) {
            $resN = $stmtN->get_result();
            while ($r = $resN->fetch_assoc()) {
                $pn = trim($r['neighbor']);
                if ($pn !== '' && !in_array($pn, $pincodes, true)) $pincodes[] = $pn;
            }
        }
        $stmtN->close();
    }
}

// Safety cap
if (count($pincodes) > 50) $pincodes = array_slice($pincodes, 0, 50);

// Prepare placeholders and types
$ph = implode(',', array_fill(0, count($pincodes), '?'));
$types = str_repeat('s', count($pincodes)) . 'i'; // pincodes... then limit (int)

$sql = "
    SELECT id, name, COALESCE(address,'') AS address,
           COALESCE(latitude, lat, 0) AS latitude,
           COALESCE(longitude, lng, 0) AS longitude,
           COALESCE(phone, '') AS phone, pincode
    FROM providers
    WHERE pincode IN ($ph) AND approved = 1
    ORDER BY name ASC
    LIMIT ?
";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['error' => 'Database prepare failed'], JSON_UNESCAPED_UNICODE);
    exit;
}

// Build params array for bind_param (must be references)
$params = [];
// types string
$params[] = $types;
// add pincodes values
foreach ($pincodes as $i => $pc) {
    $params[] = $pincodes[$i];
}
// add limit as last param
$params[] = $limit;

// convert to references
$bind_params = [];
foreach ($params as $key => $value) {
    $bind_params[$key] = &$params[$key];
}

// bind
call_user_func_array([$stmt, 'bind_param'], $bind_params);

// execute
if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(['error' => 'Database execute failed'], JSON_UNESCAPED_UNICODE);
    exit;
}

$res = $stmt->get_result();
$providers = [];
while ($row = $res->fetch_assoc()) {
    // normalize numeric lat/lng to floats
    $row['latitude'] = $row['latitude'] !== null ? (float)$row['latitude'] : 0.0;
    $row['longitude'] = $row['longitude'] !== null ? (float)$row['longitude'] : 0.0;
    $providers[] = $row;
}
$stmt->close();

http_response_code(200);
echo json_encode([
    'count' => count($providers),
    'providers' => $providers,
    'pincodes_used' => $pincodes
], JSON_UNESCAPED_UNICODE);
exit;
