<?php
/**
 * Customer → Create Payment Session (Clean, Secure, Duplicate-Free)
 * - Validates session
 * - Validates booking ownership
 * - Ensures booking is completed before payment
 * - Creates or fetches an existing payment row
 * - Redirects to make_payment.php
 */

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../inc/db.php';

/* ---------------------------------------------------------
   1. Ensure User Is Logged In
--------------------------------------------------------- */
if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit;
}

$uid = intval($_SESSION['customer_id']);

/* ---------------------------------------------------------
   2. Validate Booking ID
--------------------------------------------------------- */
if (!isset($_GET['booking_id']) || !is_numeric($_GET['booking_id'])) {
    header("Location: dashboard.php");
    exit;
}

$booking_id = intval($_GET['booking_id']);

/* ---------------------------------------------------------
   3. Fetch Booking + Service Price (Safe)
--------------------------------------------------------- */
$stmt = $conn->prepare("
    SELECT 
        b.id, b.user_id, b.status, b.service_id,
        s.price AS service_price
    FROM bookings b
    JOIN services s ON s.id = b.service_id
    WHERE b.id = ?
    LIMIT 1
");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$res = $stmt->get_result();
$booking = $res->fetch_assoc();
$stmt->close();

if (!$booking) {
    die("<h3 style='color:red;'>Booking not found.</h3>");
}

if (intval($booking['user_id']) !== $uid) {
    die("<h3 style='color:red;'>Unauthorized booking access.</h3>");
}

// Must be completed
$status = strtolower($booking['status']);
if (!in_array($status, ['completed', 'complete'])) {
    die("<h3 style='color:red;'>This booking is not marked as completed yet.</h3>");
}

/* ---------------------------------------------------------
   4. Check If Payment Already Exists
--------------------------------------------------------- */
$stmt = $conn->prepare("
    SELECT id 
    FROM payments 
    WHERE booking_id = ?
    ORDER BY created_at DESC 
    LIMIT 1
");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$res = $stmt->get_result();
$existing_payment = $res->fetch_assoc();
$stmt->close();

if ($existing_payment) {
    $payment_id = intval($existing_payment['id']);
} else {
    /* -----------------------------------------
       Create New Payment Row
    ----------------------------------------- */
    $amount = floatval($booking['service_price']);
    $admin_fee = round($amount * 0.10, 2);
    $provider_earning = $amount - $admin_fee;

    $stmt = $conn->prepare("
        INSERT INTO payments 
            (booking_id, amount, status, provider_earning, admin_fee, created_at)
        VALUES (?, ?, 'pending', ?, ?, NOW())
    ");
    $stmt->bind_param("iddd", $booking_id, $amount, $provider_earning, $admin_fee);
    $stmt->execute();
    $payment_id = $stmt->insert_id;
    $stmt->close();
}

/* ---------------------------------------------------------
   5. Redirect to Payment Page
--------------------------------------------------------- */
header("Location: make_payment.php?booking_id={$booking_id}&payment_id={$payment_id}");
exit;
