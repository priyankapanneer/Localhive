<?php
// download_invoices_zip.php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../inc/db.php';

// Auth check
if (!isset($_SESSION['customer_id'])) {
    header('Location: login.php');
    exit();
}

$uid = intval($_SESSION['customer_id']);

// Helper to set flash message & redirect
function flash_and_redirect($msg, $dest = 'invoices.php') {
    $_SESSION['flash_message'] = $msg;
    header('Location: ' . $dest);
    exit();
}

// 1) Get all payment ids for this user's bookings (prepared)
$stmt = $conn->prepare("
    SELECT pa.id AS payment_id
    FROM payments pa
    JOIN bookings b ON b.id = pa.booking_id
    WHERE b.user_id = ?
");
$stmt->bind_param('i', $uid);
$stmt->execute();
$res = $stmt->get_result();
$paymentIds = [];
while ($r = $res->fetch_assoc()) {
    $paymentIds[] = intval($r['payment_id']);
}
$stmt->close();

if (empty($paymentIds)) {
    flash_and_redirect('No invoices available to download.');
}

// 2) Locate invoice files (prefer PDF, fallback to HTML)
$invoiceDir = realpath(__DIR__ . '/../exports/invoices');
if ($invoiceDir === false) {
    // If the folder doesn't exist, we can't proceed
    flash_and_redirect('No invoices directory found on the server. Contact support.');
}

$filesToZip = []; // [ payment_id => full_path ]
foreach ($paymentIds as $pid) {
    $pdfPath  = $invoiceDir . DIRECTORY_SEPARATOR . 'invoice_' . $pid . '.pdf';
    $htmlPath = $invoiceDir . DIRECTORY_SEPARATOR . 'invoice_' . $pid . '.html';

    if (is_file($pdfPath) && is_readable($pdfPath)) {
        $filesToZip[$pid] = $pdfPath;
    } elseif (is_file($htmlPath) && is_readable($htmlPath)) {
        $filesToZip[$pid] = $htmlPath;
    }
}

// If nothing found
if (empty($filesToZip)) {
    flash_and_redirect('No invoice files found for your account.');
}

// 3) Ensure ZipArchive extension available
if (!class_exists('ZipArchive')) {
    flash_and_redirect('ZIP support is missing on the server. Please enable the PHP zip extension (php_zip).');
}

// 4) Create temp zip
$tempDir = sys_get_temp_dir();
$zipName = 'invoices_' . $uid . '_' . time() . '.zip';
$zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipName;

// Register shutdown cleanup in case script dies before unlink
$cleanup = function() use (&$zipPath) {
    if (isset($zipPath) && file_exists($zipPath)) {
        @unlink($zipPath);
    }
};
register_shutdown_function($cleanup);

$zip = new ZipArchive();
if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
    flash_and_redirect('Unable to create ZIP archive on server.');
}

// Add files to zip. Use basename in archive so ZIP doesn't contain full server paths.
foreach ($filesToZip as $pid => $fullPath) {
    $localName = basename($fullPath); // invoice_123.pdf or invoice_123.html
    // Avoid duplicate names: prefix with payment id if necessary
    if ($zip->locateName($localName) !== false) {
        $localName = $pid . '_' . $localName;
    }
    $zip->addFile($fullPath, $localName);
}
$zip->close();

// 5) Log the download (best-effort)
$logDir = __DIR__ . '/../logs';
if (!is_dir($logDir)) @mkdir($logDir, 0755, true);
$logFile = $logDir . '/invoices.log';
$logLine = date('Y-m-d H:i:s') . " | download_invoices_zip | user=" . $uid . " | files=" . implode(',', array_keys($filesToZip)) . " | zip=" . basename($zipPath) . PHP_EOL;
@file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);

// 6) Stream the zip to the user safely
if (!is_file($zipPath) || !is_readable($zipPath)) {
    flash_and_redirect('Failed to create ZIP archive.');
}

// Clear output buffers to avoid corrupting the zip
if (ob_get_level()) {
    ob_end_clean();
}

$filesize = filesize($zipPath);
$downloadName = 'invoices_' . date('Ymd_His') . '.zip';

// Send headers
header('Content-Description: File Transfer');
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $downloadName . '"');
header('Content-Transfer-Encoding: binary');
header('Content-Length: ' . $filesize);
header('Pragma: public');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');

// Stream in chunks (safer for large files)
$chunkSize = 1024 * 1024; // 1MB
$fp = fopen($zipPath, 'rb');
if ($fp === false) {
    flash_and_redirect('Failed to open archive for download.');
}
while (!feof($fp)) {
    echo fread($fp, $chunkSize);
    // flush output buffers so download continues
    flush();
}
fclose($fp);

// remove temp zip
@unlink($zipPath);

// success - exit
exit();
