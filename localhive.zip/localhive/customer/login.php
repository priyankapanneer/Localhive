<?php
// ---------------------------------------------
// CUSTOMER LOGIN (SECURE + UI ENHANCED)
// ---------------------------------------------
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../inc/db.php';

$msg = "";

// Handle login
if (isset($_POST['login'])) {

    $email = trim($_POST['email'] ?? '');
    $pass  = trim($_POST['password'] ?? '');

    if ($email !== '' && $pass !== '') {

        // Prepared statement (SQL Injection Safe)
        $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res && $res->num_rows === 1) {
            $data = $res->fetch_assoc();

            if (password_verify($pass, $data['password'])) {
                $_SESSION['customer_id'] = $data['id'];
                header("Location: dashboard.php");
                exit();
            } else {
                $msg = "Incorrect password!";
            }
        } else {
            $msg = "Email does not exist!";
        }

        $stmt->close();
    } else {
        $msg = "All fields are required.";
    }
}

$page_title = 'Customer Login';
$body_class = 'customer-auth';
require_once __DIR__ . '/../inc/components/header.php';
?>

<div class="d-flex align-items-center" style="min-height:70vh;">
  <div class="container lh-container">
    <div class="row justify-content-center">
      <div class="col-sm-10 col-md-7 col-lg-5">
        <div class="login-card lh-card">
          <div class="text-center mb-3">
            <h2 class="h4 mb-0">Customer Login</h2>
            <small class="lh-muted">Sign in to manage bookings and invoices</small>
          </div>

          <?php if ($msg): ?>
            <div class="alert alert-danger" role="alert"><?= htmlspecialchars($msg) ?></div>
          <?php endif; ?>

          <form method="POST" autocomplete="off">
            <div class="mb-3">
              <label class="form-label">Email Address</label>
              <input type="email" name="email" class="form-control" placeholder="you@example.com" required>
            </div>

            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" name="password" class="form-control" placeholder="••••••" required>
            </div>

            <div class="d-flex justify-content-between align-items-center mb-3">
              <div><input id="remember" name="remember" type="checkbox"> <label for="remember" class="small">Remember me</label></div>
              <a href="register.php" class="small">Create account</a>
            </div>

            <div class="d-grid">
              <button class="btn lh-btn lh-btn-primary" name="login">Sign in</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../inc/components/footer.php'; ?>
