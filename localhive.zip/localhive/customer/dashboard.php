<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../inc/db.php';

if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit();
}

$uid = intval($_SESSION['customer_id']);

function fetch_count($conn, $sql, $types = '', $params = []) {
    $stmt = $conn->prepare($sql);
    if ($types) $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res ? $res->fetch_row() : null;
    $stmt->close();
    return $row ? intval($row[0]) : 0;
}

function fetch_all_assoc($conn, $sql, $types = '', $params = []) {
    $stmt = $conn->prepare($sql);
    if ($types) $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $res = $stmt->get_result();
    $rows = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
    $stmt->close();
    return $rows;
}

$stmt = $conn->prepare("SELECT id, name, email, phone, pincode FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $uid);
$stmt->execute();
$cres = $stmt->get_result();
$customer = $cres ? $cres->fetch_assoc() : null;
$stmt->close();

if (!$customer) {
    session_destroy();
    header("Location: login.php");
    exit();
}

$totalBookings = fetch_count($conn, "SELECT COUNT(*) FROM bookings WHERE user_id = ?", "i", [$uid]);
$pendingBookings = fetch_count($conn, "SELECT COUNT(*) FROM bookings WHERE user_id = ? AND status = ?", "is", [$uid, 'pending']);
$completedBookingIdsCount = fetch_count($conn, "SELECT COUNT(*) FROM payments WHERE booking_id IN (SELECT id FROM bookings WHERE user_id = ? AND status IN ('completed','complete'))", "i", [$uid]);

$bookings_sql = "
    SELECT 
        b.id, b.booking_type, b.preferred_date, b.preferred_time, b.status, b.created_at,
        COALESCE(s.price, 0) AS service_price, COALESCE(s.title, '') AS service_title,
        COALESCE(p.name, '') AS provider_name
    FROM bookings b
    LEFT JOIN services s ON s.id = b.service_id
    LEFT JOIN providers p ON p.id = b.provider_id
    WHERE b.user_id = ?
    ORDER BY b.created_at DESC
";
$bookings = fetch_all_assoc($conn, $bookings_sql, "i", [$uid]);

// Notification emission removed: the persistent notification system was
// replaced with a notification bell. Recent booking updates are available
// via the bell and the bookings list below.

function get_successful_payment($conn, $bookingId) {
    $stmt = $conn->prepare("SELECT id, amount, status FROM payments WHERE booking_id = ? AND status IN ('success','paid') ORDER BY created_at DESC LIMIT 1");
    $stmt->bind_param("i", $bookingId);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res ? $res->fetch_assoc() : null;
    $stmt->close();
    return $row;
}

function invoice_links_for_payment($paymentId) {
    $invoiceDir = dirname(__DIR__) . '/exports/invoices';
    $pdfPath = $invoiceDir . '/invoice_' . $paymentId . '.pdf';
    $htmlPath = $invoiceDir . '/invoice_' . $paymentId . '.html';
    $links = [];
    if (file_exists($pdfPath)) $links['pdf'] = '../exports/invoices/invoice_' . $paymentId . '.pdf';
    if (file_exists($htmlPath)) $links['html'] = '../exports/invoices/invoice_' . $paymentId . '.html';
    return $links;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Customer Dashboard</title>

    <!-- Bootstrap 5 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <!-- Serif theme for refined UI -->
    <link rel="stylesheet" href="/localhive/assets/css/serif_theme.css">
</head>
<body>

<div class="container mt-5">

    <div class="lh-card lh-page-head mt-4 mb-3">
        <div class="lh-page-title">Welcome, <?= htmlspecialchars($customer['name']) ?>!</div>
        <div><a href="book_service.php" class="btn btn-primary">Book Service</a></div>
    </div>

    <div class="lh-grid">
        <!-- Aside Profile -->
        <aside class="lh-aside">
            <div class="d-flex align-items-center gap-3 mb-3">
                <div class="ecom-avatar" style="background:var(--lh-teal); color:#fff; width:64px; height:64px; font-size:24px; display:flex; align-items:center; justify-content:center; border-radius:12px;"><?= strtoupper(substr($customer['name'] ?? 'U', 0, 1)) ?></div>
                <div>
                    <div class="lh-profile-name"><?= htmlspecialchars($customer['name']) ?></div>
                    <div class="lh-profile-meta"><?= htmlspecialchars($customer['email']) ?></div>
                </div>
            </div>
            <hr>
            <p class="kv"><strong>Phone:</strong> <?= htmlspecialchars($customer['phone'] ?? '—') ?></p>
            <p class="kv"><strong>Pincode:</strong> <?= htmlspecialchars($customer['pincode'] ?? '—') ?></p>

            <div class="d-grid gap-2 mt-3">
                <a href="book_service.php" class="btn btn-primary">Book Service</a>
                <a href="invoices.php" class="btn btn-outline-secondary">Invoices</a>
                <a href="customer_logout.php" class="btn btn-outline-secondary">Logout</a>
            </div>
        </aside>

        <!-- Main Content -->
        <main>
            <!-- Stats Cards -->
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="lh-card text-center">
                        <h6 class="small-muted">Bookings</h6>
                        <div class="h3" style="color:var(--lh-teal); font-weight:700; font-size:1.6rem"><?= $totalBookings ?></div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="lh-card text-center">
                        <h6 class="small-muted">Pending</h6>
                        <div class="h3" style="color:#a07b44; font-weight:700; font-size:1.6rem"><?= $pendingBookings ?></div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="lh-card text-center">
                        <h6 class="small-muted">Invoices</h6>
                        <div class="h3" style="color:#47564a; font-weight:700; font-size:1.6rem"><?= $completedBookingIdsCount ?></div>
                    </div>
                </div>
            </div>

            <!-- Bookings Table -->
            <div class="lh-card">
                <div class="lh-page-head">
                    <div><strong>Your Bookings</strong></div>
                    <div class="lh-subtle">Latest activity</div>
                </div>
                <?php if (!empty($bookings)): ?>
                <div class="table-responsive">
                    <table class="lh-table">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Service</th>
                            <th>Provider</th>
                            <th>When</th>
                            <th>Status</th>
                            <th>Payment</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($bookings as $b): 
                            $isEmergency = ($b['booking_type'] ?? '') === 'emergency';
                            $rowClass = $isEmergency ? 'emergency' : '';
                            $statusLower = strtolower($b['status'] ?? '');
                            $payment = get_successful_payment($conn, intval($b['id']));
                            $payLinks = $payment ? invoice_links_for_payment(intval($payment['id'])) : [];
                            $displayPrice = number_format(floatval($b['service_price'] ?? 0.00), 2);
                        ?>
                            <tr class="<?= $rowClass ?>">
                                <td><?= intval($b['id']) ?></td>
                                <td>
                                    <?= htmlspecialchars($b['service_title'] ?: 'Service') ?>
                                    <?php if ($isEmergency): ?>
                                        <span class="lh-badge warn ms-2">EMERGENCY</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($b['provider_name'] ?: '—') ?></td>
                                <td><?= htmlspecialchars($b['preferred_date'] ?: date('Y-m-d', strtotime($b['created_at'] ?? 'now'))) ?> <?= htmlspecialchars($b['preferred_time'] ?? '') ?></td>
                                <td><span class="lh-badge <?= $statusLower === 'completed' ? 'success' : ($statusLower === 'pending' ? 'pending' : '') ?>"><?= htmlspecialchars(ucfirst($b['status'] ?? '')) ?></span></td>
                                <td>
                                    <?php if ($payment): ?>
                                        <span class="lh-badge success">Paid</span>
                                        <?php if (!empty($payLinks['pdf'])): ?>
                                            <a class="btn btn-sm btn-outline-secondary ms-2" href="<?= htmlspecialchars($payLinks['pdf']) ?>" target="_blank">PDF</a>
                                        <?php endif; ?>
                                        <?php if (!empty($payLinks['html'])): ?>
                                            <a class="btn btn-sm btn-outline-secondary ms-2" href="<?= htmlspecialchars($payLinks['html']) ?>" target="_blank">HTML</a>
                                        <?php endif; ?>
                                        <?php if (empty($payLinks)): ?>
                                            <a class="btn btn-sm btn-outline-secondary ms-2" href="invoices.php">View Invoice</a>
                                        <?php endif; ?>
                                        <a class="btn btn-sm btn-outline-secondary ms-2" href="report_payment_issue.php?booking_id=<?= intval($b['id']) ?>">Report</a>
                                    <?php elseif (in_array($statusLower, ['completed','complete'])): ?>
                                        <a class="btn btn-sm btn-primary" href="make_payment.php?booking_id=<?= intval($b['id']) ?>">Pay Now (₹ <?= $displayPrice ?>)</a>
                                    <?php else: ?>
                                        <span class="kv">Not payable</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                    <p class="text-muted">You have no bookings yet.</p>
                <?php endif; ?>
            </div>
        </main>
    </div>
</div>

<?php include_once __DIR__ . '/../inc/site_footer.php'; ?>
</body>
</html>
