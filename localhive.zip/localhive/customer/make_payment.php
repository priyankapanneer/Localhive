<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once('../inc/db.php');

if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit();
}

$uid = intval($_SESSION['customer_id']);

// ----------------------
// Utility Functions
// ----------------------
function fetchOne($conn, $sql) {
    $res = mysqli_query($conn, $sql);
    return ($res && mysqli_num_rows($res) > 0) ? mysqli_fetch_assoc($res) : null;
}

function buildInvoiceHTML($id, $cust, $prov, $service, $total, $admin_fee, $provider_earning) {
    return "
    <html><head><meta charset='utf-8'>
    <title>Invoice #$id</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        table { width: 60%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #555; padding: 8px; }
    </style>
    </head>
    <body>
    <h2>Invoice #$id</h2>
    <p><strong>Date:</strong> ".date('Y-m-d H:i:s')."</p>

    <p><strong>Customer:</strong> ".htmlspecialchars($cust['customer_name'])." (".htmlspecialchars($cust['customer_email']).")</p>
    <p><strong>Provider:</strong> ".htmlspecialchars($prov['provider_name'])."</p>
    <p><strong>Service:</strong> ".htmlspecialchars($service['title'])."</p>

    <table>
        <tr><th>Description</th><th>Amount</th></tr>
        <tr><td>Service Charge</td><td>₹".number_format($service['price'],2)."</td></tr>
        <tr><td>Admin Fee (10%)</td><td>₹".number_format($admin_fee,2)."</td></tr>
        <tr><td><strong>Total</strong></td><td><strong>₹".number_format($total,2)."</strong></td></tr>
    </table>
    </body>
    </html>";
}

function generateInvoice($conn, $booking_id, $payment_id) {
    $invoiceDir = dirname(__DIR__) . '/exports/invoices';

    if (!is_dir($invoiceDir)) mkdir($invoiceDir, 0755, true);

    $cust = fetchOne($conn, "SELECT u.name AS customer_name, u.email AS customer_email 
                             FROM bookings b 
                             JOIN users u ON u.id=b.user_id 
                             WHERE b.id=$booking_id LIMIT 1");

    $prov = fetchOne($conn, "SELECT p.name AS provider_name 
                             FROM bookings b 
                             JOIN providers p ON p.id=b.provider_id 
                             WHERE b.id=$booking_id LIMIT 1");

    $service = fetchOne($conn, "SELECT s.title, s.price 
                                FROM bookings b 
                                JOIN services s ON s.id=b.service_id 
                                WHERE b.id=$booking_id LIMIT 1");

    $amount = floatval($service['price']);
    $admin_fee = round($amount * 0.10, 2);
    $total = $amount; // Your logic uses service price as final total

    $html = buildInvoiceHTML($payment_id, $cust, $prov, $service, $total, $admin_fee, $total - $admin_fee);

    file_put_contents("$invoiceDir/invoice_$payment_id.html", $html);
}

// ----------------------
// Validate booking
// ----------------------
$booking_id = intval($_GET['booking_id'] ?? $_POST['booking_id'] ?? 0);

$booking = fetchOne($conn,
    "SELECT b.*, s.title AS service_title, s.price AS service_price, p.name AS provider_name
     FROM bookings b
     JOIN services s ON s.id=s.id
     JOIN providers p ON p.id=b.provider_id
     WHERE b.id=$booking_id AND b.user_id=$uid
     LIMIT 1"
);

if (!$booking) die("Booking not found or not accessible.");

if (!in_array(strtolower($booking['status']), ['completed', 'complete'])) {
    die("Payment can only be made for completed bookings.");
}

$exists = fetchOne($conn,
    "SELECT id FROM payments 
     WHERE booking_id=$booking_id AND status IN ('success','paid') LIMIT 1"
);

if ($exists) die("This booking is already paid.");

// ----------------------
// Payment Handler
// ----------------------
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $method = trim($_POST['method'] ?? '');

    if ($method === '') $errors[] = "Please select a payment method.";

    if (!$errors) {

        $amount = floatval($booking['service_price']);
        $admin_fee = round($amount * 0.10, 2);
        $provider_earning = $amount - $admin_fee;

        // check for pending
        $pending = fetchOne($conn, 
            "SELECT id FROM payments 
             WHERE booking_id=$booking_id AND status='pending' 
             ORDER BY created_at DESC LIMIT 1"
        );

        if ($pending) {
            $pid = intval($pending['id']);

            mysqli_query($conn, 
                "UPDATE payments SET status='success', created_at=NOW() WHERE id=$pid"
            );

            generateInvoice($conn, $booking_id, $pid);

        } else {
            mysqli_query($conn,
                "INSERT INTO payments (booking_id, amount, status, provider_earning, admin_fee, created_at)
                VALUES ($booking_id, '$amount', 'success', '$provider_earning', '$admin_fee', NOW())"
            );
            $pid = mysqli_insert_id($conn);

            generateInvoice($conn, $booking_id, $pid);
        }

        header("Location: dashboard.php?payment=success");
        exit();
    }
}
?>

$page_title = 'Make Payment';
$body_class = 'customer-make-payment';
require_once __DIR__ . '/../inc/components/header.php';

<div class="container mt-5">
    <div class="col-md-8 mx-auto">
        <div class="card p-4">
            <h3 class="pay-header mb-3">Payment for Booking #<?= $booking['id'] ?></h3>

            <p>
                <strong>Service:</strong> <?= htmlspecialchars($booking['service_title']) ?><br>
                <strong>Provider:</strong> <?= htmlspecialchars($booking['provider_name']) ?><br>
                <strong>Amount:</strong> <span class="text-success fw-bold">₹<?= number_format($booking['service_price'], 2) ?></span>
            </p>

            <?php if ($errors): ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $e): ?>
                        <div><?= htmlspecialchars($e) ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="booking_id" value="<?= $booking['id'] ?>">

                <div class="mb-3">
                    <label class="form-label">Choose Payment Method</label>
                    <select name="method" class="form-select" required>
                        <option value="">-- Select Payment Method --</option>
                        <option value="credit_card">Credit Card</option>
                        <option value="debit_card">Debit Card</option>
                        <option value="netbanking">Netbanking</option>
                        <option value="gpay">GPay (UPI)</option>
                        <option value="phonepe">PhonePe (UPI)</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">(Simulated) Enter mock details</label>
                    <input type="text" class="form-control" name="mock_info" placeholder="UPI / Card / Bank info">
                </div>

                <button class="btn btn-success px-4">
                    Pay ₹<?= number_format($booking['service_price'],2) ?>
                </button>

                <a href="dashboard.php" class="btn btn-secondary ms-2">Cancel</a>
            </form>
        </div>
    </div>
</div>

</body>
</html>
