<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include('../inc/db.php');

if(!isset($_SESSION['customer_id'])){
    header('Location: login.php');
    exit();
}
$uid = intval($_SESSION['customer_id']);
$customer = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id=$uid"));

// fetch payments for this customer's bookings
$q = "SELECT pa.*, b.id AS booking_id, s.title AS service_title, s.price AS service_price, b.provider_id
      FROM payments pa
      JOIN bookings b ON b.id = pa.booking_id
      JOIN services s ON s.id = b.service_id
      WHERE b.user_id = $uid
      ORDER BY pa.created_at DESC";
$res = mysqli_query($conn, $q);

?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Your Invoices</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/localhive/assets/css/serif_theme.css">
    <link rel="stylesheet" href="/localhive/assets/css/styles.css">
        <link rel="stylesheet" href="/localhive/assets/css/ecommerce.css">
        <link rel="stylesheet" href="/localhive/assets/css/admin_theme.css">
</head>
<body class="ecom-body admin-theme">
<?php include_once __DIR__ . '/../inc/customer_sidebar.php'; ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center">
    <?php if(!empty($_SESSION['flash_message'])): ?>
        <div class="alert alert-info"><?php echo htmlspecialchars($_SESSION['flash_message']); unset($_SESSION['flash_message']); ?></div>
    <?php endif; ?>
        <h3>Invoices for <?= htmlspecialchars($customer['name'] ?? ''); ?></h3>
        <div>
            <a href="download_invoices.php" class="btn btn-sm btn-outline-success">Download All (ZIP)</a>
            <a href="dashboard.php" class="btn btn-sm btn-secondary ms-2">Back</a>
        </div>
    </div>
    <hr>
    <?php if($res && mysqli_num_rows($res) > 0): ?>
    <div class="table-responsive">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Payment ID</th>
                <th>Booking ID</th>
                <th>Service</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
                <th>Invoice</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php while($r = mysqli_fetch_assoc($res)): 
            $paymentId = intval($r['id']);
            $invoiceDir = dirname(__DIR__) . '/exports/invoices';
            $pdfPath = $invoiceDir . '/invoice_' . $paymentId . '.pdf';
            $htmlPath = $invoiceDir . '/invoice_' . $paymentId . '.html';
        ?>
            <tr>
                <td><?= $paymentId ?></td>
                <td><?= intval($r['booking_id']) ?></td>
                <td><?= htmlspecialchars($r['service_title']) ?></td>
                <td>₹ <?= number_format(floatval($r['amount']),2) ?></td>
                <td><?= htmlspecialchars($r['status']) ?></td>
                <td><?= htmlspecialchars($r['created_at']) ?></td>
                <td>
                    <?php if (file_exists($pdfPath)): ?>
                        <a class="btn btn-sm btn-outline-primary" href="<?= '../exports/invoices/invoice_' . $paymentId . '.pdf' ?>" target="_blank" title="Download PDF">
                            <!-- PDF SVG icon -->
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-earmark-pdf" viewBox="0 0 16 16">
                              <path d="M5.5 6.5v3h1v-1h.5a.5.5 0 0 0 0-1H6.5v-1h-.999z"/>
                              <path d="M14 4.5V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5zM9.5 3v1a1 1 0 0 0 1 1h1l-2-2z"/>
                            </svg>
                        </a>
                    <?php endif; ?>
                    <?php if (file_exists($htmlPath)): ?>
                        <a class="btn btn-sm btn-outline-secondary ms-1" href="<?= '../exports/invoices/invoice_' . $paymentId . '.html' ?>" target="_blank" title="Open HTML">
                            <!-- HTML icon -->
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-text" viewBox="0 0 16 16">
                              <path d="M4 0h6l2 2v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V1a1 1 0 0 1 1-1z"/>
                              <path d="M5 7.5h6v1H5v-1zm0 2.5h6v1H5v-1z"/>
                            </svg>
                        </a>
                    <?php endif; ?>
                    <?php if (!file_exists($pdfPath) && !file_exists($htmlPath)): ?>
                        <span class="text-muted">Not generated</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a class="btn btn-sm btn-danger" href="report_payment_issue.php?booking_id=<?= intval($r['booking_id']) ?>">Report Issue</a>
                    <?php if (!file_exists($pdfPath) && !file_exists($htmlPath)): ?>
                        <a class="btn btn-sm btn-outline-secondary ms-1" href="regenerate_invoice.php?payment_id=<?= $paymentId ?>">Regenerate</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    </div>
    <?php else: ?>
        <p class="text-muted">No invoices found.</p>
    <?php endif; ?>
</div>
<?php include_once __DIR__ . '/../inc/site_footer.php'; ?>

</div> <!-- main-content end -->

</body>
</html>
