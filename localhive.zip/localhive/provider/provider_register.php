<?php
// provider_register.php
session_start();
require_once('../inc/db.php');

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = trim($_POST['password']);
    $phone    = trim($_POST['phone'] ?? '');
    $address  = trim($_POST['address'] ?? '');
    $pincode  = trim($_POST['pincode'] ?? '');
    $lat      = $_POST['lat'] !== '' ? floatval($_POST['lat']) : NULL;
    $lng      = $_POST['lng'] !== '' ? floatval($_POST['lng']) : NULL;

    // Strong password check
    if (strlen($password) < 6) {
        $msg = "Password must be at least 6 characters.";
    } else {
        // Duplicate email check
        $stmt = $conn->prepare("SELECT id FROM providers WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $msg = "Email already registered.";
        } else {
            $stmt->close();

            // Insert provider
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            $approved = 0;

                $stmt = $conn->prepare("
                    INSERT INTO providers 
                    (name, email, password, phone, address, pincode, lat, lng, approved, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                ");

                // Bind exactly 9 variables for the 9 placeholders (name,email,password,phone,address,pincode,lat,lng,approved)
                // types: s = string, d = double, i = integer
                $stmt->bind_param(
                    "ssssssddi",
                    $name,
                    $email,
                    $hashedPassword,
                    $phone,
                    $address,
                    $pincode,
                    $lat,
                    $lng,
                    $approved
                );

            

            if ($stmt->execute()) {
                $msg = "Registered successfully! Please wait for admin approval.";
            } else {
                $msg = "Registration failed: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Provider Registration • LocalHive</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="/localhive/assets/css/styles.css">
<link rel="stylesheet" href="/localhive/assets/css/ecommerce.css">
<link rel="stylesheet" href="/localhive/assets/css/admin_theme.css">

<style>
    body {
        background: #f5f7fa;
    }
    .register-card {
        max-width: 550px;
        margin: 60px auto;
        padding: 35px;
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 8px 22px rgba(0,0,0,0.12);
        transition: .25s;
    }
    .register-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 28px rgba(0,0,0,0.16);
    }
    .btn-brand {
        background: #007E6E;
        color: #fff;
        border: none;
        font-weight: 600;
        transition: .25s;
    }
    .btn-brand:hover {
        background: #059c85;
    }
    a {
        color: #007E6E;
        text-decoration: none;
    }
    a:hover {
        color: #059c85;
    }
</style>

</head>
<body>

<div class="register-card">
    <h3 class="text-center mb-4 fw-bold">Provider Registration</h3>

    <?php if ($msg): ?>
        <div class="alert alert-info"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <form method="post" onsubmit="return validateForm();">

        <div class="mb-3">
            <label class="form-label fw-semibold">Full Name</label>
            <input name="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label fw-semibold">Email</label>
            <input name="email" type="email" class="form-control" required autocomplete="email">
        </div>

        <div class="mb-3">
            <label class="form-label fw-semibold">Password</label>
            <input name="password" type="password" class="form-control" required autocomplete="new-password">
        </div>

        <div class="mb-3">
            <label class="form-label fw-semibold">Phone</label>
            <input name="phone" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label fw-semibold">Full Address</label>
            <textarea name="address" class="form-control"></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label fw-semibold">Pincode / ZIP</label>
            <input name="pincode" class="form-control">
        </div>

        <div class="row mb-3">
            <div class="col">
                <label class="form-label fw-semibold">Latitude (optional)</label>
                <input id="lat" name="lat" class="form-control">
            </div>
            <div class="col">
                <label class="form-label fw-semibold">Longitude (optional)</label>
                <input id="lng" name="lng" class="form-control">
            </div>
        </div>

        <button class="btn btn-brand w-100 py-2">Register</button>

        <p class="text-center mt-3 mb-0">
            Already registered? <a href="provider_login.php">Login</a>
        </p>
    </form>
</div>

<script>
function validateForm() {
    const pass = document.querySelector('input[name="password"]').value;
    if (pass.length < 6) {
        alert("Password must be at least 6 characters.");
        return false;
    }
    return true;
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
