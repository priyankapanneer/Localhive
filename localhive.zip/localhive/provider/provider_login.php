<?php
// provider_login.php
session_start();
require_once('../inc/db.php');

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $pass  = $_POST['password'];

    // Secure
    $stmt = $conn->prepare("SELECT id,name,password,approved FROM providers WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($row = $res->fetch_assoc()) {
        if (!password_verify($pass, $row['password'])) {
            $msg = "Invalid credentials.";
        } elseif ((int)$row['approved'] !== 1) {
            $msg = "Your account is not approved yet by admin.";
        } else {
            $_SESSION['provider_id']    = $row['id'];
            $_SESSION['provider_name']  = $row['name'];
            header("Location: provider_dashboard.php");
            exit();
        }
    } else {
        $msg = "No account found with that email.";
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Provider Login • LocalHive</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="/localhive/assets/css/styles.css">
<link rel="stylesheet" href="/localhive/assets/css/ecommerce.css">
<link rel="stylesheet" href="/localhive/assets/css/admin_theme.css">

<style>
    body {
        background: #f3f5f7;
    }
    .login-card {
        max-width: 420px;
        margin: 80px auto;
        background: #ffffff;
        border-radius: 16px;
        padding: 35px 30px;
        box-shadow: 0 6px 20px rgba(0,0,0,0.12);
        transition: .25s;
    }
    .login-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 10px 26px rgba(0,0,0,0.18);
    }
    .btn-brand {
        background: #007E6E;
        color: #fff;
        border: none;
    }
    .btn-brand:hover {
        background: #059c85;
    }
    a {
        color: #007E6E;
        text-decoration: none;
    }
    a:hover {
        color: #059c85;
    }
</style>

</head>
<body>

<div class="login-card">
    <h3 class="text-center mb-4 fw-bold">Provider Login</h3>

    <?php if (!empty($msg)): ?>
        <div class="alert alert-danger small"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <form method="post" novalidate>
        <div class="mb-3">
            <label class="form-label fw-semibold">Email</label>
            <input type="email" name="email" class="form-control" required autocomplete="email">
        </div>

        <div class="mb-3">
            <label class="form-label fw-semibold">Password</label>
            <input type="password" name="password" class="form-control" required autocomplete="current-password">
        </div>

        <button type="submit" class="btn btn-brand w-100 py-2 fw-semibold">Login</button>

        <p class="text-center mt-3 mb-0">
            New provider? <a href="provider_register.php">Create account</a>
        </p>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
