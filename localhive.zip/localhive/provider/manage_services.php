<?php
// manage_services.php (refactored)
// - Prepared statements for all DB writes
// - CSRF token + POST->Redirect->GET to avoid double submits
// - Bootstrap modal used for Edit (no duplicate edit form)
// - Sanitized output, simple server-side validation
// - Flash messages stored in session
session_start();
require_once __DIR__ . '/../inc/db.php';

if (!isset($_SESSION['provider_id'])) {
    header("Location: provider_login.php");
    exit();
}

$pid = intval($_SESSION['provider_id']);

// initialize flash
if (!isset($_SESSION['flash'])) $_SESSION['flash'] = null;

// CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
}
$csrf = $_SESSION['csrf_token'];

// Helper to set flash and redirect
function flash_and_redirect($msg, $type = 'info', $loc = 'manage_services.php') {
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
    header("Location: $loc");
    exit();
}

// ---------------------------
// Handle POST actions
// ---------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // basic CSRF check
    $posted_token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], $posted_token)) {
        flash_and_redirect('Invalid CSRF token.', 'danger');
    }

    // ADD SERVICE
    if (isset($_POST['add_service'])) {
        $title = trim($_POST['title'] ?? '');
        $desc  = trim($_POST['description'] ?? '');
        $price = isset($_POST['price']) ? floatval($_POST['price']) : 0.0;
        $dur   = isset($_POST['duration']) ? intval($_POST['duration']) : 0;

        // server side validation
        if ($title === '' || $price <= 0 || $dur <= 0) {
            flash_and_redirect('Please provide valid Title, Price and Duration.', 'danger');
        }

        $stmt = $conn->prepare("INSERT INTO services (provider_id, title, description, price, duration_minutes, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param('issdi', $pid, $title, $desc, $price, $dur);
        if ($stmt->execute()) {
            $stmt->close();
            flash_and_redirect('Service added successfully!', 'success');
        } else {
            $err = $stmt->error;
            $stmt->close();
            flash_and_redirect("Error adding service: $err", 'danger');
        }
    }

    // EDIT SERVICE
    if (isset($_POST['edit_service'])) {
        $sid   = intval($_POST['service_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $desc  = trim($_POST['description'] ?? '');
        $price = isset($_POST['price']) ? floatval($_POST['price']) : 0.0;
        $dur   = isset($_POST['duration']) ? intval($_POST['duration']) : 0;

        if ($sid <= 0 || $title === '' || $price <= 0 || $dur <= 0) {
            flash_and_redirect('Invalid input for update.', 'danger');
        }

        $stmt = $conn->prepare("UPDATE services SET title = ?, description = ?, price = ?, duration_minutes = ? WHERE id = ? AND provider_id = ?");
        $stmt->bind_param('ssdiii', $title, $desc, $price, $dur, $sid, $pid);
        if ($stmt->execute()) {
            $stmt->close();
            flash_and_redirect('Service updated successfully!', 'success');
        } else {
            $err = $stmt->error;
            $stmt->close();
            flash_and_redirect("Error updating service: $err", 'danger');
        }
    }
}

// ---------------------------
// Handle GET delete (safe, requires confirm on client)
// ---------------------------
if (isset($_GET['delete'])) {
    $sid = intval($_GET['delete']);
    if ($sid > 0) {
        $stmt = $conn->prepare("DELETE FROM services WHERE id = ? AND provider_id = ?");
        $stmt->bind_param('ii', $sid, $pid);
        $stmt->execute();
        $affected = $stmt->affected_rows;
        $stmt->close();
        if ($affected > 0) {
            flash_and_redirect('Service deleted.', 'success');
        } else {
            flash_and_redirect('Service not found or not allowed.', 'warning');
        }
    } else {
        flash_and_redirect('Invalid service id.', 'danger');
    }
}

// ---------------------------
// Fetch services for provider
// ---------------------------
$stmt = $conn->prepare("SELECT id, title, description, price, duration_minutes, created_at FROM services WHERE provider_id = ? ORDER BY id DESC");
$stmt->bind_param('i', $pid);
$stmt->execute();
$services_res = $stmt->get_result();
$services = $services_res->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// show and clear flash
$flash = $_SESSION['flash'];
$_SESSION['flash'] = null;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Manage Services</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="/localhive/assets/css/styles.css">
<link rel="stylesheet" href="/localhive/assets/css/ecommerce.css">
<link rel="stylesheet" href="/localhive/assets/css/admin_theme.css">
<style>
  .card-custom { border-radius:12px; }
  .btn-primary { background:#007E6E; border:none; }
  .btn-primary:hover { background:#046a59; }
  .table thead { background:#007E6E; color:#fff; }
  .service-desc { white-space:pre-wrap; color:#333; }
</style>
</head>
<body class="ecom-body admin-theme">
<?php include_once __DIR__ . '/../inc/provider_sidebar.php'; ?>

<div class="container py-4">

  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0">Your Services</h3>
    <a class="btn btn-outline-secondary" href="provider_dashboard.php">Back to Dashboard</a>
  </div>

  <?php if ($flash): ?>
    <div class="alert alert-<?= htmlspecialchars($flash['type'] ?? 'info') ?> alert-dismissible fade show">
      <?= htmlspecialchars($flash['msg']) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <!-- Add Service -->
  <div class="card card-custom p-3 mb-4 shadow-sm">
    <h5 class="mb-3">Add New Service</h5>
    <form method="post" class="row g-2">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
      <div class="col-md-5">
        <input name="title" class="form-control" placeholder="Service Title" required maxlength="191">
      </div>
      <div class="col-md-4">
        <input name="price" type="number" step="0.01" class="form-control" placeholder="Price" required min="0.01">
      </div>
      <div class="col-md-3">
        <input name="duration" type="number" class="form-control" placeholder="Duration (mins)" required min="1">
      </div>
      <div class="col-12">
        <textarea name="description" class="form-control mt-2" placeholder="Short description (optional)" rows="3" maxlength="1000"></textarea>
      </div>
      <div class="col-12">
        <button name="add_service" class="btn btn-primary mt-2 w-100">Add Service</button>
      </div>
    </form>
  </div>

  <!-- Existing Services -->
  <div class="card card-custom p-3 shadow-sm">
    <h5 class="mb-3">Existing Services</h5>
    <div class="table-responsive">
      <table class="table table-striped table-hover align-middle">
        <thead>
          <tr>
            <th style="width:70px">ID</th>
            <th>Title & Description</th>
            <th style="width:140px">Price</th>
            <th style="width:130px">Duration</th>
            <th style="width:180px">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($services as $s): ?>
          <tr>
            <td><?= (int)$s['id'] ?></td>
            <td>
              <strong><?= htmlspecialchars($s['title']) ?></strong><br>
              <div class="service-desc small mt-1"><?= htmlspecialchars($s['description'] ?: '—') ?></div>
              <div class="text-muted small mt-1">Added: <?= htmlspecialchars(date('d M Y', strtotime($s['created_at']))) ?></div>
            </td>
            <td>₹ <?= number_format((float)$s['price'], 2) ?></td>
            <td><?= (int)$s['duration_minutes'] ?> mins</td>
            <td>
              <button class="btn btn-sm btn-outline-primary me-1" 
                      data-bs-toggle="modal" data-bs-target="#editModal"
                      data-id="<?= (int)$s['id'] ?>"
                      data-title="<?= htmlspecialchars($s['title'], ENT_QUOTES) ?>"
                      data-price="<?= htmlspecialchars($s['price'], ENT_QUOTES) ?>"
                      data-duration="<?= (int)$s['duration_minutes'] ?>"
                      data-desc="<?= htmlspecialchars($s['description'], ENT_QUOTES) ?>">
                Edit
              </button>

              <a href="manage_services.php?delete=<?= (int)$s['id'] ?>" 
                 class="btn btn-sm btn-danger"
                 onclick="return confirm('Are you sure you want to delete this service?');">Delete</a>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($services)): ?>
          <tr><td colspan="5" class="text-center text-muted">No services found.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <form method="post" id="editForm">
        <div class="modal-header">
          <h5 class="modal-title">Edit Service</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
          <input type="hidden" name="service_id" id="service_id">
          <div class="mb-3">
            <label class="form-label">Title</label>
            <input id="etitle" name="title" class="form-control" required maxlength="191">
          </div>
          <div class="row g-2">
            <div class="col-md-6 mb-3">
              <label class="form-label">Price</label>
              <input id="eprice" name="price" type="number" step="0.01" class="form-control" required min="0.01">
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Duration (mins)</label>
              <input id="eduration" name="duration" type="number" class="form-control" required min="1">
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea id="edesc" name="description" class="form-control" rows="4" maxlength="1000"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button name="edit_service" class="btn btn-success">Save Changes</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  // populate edit modal from data attributes
  var editModal = document.getElementById('editModal');
  editModal.addEventListener('show.bs.modal', function (event) {
    var button = event.relatedTarget;
    var id = button.getAttribute('data-id');
    var title = button.getAttribute('data-title');
    var price = button.getAttribute('data-price');
    var duration = button.getAttribute('data-duration');
    var desc = button.getAttribute('data-desc');

    document.getElementById('service_id').value = id;
    document.getElementById('etitle').value = title;
    document.getElementById('eprice').value = price;
    document.getElementById('eduration').value = duration;
    document.getElementById('edesc').value = desc;
  });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?php include_once __DIR__ . '/../inc/site_footer.php'; ?>
</body>
</html>
