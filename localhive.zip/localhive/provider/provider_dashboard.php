<?php
// provider_dashboard.php (refactored & UI-enhanced)
session_start();
require_once __DIR__ . '/../inc/db.php';

// Auth
if (!isset($_SESSION['provider_id'])) {
    header("Location: provider_login.php");
    exit();
}
$pid = intval($_SESSION['provider_id']);

// Provider name (take from session if available, otherwise fetch)
$providerName = $_SESSION['provider_name'] ?? null;
if (!$providerName) {
    $pstmt = $conn->prepare("SELECT name FROM providers WHERE id = ? LIMIT 1");
    $pstmt->bind_param('i', $pid);
    if ($pstmt->execute()) {
        $pres = $pstmt->get_result();
        $prow = $pres->fetch_assoc();
        $providerName = $prow['name'] ?? 'Provider';
    } else {
        $providerName = 'Provider';
    }
    $pstmt->close();
}

// Helper: get single int result
function get_count($conn, $sql, $types = '', $params = []) {
    $stmt = $conn->prepare($sql);
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    return intval($row[array_key_first($row)] ?? 0);
}

// Stats
$completed = get_count($conn,
    "SELECT COUNT(*) AS c FROM bookings WHERE provider_id = ? AND status = 'completed'",
    'i', [$pid]);

$pending = get_count($conn,
    "SELECT COUNT(*) AS c FROM bookings WHERE provider_id = ? AND status = 'pending'",
    'i', [$pid]);

// Earnings: sum provider_earning for successful payments related to this provider
$stmt = $conn->prepare("
    SELECT IFNULL(SUM(p.provider_earning),0) AS total
    FROM payments p
    JOIN bookings b ON p.booking_id = b.id
    WHERE b.provider_id = ? AND p.status = 'success'
");
$stmt->bind_param('i', $pid);
$stmt->execute();
$res = $stmt->get_result();
$earningsRow = $res->fetch_assoc();
$earnings = floatval($earningsRow['total'] ?? 0.00);
$stmt->close();

// Recent bookings (limit 8) - use prepared statement
$stmt = $conn->prepare("
    SELECT b.id, b.booking_type, b.preferred_date, b.preferred_time, b.expected_arrival, b.actual_arrival, b.status,
           u.name AS customer_name, s.title AS service_title, b.created_at
    FROM bookings b
    JOIN users u ON u.id = b.user_id
    JOIN services s ON s.id = b.service_id
    WHERE b.provider_id = ?
    ORDER BY b.created_at DESC
    LIMIT 8
");
$stmt->bind_param('i', $pid);
$stmt->execute();
$bookingsRes = $stmt->get_result();
$bookings = $bookingsRes->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Provider Dashboard — <?= htmlspecialchars($providerName) ?></title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="/localhive/assets/css/styles.css">
<link rel="stylesheet" href="/localhive/assets/css/ecommerce.css">
<link rel="stylesheet" href="/localhive/assets/css/admin_theme.css">
<style>
  /* Small, focused styles for the provider dashboard */
  :root { --brand: #007E6E; --accent: #73AF6F; --muted: #6c757d; }
  body { background:#f6f7f9; }
  .stat-card { background:#fff; border-radius:12px; padding:18px; box-shadow:0 6px 18px rgba(0,0,0,0.06); }
  .stat-card h6 { color:var(--brand); font-weight:700; margin-bottom:8px; }
  .stat-card .num { font-size:1.9rem; font-weight:800; color:#0b5345; }
  .table-head-brand thead { background: linear-gradient(90deg,var(--brand), var(--accent)); color:#fff; }
  .badge-status { padding:.4em .65em; border-radius:10px; font-weight:700; }
  .badge-status.bg-warning { background:#ffca2c; color:#000; }
  .badge-status.bg-primary { background:#0d6efd; color:#fff; }
  .badge-status.bg-danger { background:#dc3545; color:#fff; }
  .badge-status.bg-success { background:#28a745; color:#fff; }
  .ecom-card { background:#fff; border-radius:12px; padding:16px; box-shadow:0 6px 18px rgba(0,0,0,0.04); }
  @media (max-width:767px){ .stat-card { text-align:center } }
</style>
</head>
<body class="ecom-body admin-theme">
<?php include_once __DIR__ . '/../inc/provider_sidebar.php'; ?>

<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <h3 class="mb-0">Welcome, <?= htmlspecialchars($providerName) ?></h3>
      <small class="text-muted">Manage your services, bookings and earnings</small>
    </div>
    <div>
      <!-- action placeholders (use sidebar) -->
    </div>
  </div>

  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <div class="stat-card text-center">
        <h6>Total Completed</h6>
        <div class="num"><?= $completed ?></div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="stat-card text-center">
        <h6>Pending</h6>
        <div class="num"><?= $pending ?></div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="stat-card text-center">
        <h6>Earnings</h6>
        <div class="num">₹ <?= number_format($earnings, 2) ?></div>
      </div>
    </div>
  </div>

  <h5 class="mb-3">Recent Bookings</h5>
  <div class="table-responsive ecom-card">
    <table class="table table-hover align-middle">
      <thead class="table-head-brand">
        <tr>
          <th style="width:70px">ID</th>
          <th>Customer</th>
          <th>Service</th>
          <th>Type</th>
          <th>Expected</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (count($bookings) === 0): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">No bookings found.</td></tr>
        <?php else: foreach ($bookings as $r): 
            $status = strtolower($r['status'] ?? '');
            $statusClass = 'bg-secondary text-white';
            if ($status === 'pending') $statusClass = 'bg-warning text-dark';
            if ($status === 'accepted') $statusClass = 'bg-primary text-white';
            if ($status === 'rejected') $statusClass = 'bg-danger text-white';
            if ($status === 'completed') $statusClass = 'bg-success text-white';

            // expected arrival: prefer expected_arrival, else show preferred_date + preferred_time
            $expected = $r['expected_arrival'];
            if (empty($expected)) {
                $expectedDate = $r['preferred_date'] ? date('d M Y', strtotime($r['preferred_date'])) : '';
                $expectedTime = $r['preferred_time'] ? date('H:i', strtotime($r['preferred_time'])) : '';
                $expected = trim($expectedDate . ' ' . $expectedTime);
                if ($expected === '') $expected = '—';
            } else {
                $expected = date('d M Y, H:i', strtotime($expected));
            }
        ?>
        <tr>
          <td><?= (int)$r['id'] ?></td>
          <td><?= htmlspecialchars($r['customer_name']) ?></td>
          <td><?= htmlspecialchars($r['service_title']) ?></td>
          <td><?= ucfirst(htmlspecialchars($r['booking_type'] ?? '')) ?></td>
          <td><?= htmlspecialchars($expected) ?></td>
          <td><span class="badge-status <?= htmlspecialchars($statusClass) ?>"><?= ucfirst(htmlspecialchars($r['status'])) ?></span></td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?php include_once __DIR__ . '/../inc/site_footer.php'; ?>
</body>
</html>
