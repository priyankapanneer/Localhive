<?php
// provider_download_reports.php
session_start();
include('../inc/db.php');

if (!isset($_SESSION['provider_id'])) {
    header("Location: provider_login.php");
    exit;
}

$pid = intval($_SESSION['provider_id']);
$filename = "provider_report_{$pid}_" . date('Ymd_His') . ".csv";

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment;filename="'.$filename.'"');

// Emit UTF-8 BOM so Excel recognizes UTF-8 encoding
echo "\xEF\xBB\xBF";

$out = fopen('php://output', 'w');

// Provider Info
$prov = mysqli_fetch_assoc(mysqli_query($conn, "SELECT name,email FROM providers WHERE id=$pid"));
fputcsv($out, ["Provider Report", "Generated at", date('Y-m-d H:i:s')]);
fputcsv($out, ["Provider ID", $pid]);
fputcsv($out, ["Name", $prov['name']]);
fputcsv($out, ["Email", $prov['email']]);
fputcsv($out, []);

// Completed Bookings
fputcsv($out, ["Completed Services"]);
fputcsv($out, ["Booking ID","Customer","Service","Completed At"]);
// Use actual_arrival if available, otherwise fall back to booking created_at
$bookings = mysqli_query($conn,
    "SELECT b.id AS booking_id, u.name AS customer, s.title AS service, COALESCE(b.actual_arrival, b.created_at) AS completed_at
     FROM bookings b
     JOIN users u ON u.id=b.user_id
     JOIN services s ON s.id=b.service_id
     WHERE b.provider_id=$pid AND b.status='completed'
     ORDER BY COALESCE(b.actual_arrival, b.created_at) DESC"
);
while ($row = mysqli_fetch_assoc($bookings)) {
    fputcsv($out, [$row['booking_id'], $row['customer'], $row['service'], $row['completed_at']]);
}
fputcsv($out, []);

// Late Arrival Reports
fputcsv($out, ["Late Arrival Reports"]);
fputcsv($out, ["Report ID","Booking ID","Reporter","Delay (mins)","Reason","Reported At"]);
$lateReports = mysqli_query($conn,
    "SELECT lr.id, lr.booking_id, u.name AS reporter, lr.delay_minutes, lr.reason, lr.reported_at
    FROM late_reports lr
    JOIN users u ON u.id=lr.reporter_user_id
     JOIN bookings b ON lr.booking_id=b.id
     WHERE b.provider_id=$pid
     ORDER BY lr.reported_at DESC"
);
while ($row = mysqli_fetch_assoc($lateReports)) {
    fputcsv($out, [$row['id'], $row['booking_id'], $row['reporter'], $row['delay_minutes'], $row['reason'], $row['reported_at']]);
}
fputcsv($out, []);

// Payments
fputcsv($out, ["Payments"]);
fputcsv($out, ["Payment ID","Booking ID","Amount","Provider Earning","Admin Fee","Status","Date"]);
$payments = mysqli_query($conn,
    "SELECT p.id, p.booking_id, p.amount, p.provider_earning, p.admin_fee, p.status, p.created_at
     FROM payments p
     JOIN bookings b ON p.booking_id=b.id
     WHERE b.provider_id=$pid
     ORDER BY p.created_at DESC"
);
while ($row = mysqli_fetch_assoc($payments)) {
    fputcsv($out, [$row['id'], $row['booking_id'], $row['amount'], $row['provider_earning'], $row['admin_fee'], $row['status'], $row['created_at']]);
}

// Totals: sum only successful payments
$totalRow = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT IFNULL(SUM(p.provider_earning),0) AS total_earnings
     FROM payments p
     JOIN bookings b ON p.booking_id=b.id
     WHERE b.provider_id=$pid AND p.status='success'"
));
fputcsv($out, []);
fputcsv($out, ["Total Provider Earnings (successful payments)", isset($totalRow['total_earnings']) ? $totalRow['total_earnings'] : 0]);

fclose($out);
exit;
