<?php
// provider_bookings.php (refactored, secure, UI-enhanced)
session_start();
require_once __DIR__ . '/../inc/db.php';

// ---------- AUTH ----------
if (!isset($_SESSION['provider_id'])) {
    header("Location: provider_login.php");
    exit();
}
$pid = intval($_SESSION['provider_id']);

// ---------- CSRF ----------
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
}
$csrf = $_SESSION['csrf_token'];

// ---------- FLASH ----------
if (!isset($_SESSION['flash'])) $_SESSION['flash'] = null;
function flash($msg, $type = 'info') {
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

// ---------- HANDLE ACTIONS (POST) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // basic token check
    $posted = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], (string)$posted)) {
        flash('Invalid CSRF token.', 'danger');
        header('Location: provider_bookings.php');
        exit();
    }

    $bid = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;
    $action = $_POST['action'] ?? '';

    if ($bid <= 0 || !$action) {
        flash('Invalid request.', 'danger');
        header('Location: provider_bookings.php');
        exit();
    }

    // Ensure this booking belongs to this provider
    $stmt = $conn->prepare("SELECT id, service_id, user_id, status FROM bookings WHERE id = ? AND provider_id = ? LIMIT 1");
    $stmt->bind_param('ii', $bid, $pid);
    $stmt->execute();
    $bookingRes = $stmt->get_result();
    $booking = $bookingRes->fetch_assoc();
    $stmt->close();

    if (!$booking) {
        flash('Booking not found or not permitted.', 'danger');
        header('Location: provider_bookings.php');
        exit();
    }

    // Normalize current status
    $currentStatus = strtolower($booking['status'] ?? '');

    // ACCEPT
    if ($action === 'accept' && $currentStatus === 'pending') {
        $u = $conn->prepare("UPDATE bookings SET status='accepted' WHERE id = ? AND provider_id = ?");
        $u->bind_param('ii', $bid, $pid);
        $u->execute();
        $u->close();
        flash('Booking accepted.', 'success');
        header('Location: provider_bookings.php');
        exit();
    }

    // REJECT
    if ($action === 'reject' && $currentStatus === 'pending') {
        $u = $conn->prepare("UPDATE bookings SET status='rejected' WHERE id = ? AND provider_id = ?");
        $u->bind_param('ii', $bid, $pid);
        $u->execute();
        $u->close();
        flash('Booking rejected.', 'warning');
        header('Location: provider_bookings.php');
        exit();
    }

    // LOG ARRIVAL
    if ($action === 'arrival' && in_array($currentStatus, ['accepted','pending'])) {
        $now = date('Y-m-d H:i:s');
        $u = $conn->prepare("UPDATE bookings SET actual_arrival = ?, status = 'accepted' WHERE id = ? AND provider_id = ?");
        $u->bind_param('sii', $now, $bid, $pid);
        $u->execute();
        $u->close();
        flash('Arrival logged.', 'success');
        header('Location: provider_bookings.php');
        exit();
    }

    // COMPLETE + create pending payment + generate HTML invoice
    if ($action === 'complete' && in_array($currentStatus, ['accepted','pending'])) {

        // mark completed
        $u = $conn->prepare("UPDATE bookings SET status='completed' WHERE id = ? AND provider_id = ?");
        $u->bind_param('ii', $bid, $pid);
        $u->execute();
        $u->close();

        // fetch service price & user
        $svcStmt = $conn->prepare("SELECT s.price, s.title, b.user_id FROM services s JOIN bookings b ON b.service_id = s.id WHERE b.id = ? LIMIT 1");
        $svcStmt->bind_param('i', $bid);
        $svcStmt->execute();
        $svcRes = $svcStmt->get_result();
        $svc = $svcRes->fetch_assoc();
        $svcStmt->close();

        if (!$svc) {
            flash('Service info not found; payment not created.', 'warning');
            header('Location: provider_bookings.php');
            exit();
        }

        $amount = round(floatval($svc['price']), 2);
        $admin_fee = round($amount * 0.10, 2);
        $provider_earning = round($amount - $admin_fee, 2);

        // insert pending payment
        $ins = $conn->prepare("INSERT INTO payments (booking_id, amount, status, provider_earning, admin_fee, created_at) VALUES (?, ?, 'pending', ?, ?, NOW())");
        $ins->bind_param('idds', $bid, $amount, $provider_earning, $admin_fee); // note: bind types adjusted below
        // PHP mysqli doesn't allow 'd' and 's' mixed incorrectly above, fix with proper types:
        $ins->close();
        // do safe insert using types: i d d d => 'iddd'
        $ins2 = $conn->prepare("INSERT INTO payments (booking_id, amount, status, provider_earning, admin_fee, created_at) VALUES (?, ?, 'pending', ?, ?, NOW())");
        $ins2->bind_param('iddd', $bid, $amount, $provider_earning, $admin_fee);
        $ok = $ins2->execute();
        if (!$ok) {
            $err = $ins2->error;
            $ins2->close();
            flash("Failed to create payment record: $err", 'danger');
            header('Location: provider_bookings.php');
            exit();
        }
        $payment_id = $ins2->insert_id;
        $ins2->close();

        // generate HTML invoice
        $invoiceDir = __DIR__ . '/../exports/invoices';
        if (!is_dir($invoiceDir)) mkdir($invoiceDir, 0755, true);

        // fetch customer and provider friendly names
        $custStmt = $conn->prepare("SELECT u.name AS customer_name, u.email AS customer_email FROM users u JOIN bookings b ON b.user_id = u.id WHERE b.id = ? LIMIT 1");
        $custStmt->bind_param('i', $bid);
        $custStmt->execute();
        $custRes = $custStmt->get_result();
        $cust = $custRes->fetch_assoc();
        $custStmt->close();

        $provStmt = $conn->prepare("SELECT name AS provider_name FROM providers WHERE id = ? LIMIT 1");
        $provStmt->bind_param('i', $pid);
        $provStmt->execute();
        $provRes = $provStmt->get_result();
        $prov = $provRes->fetch_assoc();
        $provStmt->close();

        $serviceTitle = $svc['title'] ?? 'Service';
        $invoiceHtml = "<!doctype html><html><head><meta charset='utf-8'><title>Invoice #{$payment_id}</title>";
        $invoiceHtml .= "<style>body{font-family:Arial,Helvetica,sans-serif;padding:20px;color:#222} .container{max-width:700px;margin:auto} h2{color:#007E6E} table{width:100%;border-collapse:collapse;margin-top:15px} th,td{border:1px solid #ddd;padding:8px;text-align:left} th{background:#f5f5f5}</style>";
        $invoiceHtml .= "</head><body><div class='container'>";
        $invoiceHtml .= "<h2>Invoice #{$payment_id}</h2>";
        $invoiceHtml .= "<p><strong>Date:</strong> " . date('Y-m-d H:i:s') . "</p>";
        $invoiceHtml .= "<p><strong>Customer:</strong> " . htmlspecialchars($cust['customer_name'] ?? '') . " (" . htmlspecialchars($cust['customer_email'] ?? '') . ")</p>";
        $invoiceHtml .= "<p><strong>Provider:</strong> " . htmlspecialchars($prov['provider_name'] ?? '') . "</p>";
        $invoiceHtml .= "<p><strong>Service:</strong> " . htmlspecialchars($serviceTitle) . "</p>";
        $invoiceHtml .= "<table><tr><th>Description</th><th>Amount (₹)</th></tr>";
        $invoiceHtml .= "<tr><td>Service Charge</td><td>" . number_format($amount, 2) . "</td></tr>";
        $invoiceHtml .= "<tr><td>Admin Fee</td><td>" . number_format($admin_fee, 2) . "</td></tr>";
        $invoiceHtml .= "<tr><td><strong>Total</strong></td><td><strong>" . number_format($amount, 2) . "</strong></td></tr>";
        $invoiceHtml .= "</table>";
        $invoiceHtml .= "<p style='margin-top:12px'>Payment ID: " . $payment_id . "</p>";
        $invoiceHtml .= "</div></body></html>";

        $htmlPath = $invoiceDir . '/invoice_' . $payment_id . '.html';
        file_put_contents($htmlPath, $invoiceHtml);

        // log small entry
        $logDir = __DIR__ . '/../logs';
        if (!is_dir($logDir)) mkdir($logDir, 0755, true);
        $logFile = $logDir . '/invoices.log';
        $logLine = date('Y-m-d H:i:s') . " | created_pending_payment | provider={$pid} | booking={$bid} | payment={$payment_id}\n";
        file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);

        flash('Booking completed and pending payment created.', 'success');
        header('Location: provider_bookings.php');
        exit();
    }

    // unknown action
    flash('Unknown action or action not allowed in current state.', 'warning');
    header('Location: provider_bookings.php');
    exit();
}

// ---------- FETCH BOOKINGS (provider only) ----------
$stmt = $conn->prepare("
    SELECT b.id, b.booking_type, b.preferred_date, b.preferred_time, b.expected_arrival, b.actual_arrival, b.status,
           u.name AS customer_name, s.title AS service_title
    FROM bookings b
    JOIN users u ON u.id = b.user_id
    JOIN services s ON s.id = b.service_id
    WHERE b.provider_id = ?
    ORDER BY b.created_at DESC
");
$stmt->bind_param('i', $pid);
$stmt->execute();
$res = $stmt->get_result();
$bookings = $res->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// grab flash and clear
$flash = $_SESSION['flash'];
$_SESSION['flash'] = null;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Provider Bookings</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  :root{--brand:#007E6E;--muted:#6c757d}
  body{font-family:Inter,Segoe UI,Helvetica,Arial,sans-serif;background:#f6f7f8}
  .container{padding:28px}
  .badge-status{padding:.45em .65em;border-radius:10px;font-weight:700}
  .badge-pending{background:#ffca2c;color:#000}
  .badge-accepted{background:#0d6efd;color:#fff}
  .badge-rejected{background:#dc3545;color:#fff}
  .badge-completed{background:#28a745;color:#fff}
  .btn-primary-custom{background:var(--brand);border:none}
  .btn-primary-custom:hover{background:#046a59}
  .ecom-card{background:#fff;border-radius:10px;padding:16px;box-shadow:0 6px 18px rgba(0,0,0,0.06)}
</style>
</head>
<body>
<?php include_once __DIR__ . '/../inc/provider_sidebar.php'; ?>

<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0">Bookings</h3>
    <a class="btn btn-outline-secondary" href="provider_dashboard.php">Back to Dashboard</a>
  </div>

  <?php if ($flash): ?>
    <div class="alert alert-<?= htmlspecialchars($flash['type'] ?? 'info') ?> alert-dismissible fade show">
      <?= htmlspecialchars($flash['msg']) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <div class="ecom-card">
    <div class="table-responsive">
      <table class="table table-hover align-middle">
        <thead class="table-light">
          <tr>
            <th style="width:70px">ID</th>
            <th>Customer</th>
            <th>Service</th>
            <th>Type</th>
            <th>Expected</th>
            <th>Actual</th>
            <th>Status</th>
            <th style="width:250px">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (count($bookings) === 0): ?>
            <tr><td colspan="8" class="text-center text-muted py-4">No bookings found.</td></tr>
          <?php else: foreach ($bookings as $b): ?>
            <?php
              $status = strtolower($b['status'] ?? '');
              $badgeClass = 'badge-status badge-pending';
              if ($status === 'accepted') $badgeClass = 'badge-status badge-accepted';
              if ($status === 'rejected') $badgeClass = 'badge-status badge-rejected';
              if ($status === 'completed') $badgeClass = 'badge-status badge-completed';
            ?>
            <tr>
              <td><?= (int)$b['id'] ?></td>
              <td><?= htmlspecialchars($b['customer_name']) ?></td>
              <td><?= htmlspecialchars($b['service_title']) ?></td>
              <td><?= htmlspecialchars(ucfirst($b['booking_type'] ?? '')) ?></td>
              <td><?= htmlspecialchars($b['preferred_date'] ?? '—') ?> <?= htmlspecialchars($b['preferred_time'] ?? '') ?></td>
              <td><?= htmlspecialchars($b['actual_arrival'] ?: '—') ?></td>
              <td><span class="<?= $badgeClass ?>"><?= htmlspecialchars(ucfirst($b['status'] ?? '')) ?></span></td>
              <td>
                <form method="post" class="d-flex gap-2 align-items-center">
                  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
                  <input type="hidden" name="booking_id" value="<?= (int)$b['id'] ?>">

                  <?php if ($status === 'pending'): ?>
                    <button type="submit" name="action" value="accept" class="btn btn-sm btn-primary-custom">Accept</button>
                    <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger">Reject</button>
                  <?php elseif ($status === 'accepted'): ?>
                    <button type="submit" name="action" value="arrival" class="btn btn-sm btn-warning">Log Arrival</button>
                    <button type="submit" name="action" value="complete" class="btn btn-sm btn-success">Complete</button>
                  <?php else: ?>
                    <span class="text-muted small">No actions</span>
                  <?php endif; ?>
                </form>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?php include_once __DIR__ . '/../inc/site_footer.php'; ?>
</body>
</html>
