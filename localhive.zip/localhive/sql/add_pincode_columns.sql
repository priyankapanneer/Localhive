-- Migration: add pincode columns to providers and users
ALTER TABLE `providers`
  ADD COLUMN `pincode` VARCHAR(20) NULL AFTER `address`;

ALTER TABLE `users`
  ADD COLUMN `pincode` VARCHAR(20) NULL AFTER `address`;

-- index
CREATE INDEX `idx_providers_pincode` ON `providers` (`pincode`);
CREATE INDEX `idx_users_pincode` ON `users` (`pincode`);
