-- Migration: create pincode_neighbors table
CREATE TABLE IF NOT EXISTS pincode_neighbors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pincode VARCHAR(20) NOT NULL,
  neighbor VARCHAR(20) NOT NULL,
  UNIQUE KEY uniq_pair (pincode, neighbor)
);

CREATE INDEX idx_pincode ON pincode_neighbors (pincode);

-- Example rows (populate real neighbor data as needed):
-- INSERT INTO pincode_neighbors (pincode, neighbor) VALUES ('560001','560002'),('560001','560003');
