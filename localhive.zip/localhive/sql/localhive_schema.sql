-- localhive_schema.sql
CREATE DATABASE IF NOT EXISTS localhive_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE localhive_db;

-- Admins
CREATE TABLE admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Users (Customers)
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(30),
  address TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Providers
CREATE TABLE providers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(30),
  address TEXT,
  lat DOUBLE NULL,
  lng DOUBLE NULL,
  approved TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Services
CREATE TABLE services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  provider_id INT NOT NULL,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  duration_minutes INT DEFAULT 60,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (provider_id) REFERENCES providers(id) ON DELETE CASCADE
);

-- Bookings
CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  provider_id INT NOT NULL,
  service_id INT NOT NULL,
  booking_type ENUM('normal','emergency') DEFAULT 'normal',
  preferred_date DATE,
  preferred_time TIME,
  expected_arrival DATETIME DEFAULT NULL,
  actual_arrival DATETIME DEFAULT NULL,
  status ENUM('pending','accepted','rejected','completed','cancelled') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (provider_id) REFERENCES providers(id) ON DELETE CASCADE,
  FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
);

-- Late arrival reports
CREATE TABLE late_reports (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  reporter_user_id INT NOT NULL,
  provider_id INT NOT NULL,
  reported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  delay_minutes INT NOT NULL,
  reason TEXT,
  resolved TINYINT(1) DEFAULT 0,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  FOREIGN KEY (reporter_user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (provider_id) REFERENCES providers(id) ON DELETE CASCADE
);

-- Payments (dummy)
CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  status ENUM('success','failed') DEFAULT 'success',
  provider_earning DECIMAL(10,2) DEFAULT 0,
  admin_fee DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
);

-- Sample admin
INSERT INTO admins (username, password) VALUES (
  'admin',
  -- password: admin123 (hash)
  '$2y$10$abcdefghijklmnopqrstuv' -- replace with real hash later
);

-- OPTIONAL: sample provider and service entries (replace hashed passwords)
INSERT INTO providers (name,email,password,phone,lat,lng,approved) VALUES
('Ramesh Plumbing','ramesh@example.com','$2y$10$samplehash1','9876543210',12.9716,77.5946,1),
('Suresh Electric','suresh@example.com','$2y$10$samplehash2','9876512345',12.9611,77.6387,1);

INSERT INTO users (name,email,password,phone,address) VALUES
('Priyanka','priyanka@example.com','$2y$10$samplehash3','9999999999','MG Road, Bangalore');

INSERT INTO services (provider_id,title,description,price,duration_minutes) VALUES
(1,'Home Plumbing Fix','Fix leaks and replace pipes',500.00,60),
(2,'Home Electrical Repair','Fix wiring and switches',700.00,60);
