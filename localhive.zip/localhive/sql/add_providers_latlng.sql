-- Migration: add latitude and longitude columns to providers
ALTER TABLE `providers`
  ADD COLUMN `latitude` DOUBLE NULL AFTER `zip`,
  ADD COLUMN `longitude` DOUBLE NULL AFTER `latitude`;

-- Add an index to speed up bounding-box queries
CREATE INDEX `idx_providers_lat_lng` ON `providers` (`latitude`, `longitude`);
